"""Portable full-controller SOFTWARE-PLANT timing; no Webots/physical sensors."""
import argparse
import csv
import gc
import importlib.util
import json
import math
import multiprocessing as mp
import os
from pathlib import Path
import platform
import sys
import time
import zipfile

ROOT=Path(__file__).resolve().parents[2]
os.environ.setdefault('NUMBA_CACHE_DIR',str(ROOT/'.numba-cache'))
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.matplotlib-cache'))
sys.path.insert(0,str(ROOT/'tools/reviewer_followup'))
sys.path.insert(0,str(ROOT/'tools/laptop'))
import boot
import numpy as np
import environment
from environment import CausalEnv
from supervisor import observation
from filtered import FilteredController
from plant import advance
from kernels import path_values
from realtime_kernels import measure_fast
from precision_wait import DeadlineWaiter

environment.measure=measure_fast
CASES={'nominal':0.,'delay20':.02,'delay1000':1.,'cpu_stress':0.,'worker_crash':0.}


def load_portable(folder):
    spec=importlib.util.spec_from_file_location('portable_actor',ROOT/'tools/laptop/laptop_benchmark.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.BASE=Path(folder);return module


def actor(connection,folder,seed,delay):
    try:
        portable=load_portable(folder);portable.golden_check();model=portable.load(seed)
        for _ in range(100):portable.logits(model,np.zeros((1,20),dtype=np.float32))
        with DeadlineWaiter('auto') as waiter:
            connection.send(('ready',waiter.backend))
            while True:
                request=connection.recv()
                if request is None:return
                seq,observed_ns,x=request
                entered=time.perf_counter_ns();index=int(portable.logits(model,x[None,:]).argmax(1)[0])
                inferred=time.perf_counter_ns()
                if delay:waiter.wait_until_ns(inferred+int(delay*1e9))
                connection.send(('output',dict(seq=seq,observed_ns=observed_ns,entered_ns=entered,
                    inferred_ns=inferred,sent_ns=time.perf_counter_ns(),residual=[-.08,-.04,0.,.04,.08][index],
                    observation_json=json.dumps(x.tolist()))))
    except (EOFError,BrokenPipeError):pass
    except Exception as error:
        try:connection.send(('error',repr(error)))
        except (EOFError,OSError):pass
    finally:connection.close()


def burn(stop):
    value=.123
    while not stop.is_set():
        for _ in range(10000):value=(value*1.000001+.000001)%1.


def shutdown(process):
    process.join(timeout=.5)
    if process.is_alive():process.terminate();process.join(timeout=2)


def write_csv(file,rows):
    if not rows:return
    with file.open('w',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows)


def episode(ctx,case,seed,profile,seconds,models,out):
    env=CausalEnv(mode='lqr',case=(20,'dlc220',1,'nominal',1256000000+seed));env.reset()
    # Warm every parent numerical path outside the measured window.
    for _ in range(40):env.step(2)
    c=FilteredController(profile)
    c.packet=(1,0.,.04);c.previews=env.obs[6:9].astype(float)*.02
    for i in range(5):c.choose(i*.001,env.baseline,env.estimate,env.state[5],env.measured_speed,env.curvature,env.gain)
    env.reset();env.tick=0;env.estimate=np.zeros(4);env.cov=np.eye(4)*.01;env.previous=np.zeros(4)
    ctrl=FilteredController(profile);env.ctrl=ctrl
    parent,child=ctx.Pipe();worker=ctx.Process(target=actor,args=(child,str(models),seed,CASES[case]))
    worker.start();child.close()
    if not parent.poll(120):shutdown(worker);raise RuntimeError('actor startup timeout; first-run compilation is outside measured window')
    status,backend=parent.recv()
    if status!='ready':shutdown(worker);raise RuntimeError(backend)
    stop=ctx.Event();stress=None
    if case=='cpu_stress':stress=ctx.Process(target=burn,args=(stop,));stress.start()
    n=round(seconds/.01);packet=None;busy=False;dead=False;seq=0;rows=[];packets=[];errors=[]
    enabled=gc.isenabled();gc.collect();gc.disable()
    try:
        with DeadlineWaiter('auto') as waiter:
            monitor_backend=waiter.backend;origin=time.perf_counter_ns()+20_000_000
            for tick in range(n):
                target=origin+tick*10_000_000;waiter.wait_until_ns(target)
                release=time.perf_counter_ns()
                if case=='worker_crash' and tick==n//3:worker.terminate()
                if not dead:
                    try:
                        if parent.poll():
                            tag,message=parent.recv()
                            if tag!='output':raise RuntimeError(message)
                            message['received_ns']=time.perf_counter_ns();packet=message;packets.append(message);busy=False
                        if not worker.is_alive():raise RuntimeError('worker exited')
                    except (EOFError,OSError,RuntimeError) as error:
                        errors.append(str(error));dead=True;packet=None;busy=False
                env._sense()
                baseline=env.baseline
                if packet is None:ctrl.packet=None
                else:ctrl.packet=(packet['seq'],(packet['observed_ns']-origin)/1e9,packet['residual'])
                ctrl.previews=env.obs[6:9].astype(float)*.02
                obs=observation(env.state,env.estimate,env.measured_speed,ctrl.previews,ctrl,(release-origin)/1e9)
                if not busy and not dead:
                    try:seq+=1;parent.send((seq,release,obs));busy=True
                    except (OSError,EOFError):dead=True;packet=None;ctrl.packet=None
                command,reason=ctrl.choose((time.perf_counter_ns()-origin)/1e9,baseline,env.estimate,
                    env.state[5],env.measured_speed,env.curvature,env.gain)
                apply=time.perf_counter_ns();age=None if packet is None else (apply-packet['observed_ns'])/1e9
                miss=apply>target+10_000_000
                if miss or (age is not None and age>=.05):
                    ctrl.filtered=0.;ctrl.weight=0.;ctrl.good=0;ctrl.last_command=baseline
                    command=baseline;reason='deadline' if miss else 'age_at_apply'
                old=env.state[5];env.state=advance(env.state,command,20.,.9,1.);env.tick+=1
                y,h,_=path_values(env.state[0],env.path)
                rows.append(dict(tick=tick,target_ns=target,release_ns=release,apply_ns=apply,
                    observed_ns=release,command=float(command),baseline=float(baseline),weight=ctrl.weight,
                    filtered_residual=ctrl.filtered,reason=reason,packet_seq=packet['seq'] if packet else -1,
                    packet_observed_ns=packet['observed_ns'] if packet else -1,packet_age_s=age,
                    deadline_miss=miss,worker_dead=dead,error=float(env.state[1]-y),heading_error=float(env.state[2]-h),
                    actuator=float(env.state[5]),actuator_rate=float((env.state[5]-old)/.01),
                    control_ns=apply-release,release_lateness_ns=release-target))
    finally:
        if enabled:gc.enable()
        try:
            if not dead:parent.send(None)
        except (OSError,EOFError):pass
        shutdown(worker);parent.close();stop.set()
        if stress is not None:shutdown(stress)
    write_csv(out/f'{case}-ticks.csv',rows);write_csv(out/f'{case}-packets.csv',packets)
    violations=sum((r['worker_dead'] or r['deadline_miss'] or (r['packet_age_s'] is not None and r['packet_age_s']>=.05))
                   and (r['weight']!=0 or r['command']!=r['baseline']) for r in rows)
    result=dict(case=case,ticks=n,seed=seed,noise_id=1256000000+seed,profile=profile,
        deadline_misses=sum(r['deadline_miss'] for r in rows),fallback_violations=violations,
        nonzero_correction_ticks=sum(abs(r['command']-r['baseline'])>1e-10 for r in rows),
        survived=all(abs(r['error'])<=2.5 and abs(r['heading_error'])<=.6 for r in rows),
        actor_packets=len(packets),intentional_failure_events=errors,monitor_timer_backend=monitor_backend,
        worker_timer_backend=backend,simulated_duration_s=n*.01,
        wall_duration_s=(rows[-1]['apply_ns']-origin)/1e9+.01)
    print(case,result['deadline_misses'],'controller deadlines missed; fallback violations',violations,flush=True)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--models',type=Path,default=ROOT/'actor')
    p.add_argument('--output',type=Path,required=True);p.add_argument('--seconds',type=float,default=13.)
    p.add_argument('--seed',type=int,choices=[701,802,903],default=701)
    p.add_argument('--profile',choices=['age_filtered','predictive_filtered','preview_filtered'],default='age_filtered')
    args=p.parse_args()
    if not .5<=args.seconds<=30:p.error('seconds must be0.5..30')
    args.output.mkdir(parents=True,exist_ok=False)
    rows=[episode(mp.get_context('spawn'),case,args.seed,args.profile,args.seconds,args.models,args.output) for case in CASES]
    result=dict(scope='Full observer/LQR/residual-supervisor/actor IPC plus fixed-step software plant; NOT native Webots, sensors/CAN or physical actuator',
        runtime=dict(python=sys.version,platform=platform.platform(),numpy=np.__version__),episodes=rows,
        functional_pass=all(r['survived'] and r['fallback_violations']==0 for r in rows),
        observed_timing_pass=all(r['deadline_misses']==0 for r in rows),guaranteed_hard_realtime=False,
        injection='Actual post-inference worker unavailability; recorded separately from computation duration',
        limits='Plant advances in10ms simulation steps; host stalls do not continuously advance physical dynamics. Target execution must be verified on this laptop.')
    (args.output/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    with zipfile.ZipFile(args.output/'Results.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in args.output.iterdir():
            if f.suffix in ('.json','.csv'):z.write(f,f.name)
    print('Saved',args.output/'Results.zip',flush=True)


if __name__=='__main__':main()
