from .native import prepare


def test_native_project_uses_real_devices_and_has_no_target_truth_interface(tmp_path):
    world = prepare(tmp_path/'native', 73)
    text = world.read_text()
    source = (tmp_path/'native/project/controllers/autonomous_vehicle/autonomous_vehicle.py').read_text()
    assert text.count('size 2000 100 0.2') == 2
    assert text.count('name "local_radar"') == 3
    assert text.count('Emitter {') == text.count('Receiver {') == 3
    assert 'randomSeed 73' in text
    assert 'getFromDef' not in source and 'getPosition' not in source and '.retarget(' not in source
    assert 'getTargets()' in source and 'getBytes()' in source
    compile(source, 'autonomous_vehicle.py', 'exec')
