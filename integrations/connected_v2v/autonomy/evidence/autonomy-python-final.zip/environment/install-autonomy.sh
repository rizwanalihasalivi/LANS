#!/usr/bin/env bash
set -euo pipefail
cd /workspace/LANS
export UV_CACHE_DIR=/workspace/.uv-cache
export UV_PYTHON_INSTALL_DIR=/workspace/.lans-python
export UV_PYTHON_BIN_DIR=/workspace/.lans-bin
mkdir -p "$UV_PYTHON_BIN_DIR"
uv python install 3.10
if [ ! -x /workspace/lans-venv/bin/python ]; then
    uv venv --python 3.10 /workspace/lans-venv
fi
uv pip install --python /workspace/lans-venv/bin/python \
    numpy==1.23.5 scipy==1.10.1 matplotlib==3.7.1 pandas==2.0.0 pillow==9.5.0 \
    pytest==7.3.1 gymnasium==0.28.1 stable-baselines3==2.0.0 torch==2.0.0+cpu \
    --extra-index-url https://download.pytorch.org/whl/cpu --index-strategy unsafe-best-match
uv pip check --python /workspace/lans-venv/bin/python
bash integrations/webots/install-private.sh
