; benchmark generated from python API
(set-info :status unknown)
(declare-fun g () Real)
(assert
 (= g 1.0))
(assert
 (< (- g (/ 3.0 2.0)) 0.0))
(check-sat)
