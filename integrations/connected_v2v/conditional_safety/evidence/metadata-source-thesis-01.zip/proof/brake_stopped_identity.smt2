; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Real)
(declare-fun v () Real)
(declare-fun h () Real)
(declare-fun m () Real)
(declare-fun s () Real)
(declare-fun w () Real)
(assert
 (> b 0.0))
(assert
 (>= v 0.0))
(assert
 (> h 0.0))
(assert
 (> m 0.0))
(assert
 (let ((?x36 (* b h)))
 (< v ?x36)))
(assert
 (let ((?x25 (* v v)))
 (let ((?x27 (* 2.0 b)))
 (let ((?x32 (* ?x27 s)))
 (= ?x32 ?x25)))))
(assert
 (= w 0.0))
(assert
 (let (($x46 (>= w 0.0)))
(let (($x45 (>= s 0.0)))
(let (($x48 (and $x45 $x46 (= (+ (* (* 2.0 b) s) (* w w)) (* v v)))))
(not $x48)))))
(check-sat)
