; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Real)
(declare-fun v () Real)
(declare-fun h () Real)
(declare-fun m () Real)
(declare-fun X () Real)
(declare-fun B () Real)
(declare-fun Xn () Real)
(declare-fun Vn () Real)
(assert
 (> b 0.0))
(assert
 (>= v 0.0))
(assert
 (> h 0.0))
(assert
 (> m 0.0))
(assert
 (let ((?x27 (* 2.0 b)))
 (let ((?x30 (* ?x27 (- (- B X) m))))
 (let ((?x25 (* v v)))
 (<= ?x25 ?x30)))))
(assert
 (<= Xn X))
(assert
 (>= Vn 0.0))
(assert
 (<= Vn v))
(assert
 (let ((?x57 (* Vn Vn)))
(let (($x74 (<= ?x57 (* (* 2.0 b) (- (- B Xn) m)))))
(not $x74))))
(check-sat)
