; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Real)
(declare-fun v () Real)
(declare-fun h () Real)
(declare-fun m () Real)
(declare-fun X () Real)
(declare-fun B () Real)
(declare-fun s () Real)
(declare-fun w () Real)
(assert
 (> b 0.0))
(assert
 (>= v 0.0))
(assert
 (> h 0.0))
(assert
 (> m 0.0))
(assert
 (let ((?x27 (* 2.0 b)))
 (let ((?x30 (* ?x27 (- (- B X) m))))
 (let ((?x25 (* v v)))
 (<= ?x25 ?x30)))))
(assert
 (let ((?x36 (* b h)))
 (>= v ?x36)))
(assert
 (= s (- (* v h) (/ (* (* b h) h) 2.0))))
(assert
 (= w (- v (* b h))))
(assert
 (let ((?x27 (* 2.0 b)))
(let ((?x30 (* ?x27 (- (- B X) m))))
(let ((?x33 (* w w)))
(let ((?x32 (* ?x27 s)))
(let ((?x34 (+ ?x32 ?x33)))
(let (($x35 (<= ?x34 ?x30)))
(not $x35))))))))
(check-sat)
