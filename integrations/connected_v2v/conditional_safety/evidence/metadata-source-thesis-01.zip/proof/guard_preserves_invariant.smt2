; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Real)
(declare-fun v () Real)
(declare-fun h () Real)
(declare-fun m () Real)
(declare-fun s () Real)
(declare-fun w () Real)
(declare-fun X () Real)
(declare-fun B () Real)
(declare-fun Xn () Real)
(declare-fun Vn () Real)
(declare-fun Bn () Real)
(assert
 (> b 0.0))
(assert
 (>= v 0.0))
(assert
 (> h 0.0))
(assert
 (> m 0.0))
(assert
 (>= s 0.0))
(assert
 (>= w 0.0))
(assert
 (let ((?x27 (* 2.0 b)))
 (let ((?x30 (* ?x27 (- (- B X) m))))
 (let ((?x33 (* w w)))
 (let ((?x32 (* ?x27 s)))
 (let ((?x34 (+ ?x32 ?x33)))
 (<= ?x34 ?x30)))))))
(assert
 (<= Xn (+ X s)))
(assert
 (>= Vn 0.0))
(assert
 (<= Vn w))
(assert
 (>= Bn B))
(assert
 (let ((?x57 (* Vn Vn)))
(let (($x61 (<= ?x57 (* (* 2.0 b) (- (- Bn Xn) m)))))
(not $x61))))
(check-sat)
