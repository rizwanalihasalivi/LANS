; benchmark generated from python API
(set-info :status unknown)
(declare-fun v () Real)
(declare-fun b () Real)
(declare-fun g () Real)
(assert
 (= v 16.0))
(assert
 (= (/ 11.0 2.0) b))
(assert
 (= g 1.0))
(assert
 (let ((?x25 (* v v)))
(> ?x25 (* (* 2.0 b) g))))
(check-sat)
