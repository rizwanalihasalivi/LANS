; benchmark generated from python API
(set-info :status unknown)
(declare-fun pos_now () Real)
(declare-fun old () Real)
(declare-fun new () Real)
(assert
 (<= old pos_now))
(assert
 (<= new pos_now))
(assert
 (let (($x85 (<= (ite (> old new) old new) pos_now)))
(not $x85)))
(check-sat)
