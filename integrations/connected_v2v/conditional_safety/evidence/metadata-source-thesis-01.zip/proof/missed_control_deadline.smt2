; benchmark generated from python API
(set-info :status unknown)
(declare-fun v () Real)
(declare-fun h () Real)
(declare-fun b () Real)
(declare-fun g () Real)
(assert
 (= v 10.0))
(assert
 (= (/ 1.0 20.0) h))
(assert
 (= (/ 11.0 2.0) b))
(assert
 (let ((?x75 (+ (+ (* v h) (/ (* (* (/ 11.0 4.0) h) h) 2.0)) (/ (^ (+ v (* (/ 11.0 4.0) h)) 2.0) (* 2.0 b)))))
 (= g ?x75)))
(assert
 (let ((?x79 (+ (* v (* 2.0 h)) (/ (* (* (/ 11.0 4.0) (* 2.0 h)) (* 2.0 h)) 2.0))))
(let ((?x9 (+ ?x79 (/ (^ (+ v (* (/ 11.0 4.0) (* 2.0 h))) 2.0) (* 2.0 b)))))
(> ?x9 g))))
(check-sat)
