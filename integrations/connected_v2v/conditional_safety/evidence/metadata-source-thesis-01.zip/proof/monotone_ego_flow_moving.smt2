; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Real)
(declare-fun v () Real)
(declare-fun h () Real)
(declare-fun m () Real)
(declare-fun a () Real)
(declare-fun s () Real)
(declare-fun w () Real)
(assert
 (> b 0.0))
(assert
 (>= v 0.0))
(assert
 (> h 0.0))
(assert
 (> m 0.0))
(assert
 (>= a (- b)))
(assert
 (let ((?x95 (* a h)))
 (let ((?x96 (+ v ?x95)))
 (>= ?x96 0.0))))
(assert
 (= s (+ (* v h) (/ (* (* a h) h) 2.0))))
(assert
 (let ((?x95 (* a h)))
 (let ((?x96 (+ v ?x95)))
 (= w ?x96))))
(assert
 (let (($x46 (>= w 0.0)))
(let (($x45 (>= s 0.0)))
(let (($x103 (and $x45 $x46)))
(not $x103)))))
(check-sat)
