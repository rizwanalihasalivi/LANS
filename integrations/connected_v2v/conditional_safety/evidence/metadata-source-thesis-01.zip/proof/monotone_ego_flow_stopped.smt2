; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Real)
(declare-fun v () Real)
(declare-fun h () Real)
(declare-fun m () Real)
(declare-fun a () Real)
(declare-fun s () Real)
(declare-fun w () Real)
(assert
 (> b 0.0))
(assert
 (>= v 0.0))
(assert
 (> h 0.0))
(assert
 (> m 0.0))
(assert
 (< a 0.0))
(assert
 (let ((?x95 (* a h)))
 (let ((?x96 (+ v ?x95)))
 (< ?x96 0.0))))
(assert
 (let ((?x25 (* v v)))
 (= (* (* 2.0 (- a)) s) ?x25)))
(assert
 (= w 0.0))
(assert
 (let (($x45 (>= s 0.0)))
(not $x45)))
(check-sat)
