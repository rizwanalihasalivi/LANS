; benchmark generated from python API
(set-info :status unknown)
(declare-fun error () Real)
(declare-fun pos_old () Real)
(declare-fun measured () Real)
(assert
 (>= error 0.0))
(assert
 (<= (- measured pos_old) error))
(assert
 (let (($x92 (<= (- measured error) pos_old)))
(not $x92)))
(check-sat)
