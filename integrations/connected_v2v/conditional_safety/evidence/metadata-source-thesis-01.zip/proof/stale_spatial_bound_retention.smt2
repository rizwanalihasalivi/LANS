; benchmark generated from python API
(set-info :status unknown)
(declare-fun pos_old () Real)
(declare-fun old () Real)
(declare-fun pos_now () Real)
(assert
 (<= old pos_old))
(assert
 (<= pos_old pos_now))
(assert
 (let (($x81 (<= old pos_now)))
(not $x81)))
(check-sat)
