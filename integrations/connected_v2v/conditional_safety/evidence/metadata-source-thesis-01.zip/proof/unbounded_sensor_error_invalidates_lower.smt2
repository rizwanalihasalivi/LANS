; benchmark generated from python API
(set-info :status unknown)
(declare-fun g () Real)
(assert
 (= g 10.0))
(assert
 (> (+ g 1.0) g))
(check-sat)
