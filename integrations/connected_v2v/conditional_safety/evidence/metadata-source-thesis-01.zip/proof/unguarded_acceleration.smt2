; benchmark generated from python API
(set-info :status unknown)
(declare-fun v () Real)
(declare-fun h () Real)
(declare-fun b () Real)
(declare-fun g () Real)
(assert
 (= v 10.0))
(assert
 (= (/ 1.0 20.0) h))
(assert
 (= (/ 11.0 2.0) b))
(assert
 (let ((?x101 (* 2.0 b)))
 (let ((?x25 (* v v)))
 (let ((?x102 (/ ?x25 ?x101)))
 (= g ?x102)))))
(assert
 (let ((?x75 (+ (+ (* v h) (/ (* (* (/ 11.0 4.0) h) h) 2.0)) (/ (^ (+ v (* (/ 11.0 4.0) h)) 2.0) (* 2.0 b)))))
(> ?x75 g)))
(check-sat)
