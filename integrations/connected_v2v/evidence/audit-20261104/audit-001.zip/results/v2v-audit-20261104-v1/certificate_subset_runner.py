from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import json
import sys
from integrations.connected_v2v.settling.certify import episode
ROOT=Path('/workspace/LANS/results/v2v-audit-20261104-v1')
def run(job):
    family,case,speed,seed=job
    name=f'{case}-{speed}-{seed}'
    result=episode(ROOT/f'{family}-validation'/name,ROOT/'certificates'/family/name,native=family=='native')
    return dict(family=family,case=name,**result)
if __name__=='__main__':
    family=sys.argv[1];native=family=='native';seed=22003 if native else 21001;top=12 if native else 16
    jobs=[(family,'curved',top,seed),(family,'combined',top,seed),(family,'noisy_nonconnected',12,seed)]
    results=[]
    with ProcessPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(run,job) for job in jobs]):
            r=future.result();results.append(r);print(json.dumps({k:r[k] for k in ('family','case','passed','pair_intervals')}),flush=True)
    report=dict(passed=all(r['passed'] for r in results),results=results)
    with (ROOT/'certificates'/f'{family}-summary.json').open('x') as stream:json.dump(report,stream,indent=2)
    if not report['passed']:raise SystemExit(1)
