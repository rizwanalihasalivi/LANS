from integrations.connected_v2v.autonomy.controller import AutonomousFollower, Scan, Detection
from integrations.connected_v2v.robustness.controller import RobustFollower
from integrations.connected_v2v.settling.controller import SettlingFollower
from integrations.connected_v2v.autonomy.test_controller import EGO, radio, scan
from integrations.connected_v2v.node import V2VEndpoint
from integrations.connected_v2v.robustness.perception import encode_peer_scan
from integrations.connected_v2v.settling.trace_certificate import certificate
import math
for name in ['peer-1','track-1']:
    n=V2VEndpoint(name); n.observe_local(EGO,0,0); c=SettlingFollower(n)
    if name=='peer-1': radio(n,'front',50.)
    else: c.observe_scan(scan(),0.)
    try: print('identity',name,c.decide(0)[0])
    except Exception as e: print('identity',name,type(e).__name__,str(e))
n=V2VEndpoint('follower',max_peers=2); c=SettlingFollower(n)
for i in range(3):
    t=i*3.; n.observe_local(EGO,t,t)
    c.observe_scan(scan(((50.,3.5),),now=t,sequence=i),t)
    print('track capacity',i,len(c.tracks),c.scan_fault)
n=V2VEndpoint('follower');c=SettlingFollower(n)
for t in [0.,.1,.15,.36,.37]:
    n.observe_local(EGO,t,t)
    if t==0.: radio(n,'leader',80.,now=t)
    if t==.1: radio(n,'intruder',50.,now=t)
    if t==.15: c.observe_scan(scan(((50.6,0.),),now=t,sequence=0),t)
    cmd,info=c.decide(t)
    print('confirmation',t,info['selected_observed_s'],info['confirmed_following_frames'],info['lateral_guard_mode'])
n=V2VEndpoint('follower'); c=SettlingFollower(n); n.observe_local(EGO,0.,0.)
radio(n,'head',25.); c.recovering=True
for _ in range(40):cmd,info=c.decide(0.)
print('zero elapsed settling',info['settled_ticks'],info['formation_mode'])
n=V2VEndpoint('follower');c=SettlingFollower(n)
radio(n,'observer',0.,speed=0.)
s=Scan(0,0.,(0.,0.,math.pi,0.,0.,0.),(Detection(30.,0.,0.),),False)
print('contradictory heading scan accepted',c.observe_peer_scan(encode_peer_scan('observer',s),0.))
print('negative duration certificate',certificate((0,0,0),(0,0,0),(0,2,0),(0,2,0),-.05))
