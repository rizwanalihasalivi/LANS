from pathlib import Path
import hashlib
import json
import shutil
import zipfile

REPO=Path('/workspace/LANS')
ROOT=REPO/'results/v2v-audit-20261104-v1'
OUT=REPO/'integrations/connected_v2v/evidence/audit-20261104'
LIMIT=32*1024*1024
CHUNK=160*1024*1024

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    OUT.mkdir(parents=True,exist_ok=False)
    shutil.copyfile(__file__,ROOT/'package_audit_evidence.py')
    files=[(p,str(p.relative_to(REPO))) for p in sorted(ROOT.rglob('*'))
           if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')
           and p.name!='historical-archive-verification.txt']
    for name in ('AUDIT.md','AUDIT_PROTOCOL.md'):
        p=REPO/'integrations/connected_v2v'/name
        files.append((p,'release-docs/'+str(p.relative_to(REPO))))
    inventory=[]
    def save(items):
        name=f'audit-{len(inventory)+1:03d}.zip';dest=OUT/name
        manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for p,n in items}
        assert len(manifest)==len(items) and manifest
        with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for p,n in items:z.write(p,n)
            z.writestr('MEMBER-SHA256.json',json.dumps(manifest,sort_keys=True,indent=2)+'\n')
        if dest.stat().st_size>=LIMIT:
            dest.unlink()
            if len(items)<2:raise RuntimeError('single archive member exceeds size budget')
            middle=len(items)//2;save(items[:middle]);save(items[middle:]);return
        record=dict(archive=name,bytes=dest.stat().st_size,sha256=sha(dest),members=len(items))
        inventory.append(record);print(json.dumps(record),flush=True)
    pending=[];size=0
    for p,name in files:
        if pending and size+p.stat().st_size>CHUNK:
            save(pending);pending=[];size=0
        pending.append((p,name));size+=p.stat().st_size
    if pending:save(pending)
    (OUT/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
    (OUT/'SHA256SUMS').write_text(''.join(f"{r['sha256']}  {r['archive']}\n" for r in inventory))
    lines=['# V2V audit evidence — 4–5 November 2026','',
        'Source, raw inputs, control and native motion traces, replay and independent',
        'scores for all 81 new 70-second runs are preserved. All 81 passed; 40 use',
        'fresh validation seeds. This is a regression cohort, not a real-world or',
        'universal safety proof. Comparative benchmarking remains on hold.', '',
        'The root is `results/v2v-audit-20261104-v1`. Its `source/` is the original',
        '115-file campaign snapshot. `post-campaign-verification-source/` separately',
        'records the later archive-verifier fix; the trial source plan was not rewritten.',
        'Includes 221-test results, regression failure evidence, 1-D/2-D SMT checks,',
        'six fresh continuous 2-D certificates, a development certificate, 128 historical',
        'native refinement rechecks, malformed-byte stress and both unreachable-range',
        'diagnostics (ordinary recovery failures with expected braking).', '',
        'Copy every ZIP, `SHA256SUMS` and `inventory.json` to one directory. Verify',
        'with the current hardened verifier before extracting into a NEW directory:', '',
        '```bash',
        'python -m integrations.connected_v2v.settling.package verify --output integrations/connected_v2v/evidence/audit-20261104 --extract /workspace/lans-setup/audit-extracted-new',
        '```', '',
        'The final old-archive integrity recheck is retained as the separate sidecar',
        '`historical-archive-verification.txt`; it is not part of the new raw campaign.',
        'New-archive integrity and isolated frozen-source replay reports are sidecars.', '',
        '| Archive | Bytes | Members |','|---|---:|---:|']
    lines += [f"| {r['archive']} | {r['bytes']} | {r['members']} |" for r in inventory]
    (OUT/'INDEX.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(archives=len(inventory),bytes=sum(r['bytes'] for r in inventory),members=sum(r['members'] for r in inventory))),flush=True)

if __name__=='__main__':main()
