from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import json
from integrations.connected_v2v.settling.certify import native_refinement, read, rows
ROOT=Path('/workspace/LANS')
OUTPUT=ROOT/'results/v2v-audit-20261104-v1/historical-native-refinement.json'
def check(path):
    try:
        spec=read(path/'config.json')
        report,_=native_refinement(path,spec,{name:rows(path/f'{name}.jsonl') for name in spec['starts']})
        return dict(path=str(path.relative_to(ROOT)),passed=True,actors=report)
    except Exception as error:
        return dict(path=str(path.relative_to(ROOT)),passed=False,error=repr(error))
if __name__=='__main__':
    paths=[]
    for stage in ('development','validation'):
        root=ROOT/'results/settling-native-v4'/stage
        records=read(root/'summary.json')['results']
        paths.extend(root/f"{r['case']}-{r['speed']:g}-{r['seed']}" for r in records)
    results=[]
    with ProcessPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(check,p) for p in paths]):
            r=future.result();results.append(r)
            if not r['passed'] or len(results)%16==0:print(json.dumps(dict(checked=len(results),last=r['path'],passed=r['passed'])),flush=True)
    summary=dict(passed=all(r['passed'] for r in results),episodes=len(results),results=sorted(results,key=lambda r:r['path']),scope='new boundary-sample qualification of historical unchanged native traces; no new physics executions')
    with OUTPUT.open('x') as stream:json.dump(summary,stream,indent=2)
    if not summary['passed']:raise SystemExit(1)
