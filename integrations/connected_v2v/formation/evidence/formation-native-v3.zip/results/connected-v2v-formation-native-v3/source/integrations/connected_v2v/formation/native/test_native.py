from .run import controller_source,prepare_native


def test_native_factorial_keeps_leader_cap_and_exposes_follower_recovery_cap(tmp_path):
    source=controller_source()
    assert 'FormationFollower as FusionFollower' in source
    assert 'following_for' in source and "os.environ['LANS_FORMATION_ADAPTER']" in source
    assert "8. if name == 'leader'" in source and 'else 16.' in source
    assert 'native_cap_m_s=native_cap' in source
    world=prepare_native(tmp_path/'world')
    assert world.read_text().count('name "local_radar"')==3
    assert 'getFromDef' not in source
