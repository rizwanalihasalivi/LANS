# Broader following and perception validation

Prepared before the new outcomes. This is a finite extension of autonomous
following, not final thesis benchmarking or a superiority experiment. Preserve
all prior controllers, archives and held-out data. Do not manufacture outstanding
results by changing thresholds, dropping seeds or hiding failures.

The follower receives only local native/simulated sensing, unlabeled radar
range/bearing/radial-speed and accepted V2V packets. The route is a known map.
NPC maneuvers are scripted; ego target switches are observation-driven. No traffic
truth, missed-target labels or scenario switch times may select the ego's target.

Fallible radar cannot prove departure by absence. The new controller must retain
an unseen predecessor and brake until reacquisition or three distinct positive
exit observations. Track memory may support identity reacquisition for <=2 s;
it must never refresh measurement timestamps or extend the 0.2/0.4 s radar/V2V
control TTL. Ambiguous association and capacity exhaustion brake. Requested
acceleration remains [-6,2.5] m/s²; steering/rate remain 0.5 rad / 0.6 rad/s.

Python uses the shared bicycle ego plant and declared kinematic NPC routes,
20 Hz control / 10 Hz radar/radio, 32 s episodes. Eight profiles: curved,
dense_curved, noisy_nonconnected, burst_misses, occlusion_brake, dual_blackout,
v2v_blackout and combined. Speeds: 8, 12, 16 m/s. Development seeds: 701, 709,
719 (72 trials). Conditional fresh validation seeds: 1009,1013,1019,1021,1031,
1033,1039,1049,1051,1061 (240 trials). Freeze source before validation. Development
seeds may diagnose defects; validation outcomes must not guide tuning on those
same seeds. A required fix invalidates promotion, preserves failures and needs a
new declared validation cohort. These are new trials, not old reserved campaigns.

Perception models include actual line-of-sight occlusion, shuffled anonymous
returns, Gaussian range/bearing/rate noise, independent misses, a 1 s burst,
measurement latency with original source stamps, plus communication loss/jitter/
duplicates and 1.5 s blackouts. Miss decisions are not a health oracle supplied
to the controller. Noise/miss severity is fixed in the profile source before runs.
Unknown coverage is always marked incomplete for departure inference.

Native Webots uses a physically bounded curved/straight two-lane road ribbon,
real Radar/GPS/IMU/Gyro and Emitter/Receiver, measured body lateral velocity and
Webots physics. Six profiles (all except v2v_blackout and combined), 35 s.
Development: speed 8, seeds 811,821 (12 trials). Conditional validation: speeds
8,12, seeds 2003,2011,2017 (36 trials), with frozen sources. Dense profiles use
eight native Cars, including non-connected vehicles; others use three. Native
occlusion is enabled. Misses and latency are applied to actual anonymous returns,
not synthetic observations of another robot. Retain raw and adapted sensor data.

Required checks: complete expected tick/sample counts; replay accepted inputs,
target changes, source ages and commands; source/world/controller hashes; no
sampled oriented-box overlap (ALL vehicle pairs, not just ego), road/pose or
requested-bound violations, no stale-source use, max braking when uncertain.
Also require meaningful progress (>25 m and >=40% of cruise distance), intervening-vehicle
acquisition and return to the front vehicle in fixed stable windows. Report speed,
gap, censoring, progress, fallback and recovery observations per run. A safe stop
without demonstrated recovery is not a complete pass.

Use at most three independent Python worker processes / two Webots processes
on the five-CPU machine. Each has unique outputs, RNGs and Xvfb display. No output
overwrite or interrupted partial reuse. Log and retain failed/invalid trials.
Native evaluation is conditional on all Python development checks passing.
Native validation additionally requires native development and Python validation.
Recompute evidence with an independent stdlib scorer and negative tamper checks.
Archive raw data, source, protocols and checksums before Git commit/push.

This does not validate a learned perception stack, arbitrary geometry or all
possible incursions. Unobservable hidden traffic can require an indefinite safe
stop; no algorithm can infer its departure from silence alone. Publication of the
cloud snapshot remains a product UI action. Final thesis comparison stays on hold.
