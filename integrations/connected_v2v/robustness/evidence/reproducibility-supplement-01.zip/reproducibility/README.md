# Reproducibility supplement

The shared native GPS/body-velocity converter was present throughout execution and pinned by the earlier autonomy native source freeze. It was omitted from the newer explicit dependency list. This archive supplies the byte-identical pre-study file in each extracted source tree. Existing experiment manifests and outcomes are unchanged. dependency.json and prior-native-plan.json show the prior pin. Full Git checkouts already contain the file.
