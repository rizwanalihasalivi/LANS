# Evidence/source status

Setup-only attempt; no simulation launched. Retained error does not belong to any trial denominator.
