# Failed actuator probe retained

Applying brake intensity while retaining SPEED mode did not resolve the exposed
8m/s8011 case. Raw poses first overlap at8.8s; subsequent intruder yaw violates
the heading gate. This is a collision failure, not an invalid-fixture exclusion.
The other three probes pass their gates and continuous certificates. The pinned
Car.proto shows velocity-motor acceleration/deceleration limited by time0To100=10s
(2.7778m/s2), with large motor torque enforcing the ramp. The next candidate
bypasses SPEED mode during emergency via zero-throttle TORQUE mode and friction
braking, with a0.3s release hold. Old sources/raw records stay unchanged.
