from pathlib import Path
import json
import shutil
import sys
sys.path.insert(0,'/workspace/LANS')
from integrations.connected_v2v.settling.native import run_one
from integrations.connected_v2v.settling.study import runtime_files,freeze,verify_sources
from integrations.connected_v2v.settling.audit import check_native_episode
from integrations.connected_v2v.settling.certify import episode
p=Path('/workspace/LANS/results/settling-native-brake-probe-v2');p.mkdir(exist_ok=False)
b=Path('/workspace/LANS/integrations/connected_v2v/settling')
files=[*runtime_files(),*[b/(n+'.py') for n in ('native','native_vehicle','world')],b/'NATIVE_PROTOCOL_V3.md']
hashes=freeze(p,files);(p/'sources.json').write_text(json.dumps(hashes,indent=2)+'\n');shutil.copyfile(__file__,p/'workflow.py')
results=[]
for case,speed,seed in [('noisy_nonconnected',8.,8011),('noisy_nonconnected',12.,2003),('curved',12.,6203),('combined',12.,8011)]:
    path=p/f'{case}-{speed:g}-{seed}';r=run_one((str(path),case,speed,seed));print(json.dumps(r),flush=True)
    if r['passed']:
        assert check_native_episode(path,r)['passed']
        c=episode(path,p/(path.name+'-certificate'),native=True);assert c['passed']
    results.append(r)
verify_sources(hashes)
(p/'summary.json').write_text(json.dumps(dict(passed=all(r['passed'] for r in results),results=results),indent=2)+'\n')
assert all(r['passed'] for r in results)
