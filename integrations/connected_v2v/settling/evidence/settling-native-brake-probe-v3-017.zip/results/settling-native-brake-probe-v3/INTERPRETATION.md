# Torque-mode probe retained

The exposed8m/s8011 case passes with no collision, but the older2003case fails
spacing/recovery and curved/high-density probes violate native pose/heading or
performance gates. This candidate is not accepted. All raw/source remain. The
replacement preserves SPEED-mode stability and instead plans earlier braking
from the actual2.8m/s2 plant response, using2.5m/s2 reserve and0.8s allowance.
