# Evidence/source status

Execution source snapshot was captured for this campaign/probe. Verify its declared hashes.
