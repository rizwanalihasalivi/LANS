from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import json
import shutil
import sys
import traceback
sys.path.insert(0,'/workspace/LANS')
from integrations.connected_v2v.settling.native import run_one
from integrations.connected_v2v.settling.study import runtime_files,freeze,verify_sources
from integrations.connected_v2v.settling.audit import check_native_episode
from integrations.connected_v2v.settling.certify import episode

ROOT=Path('/workspace/LANS/results/settling-native-envelope-probe-v1')

def probe(job):
    case,speed,seed=job;path=ROOT/f'{case}-{speed:g}-{seed}'
    try:
        result=run_one((str(path),case,speed,seed))
        report=dict(case=case,speed=speed,seed=seed,result=result,passed=result['passed'])
        if result['passed']:
            report['audit']=check_native_episode(path,result)
            report['certificate']=episode(path,ROOT/(path.name+'-certificate'),native=True)
            report['passed']=report['audit']['passed'] and report['certificate']['passed']
        return report
    except Exception:
        return dict(case=case,speed=speed,seed=seed,passed=False,error=traceback.format_exc())

if __name__=='__main__':
    ROOT.mkdir(exist_ok=False);b=Path('/workspace/LANS/integrations/connected_v2v/settling')
    files=[*runtime_files(),*[b/(n+'.py') for n in ('native','native_vehicle','world')],b/'NATIVE_PROTOCOL_V4.md']
    hashes=freeze(ROOT,files);(ROOT/'sources.json').write_text(json.dumps(hashes,indent=2)+'\n')
    shutil.copyfile(__file__,ROOT/'workflow.py')
    jobs=[('combined',12.,12037),('noisy_nonconnected',8.,8011),('noisy_nonconnected',12.,2003),('curved',12.,6203),('combined',12.,8011)]
    results=[]
    with ProcessPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(probe,j) for j in jobs]):
            r=future.result();results.append(r);print(json.dumps(r),flush=True)
    verify_sources(hashes)
    (ROOT/'summary.json').write_text(json.dumps(dict(passed=all(r['passed'] for r in results),results=results),indent=2)+'\n')
    assert all(r['passed'] for r in results)
