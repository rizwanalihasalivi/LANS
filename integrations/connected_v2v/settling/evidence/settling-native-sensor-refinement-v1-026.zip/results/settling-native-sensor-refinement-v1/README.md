# Pinned native Radar angular clipping semantics

Official source: https://github.com/cyberbotics/webots/blob/R2025a/src/webots/nodes/WbRadar.cpp#L500
Official documentation: https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/radar.md

Retrieved4November2026. SHA256 values are in sources.json. The implementation
clamps center azimuth to the physical aperture when only part of a body lies in
the frustum, then adds angular noise. A clipped return is not a center-bearing
measurement. The new adapter rejects the outer0.33..0.35rad fringe, matching the
Python model central aperture. Raw returns remain; rejected returns are unknown,
not clear road. This is an input-refinement/visibility limit, not a deterministic
bound on Gaussian noise. The physical Radar configuration is unchanged.

The inspected Cyberbotics source files retain their original copyright/license
headers; the Apache2.0 license text is included alongside them.
