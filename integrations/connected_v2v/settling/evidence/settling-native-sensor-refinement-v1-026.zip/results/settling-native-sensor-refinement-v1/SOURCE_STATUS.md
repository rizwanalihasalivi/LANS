# Evidence/source status

Pinned official R2025a reference sources for actuator/Radar semantics; hashes, URLs and licenses retained. No ordinary trial belongs here.
