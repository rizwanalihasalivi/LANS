# Evidence/source status

Execution source snapshot was captured for this campaign/probe. Verify its declared hashes.
This root has an ABORTED/PARTIAL marker. Read its scope; do not count failed or unfinished trials as successful confirmation.
