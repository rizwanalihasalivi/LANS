# Rejected high-speed native recovery

The frozen80-run campaign has79 passing trials and this failure. Verification
first rejects heading error-0.30245rad at35.95s; later raw data shows680center-
corridor violations and formation failure. Independent diagnostic scoring finds
no sampledvehicle-envelope overlaps. This is a controller/plant correspondence
failure, not an invalid fixture or a pass. Near34–35s actual speed18.5–18.75m/s
produces growing steering oscillation. Preserve all raw/source and original failed
summary. The replacement candidate will enforce a16m/s native recovery cap and
qualify actualspeed≤16.5, retaining the original heading/lane gates.
