"""Known old 150m failure; a regression, never a fresh validation trial."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
sys.path.insert(0,'/workspace/LANS')
from integrations.connected_v2v.settling.native import run_one
from integrations.connected_v2v.settling.study import verify_sources
from integrations.connected_v2v.settling.audit import check_native_episode,score,rows
from integrations.connected_v2v.settling.certify import episode

base=Path('/workspace/LANS');root=base/'results/settling-original150-regression-v2'
root.mkdir(parents=True,exist_ok=False)
plan=json.loads((base/'results/settling-native-v3/plan.json').read_text());verify_sources(plan['sources'])
for name,digest in plan['sources'].items():
    source=base/name;target=root/'source'/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target);assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
shutil.copyfile(__file__,root/'workflow.py')
details=dict(classification='EXPOSED_OLD_FAILURE_REGRESSION_NOT_FRESH',case='noisy_nonconnected',speed=12.,seed=2003,
    seconds=70.,radio_range_m=150.,sources=plan['sources'],
    original='results/robustness-native-v2/validation/noisy_nonconnected-12-2003',
    note='New architecture and70s horizon. Original35s result remains failed; no matched causal percentage is inferred.')
(root/'plan.json').write_text(json.dumps(details,indent=2)+'\n')
path=root/'noisy_nonconnected-12-2003'
result=run_one((str(path),'noisy_nonconnected',12.,2003))
assert result['passed'],result
audit=check_native_episode(path,result);assert audit['passed']
certificate=episode(path,root/'certificate',native=True);assert certificate['passed']
spec=json.loads((path/'config.json').read_text());traces={n:rows(path/f'{n}.jsonl') for n in spec['starts']}
prefix=[]
for i,row in enumerate(traces['follower']):
    if row['time_s']>35.+1e-8:break
    traffic={n:v[i]['state'] for n,v in traces.items() if n!='follower'}
    prefix.append(dict(time_s=row['time_s'],before=row['state'],after=row['state'],
        traffic_before=traffic,traffic_after=traffic,command=row['command'],decision=row['decision']))
scored=score(prefix,spec['profile']['radius'],12.,True)
assert not scored['stable_return_censored'],'Old-horizon stable return not demonstrated'
verify_sources(plan['sources'])
report=dict(passed=True,classification=details['classification'],new_70s_result=result,
    independent_audit=audit,continuous_certificate=certificate,
    original_35s_prefix=dict(ticks=len(prefix),stable_return_2s_s=scored['stable_return_2s_s'],
        stable_return_censored=scored['stable_return_censored'],longest_correct_run_s=scored['longest_correct_run_s'],
        recovered_leader_ticks=scored['recovered_leader_ticks'],collisions=scored['collisions']),
    note=details['note'])
(root/'regression.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
