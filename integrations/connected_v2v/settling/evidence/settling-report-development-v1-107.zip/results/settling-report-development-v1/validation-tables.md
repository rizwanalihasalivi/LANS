# Formation validation: strict gates and complete ranges

| Cohort | Profile | Trials | Tail RMS median / max (m) | Tail max error (m) | Settling-onset max delay (s) | Min fresh correct fraction |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Python | Curved | 9 | 0.013922 / 0.020598 | 0.062216 | 11.50 | 1.000 |
| Python | Dense curved | 9 | 0.014469 / 0.027901 | 0.059229 | 12.30 | 1.000 |
| Python | Noisy non-connected | 9 | 0.012799 / 0.025051 | 0.069037 | 14.10 | 1.000 |
| Python | Burst misses | 9 | 0.015786 / 0.025860 | 0.056011 | 14.35 | 1.000 |
| Python | Occlusion + brake | 9 | 0.014699 / 0.027449 | 0.060435 | 15.30 | 1.000 |
| Python | Dual blackout | 9 | 0.018466 / 0.024416 | 0.057726 | 11.75 | 1.000 |
| Python | V2V blackout | 9 | 0.015519 / 0.026461 | 0.054653 | 11.95 | 1.000 |
| Python | Combined | 9 | 0.006745 / 0.022263 | 0.061524 | 33.25 | 1.000 |
| Webots | Curved | 2 | 0.056789 / 0.061923 | 0.107882 | 11.90 | 1.000 |
| Webots | Dense curved | 2 | 0.035635 / 0.038850 | 0.105349 | 12.85 | 1.000 |
| Webots | Noisy non-connected | 2 | 0.037142 / 0.044144 | 0.092949 | 17.35 | 1.000 |
| Webots | Burst misses | 2 | 0.036777 / 0.041529 | 0.086845 | 12.85 | 1.000 |
| Webots | Occlusion + brake | 2 | 0.035903 / 0.042410 | 0.082267 | 14.75 | 1.000 |
| Webots | Dual blackout | 2 | 0.030342 / 0.032378 | 0.070551 | 12.05 | 1.000 |
| Webots | V2V blackout | 2 | 0.036426 / 0.043301 | 0.098003 | 11.90 | 1.000 |
| Webots | Combined | 2 | 0.043657 / 0.048465 | 0.123541 | 14.35 | 1.000 |

Settling delay is the start of a continuous2 s confirmation window after cut-out.
Tail metrics use the final5 s; whole-window correct-target RMS is a different measure.
No causal percentage improvement over earlier32/35 s fixtures is inferred.
