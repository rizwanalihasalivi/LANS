# Formation validation: strict gates and complete ranges

| Cohort | Profile | Trials | Tail RMS median / max (m) | Tail max error (m) | Settling-onset max delay (s) | Min fresh correct fraction |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Python | Curved | 30 | 0.013568 / 0.023804 | 0.046417 | 11.10 | 1.000 |
| Python | Dense curved | 30 | 0.013500 / 0.028753 | 0.048978 | 11.40 | 1.000 |
| Python | Noisy non-connected | 30 | 0.012532 / 0.030126 | 0.083661 | 16.25 | 1.000 |
| Python | Burst misses | 30 | 0.015153 / 0.035396 | 0.070885 | 12.20 | 1.000 |
| Python | Occlusion + brake | 30 | 0.013440 / 0.019873 | 0.047382 | 12.10 | 1.000 |
| Python | Dual blackout | 30 | 0.013211 / 0.023716 | 0.058424 | 11.10 | 1.000 |
| Python | V2V blackout | 30 | 0.014634 / 0.027674 | 0.050512 | 11.10 | 1.000 |
| Python | Combined | 30 | 0.007323 / 0.018942 | 0.050344 | 18.70 | 1.000 |
| Webots | Curved | 10 | 0.064763 / 0.097552 | 0.160940 | 14.20 | 1.000 |
| Webots | Dense curved | 10 | 0.055870 / 0.091651 | 0.183719 | 15.25 | 1.000 |
| Webots | Noisy non-connected | 10 | 0.055031 / 0.095631 | 0.165475 | 25.70 | 1.000 |
| Webots | Burst misses | 10 | 0.063484 / 0.084935 | 0.144833 | 14.70 | 1.000 |
| Webots | Occlusion + brake | 10 | 0.072045 / 0.087548 | 0.156603 | 19.15 | 1.000 |
| Webots | Dual blackout | 10 | 0.066034 / 0.085752 | 0.157663 | 13.90 | 1.000 |
| Webots | V2V blackout | 10 | 0.072398 / 0.090490 | 0.207090 | 14.00 | 1.000 |
| Webots | Combined | 10 | 0.046871 / 0.095243 | 0.166179 | 28.15 | 1.000 |

Settling delay is the start of a continuous2 s confirmation window after cut-out.
Tail metrics use the final5 s; whole-window correct-target RMS is a different measure.
No causal percentage improvement over earlier32/35 s fixtures is inferred.
