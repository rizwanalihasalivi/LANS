# Predeclared settling, 150 m and continuous 2-D trace study

Date: 4 November 2026 (Asia/Shanghai). Parent `164938e9`. This is a new integrated
development/validation cycle; prior source/evidence remains frozen. Final thesis
benchmarking and published-controller comparisons remain on hold.

## Changes and exploratory failures retained

An exploratory always-narrow lateral guard produced cut-in collisions and failed
all eight Python probes; native noisy/non-connected recovery also lost its path.
Those unfrozen exploratory traces remain in settling-probe-v1 and
settling-native-probe-v1. They are failures, not final evidence. The v2 exploratory
policy passed eight Python and two native probes, before the stronger final gates.

The final candidate keeps conservative approach guarding, enters lane-aware
catch-up only on distinct positive exit observations, and exits recovery after
two seconds of observed spacing/speed settling. A newly detected cut-in restores
the normal conservative mode. The lane-aware preview is 0.6 s with a declared
3 m/s² lateral uncertainty allowance; it is not a guarantee against arbitrary
inadmissible hidden intrusions. Steering uses route-normal errors on full circular
arcs rather than a short forward-Cartesian road graph.

Leader pacing is causal: own state plus received member beacons, never simulator
truth. At a member gap above80 m, reduce goal by at most2 m/s; missing beacons use
the same bounded reduction. No time/target-script trigger is supplied to ego.
The initial head/intruder geometry and all noise/loss/maneuvers remain as previously
defined; the leader now has actual closed-loop pacing dynamics. Python traffic
replay reconstructs those dynamics from the accepted message stream. Native NPCs
use their own sensors. Pacing is part of the new architecture, not an isolated
guard-performance attribution.

## Frozen cohorts and gates

- All runs70 s, 20 Hz control. Python:8 profiles×speeds8/12/16×development seeds
  6101,6113,6121 =72. Fresh seeds7001,7013,7019,7027,7039,7043,7057,7069,7079,7103
  give240. Native:all8 profiles (now also V2V-blackout and combined); development
  speed8,seeds6203/6211 =16; fresh speeds8/12,seeds8009,8011,8017,8039,8053 =80.
- Radio remains150 m in Python links, native Emitter configuration and runtime
  setRange. No300 m adapter is used. Native curved radius600 m, Python800 m.
  The physical road is extended to station1500 m for long-horizon validity.
- Original safety/freshness/requested-bound/lane gates remain. Require at least
  60% cruise-distance progress, correct fresh intruder samples, a continuous2 s
  correct head return after exit, and continuous2 s settling by60 s elapsed.
- During the final5 s:headway-error RMS≤2 m,max absolute≤5 m; relative-speed
  RMS≤0.5 m/s; correct fresh head association≥95%; leader cruise-speed RMS≤0.5 m/s.
  The last condition prevents passing by permanently slowing the whole formation.
- Correct radio-derived identity must agree with the physical head; geometry is
  checked independently. Original timestamps, source TTLs(.2 radar/.4 radio),
  replay/duplicate semantics and uncertainty are never refreshed by mode changes.
- Python validation opens only after Python development passes and source hashes
  match. Native validation additionally requires both development gates and Python
  validation. If a runtime change is needed after opening validation, use new
  development roots and new fresh seeds. Preserve all failures.

## Operating limits and proof scope

150 m is a direct-link model range, not an RF guarantee. Recovery requires an
actual fresh radar/radio path; pacing only improves the chance of retaining it.
Separate deliberately unreachable Python/native diagnostics must retain the failed
recovery classification and demonstrate braking with no invented target. They are
not included as ordinary recovery successes.

The new broader proof is **a posteriori continuous 2-D trajectory certification**,
not a prospective full-source controller-invariance theorem. Under endpoint-pose/
body bounds, coordinate acceleration≤20 m/s² and yaw rate≤2 rad/s, a separating-axis
bridge inequality proves disjoint footprints throughout each logged interval.
Fixed-point interval Taylor sin/cos and exact rational/integer comparisons avoid
optimistic floating collision thresholds. SMT checks the algebraic implications;
the continuous bridge/rotation lemmas are analytical. Native10 ms motion logging
qualifies measured refinement premises separately from commanded acceleration.
It does not establish unmeasured physical bounds or certify every future behavior.

Association is checked as a separate observation/identity property; the finite
physics certificate includes every actual actor and therefore does not rely on
an ego target label for collision scoring. This use of truth is post-control only.
Gaussian errors remain empirical inputs; no deterministic Gaussian-error guarantee,
hardware, real-time, comfort or string-stability claim is made.
