; benchmark generated from python API
(set-info :status unknown)
(declare-fun rb () Real)
(declare-fun ra () Real)
(declare-fun l () Real)
(declare-fun c () Real)
(assert
 (let ((?x28 (+ ra rb)))
 (> l ?x28)))
(assert
 (>= ra 0.0))
(assert
 (>= rb 0.0))
(assert
 (let (($x41 (not (and (<= c ra) (>= c (- l rb))))))
(not $x41)))
(check-sat)
