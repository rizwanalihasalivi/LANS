; benchmark generated from python API
(set-info :status unknown)
(declare-fun ra () Real)
(declare-fun rb () Real)
(declare-fun pad () Real)
(declare-fun l () Real)
(declare-fun eb () Real)
(declare-fun ea () Real)
(assert
 (>= ra 0.0))
(assert
 (>= rb 0.0))
(assert
 (>= pad 0.0))
(assert
 (> l (+ (+ ra rb) pad)))
(assert
 (<= (+ ea eb) pad))
(assert
 (let ((?x28 (+ ra rb)))
(let (($x35 (> (- (- l ea) eb) ?x28)))
(not $x35))))
(check-sat)
