; benchmark generated from python API
(set-info :status unknown)
(declare-fun q () Real)
(declare-fun c () Real)
(declare-fun l () Real)
(declare-fun r () Real)
(assert
 (>= q 0.0))
(assert
 (<= q 1.0))
(assert
 (> l c))
(assert
 (> r c))
(assert
 (let (($x24 (> (+ (* (- 1.0 q) l) (* q r)) c)))
(not $x24)))
(check-sat)
