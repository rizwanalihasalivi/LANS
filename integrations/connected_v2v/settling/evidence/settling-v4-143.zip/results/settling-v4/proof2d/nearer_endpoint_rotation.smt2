; benchmark generated from python API
(set-info :status unknown)
(declare-fun q () Real)
(assert
 (>= q 0.0))
(assert
 (<= q 1.0))
(assert
 (let (($x48 (>= (/ 1.0 2.0) (ite (>= (/ 1.0 2.0) q) q (- 1.0 q)))))
(not $x48)))
(check-sat)
