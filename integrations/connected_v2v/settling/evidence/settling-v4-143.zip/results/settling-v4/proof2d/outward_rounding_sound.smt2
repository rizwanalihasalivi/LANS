; benchmark generated from python API
(set-info :status unknown)
(declare-fun r () Real)
(declare-fun l () Real)
(declare-fun ra () Real)
(declare-fun c () Real)
(assert
 (<= l r))
(assert
 (>= c ra))
(assert
 (> l c))
(assert
 (let (($x44 (> r ra)))
(not $x44)))
(check-sat)
