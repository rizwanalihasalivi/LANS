; benchmark generated from python API
(set-info :status unknown)
(declare-fun l () Real)
(declare-fun ea () Real)
(declare-fun r () Real)
(declare-fun eb () Real)
(assert
 (>= ea l))
(assert
 (<= eb r))
(assert
 (> l r))
(assert
 (let (($x52 (> ea eb)))
(not $x52)))
(check-sat)
