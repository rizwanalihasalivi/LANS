# Evidence/source status

Analysis/report artifact. Scope and input/source references are in its reports and the final ledger.
This root has an ABORTED/PARTIAL marker. Read its scope; do not count failed or unfinished trials as successful confirmation.
