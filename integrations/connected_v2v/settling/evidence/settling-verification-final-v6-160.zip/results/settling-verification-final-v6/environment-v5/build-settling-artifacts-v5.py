"""Build final review artifacts only after the full verification workflow passes."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

base=Path('/workspace/LANS');os.chdir(base);sys.path.insert(0,str(base))
os.environ['MPLCONFIGDIR']=str(base/'.matplotlib-cache')
os.environ['XDG_CACHE_HOME']='/workspace/lans-setup/cache'
checks=base/'results/settling-verification-final-v6'
pipeline=Path('/workspace/settling-final-pipeline-v8.log')
while True:
    if (checks/'checks.json').exists():
        state=json.loads((checks/'checks.json').read_text())
        assert state['passed'],'A campaign gate failed; do not build final artifacts'
        if state['checks'][-1]['label']=='final-report' and 'ALL FINAL GATES COMPLETED' in pipeline.read_text():break
    time.sleep(5)
print('All gates complete; capturing environment and histories',flush=True)
history=checks/'captured-logs-v5';history.mkdir(exist_ok=False)
for p in sorted(Path('/workspace').glob('settling-*')):
    if p.is_file() and p.suffix in ('.log','.json','.err') and p.name!='settling-final-artifacts-v3.log':
        shutil.copyfile(p,history/p.name)
environment=checks/'environment-v5';environment.mkdir(exist_ok=False)
for name in ('env.sh','install-conditional.sh','run-settling-final-v4.py','run-settling-final-v5.py','run-settling-final-v6.py','run-settling-final-v7.py','run-settling-final-v8.py','run-original150-regression-v3.py','build-settling-artifacts-v5.py'):
    shutil.copyfile(Path('/workspace/lans-setup')/name,environment/name)
with (environment/'packages.json').open('x') as log:
    subprocess.run(['uv','pip','list','--python',sys.executable,'--format','json'],stdout=log,check=True)
modules={name:importlib.import_module(name).__version__ for name in ('numpy','scipy','matplotlib','mpmath')}
import z3
modules['z3-solver']=z3.get_version_string()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip()
(environment/'runtime.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform(),
    compiler=platform.python_compiler(),versions=modules,parent_git_head=head,branch=branch,
    webots='R2025a; native launcher verified pinned archive/PROTO hashes',
    cpu_quota=Path('/sys/fs/cgroup/cpu.max').read_text().strip(),
    note='Experiment snapshots and hashes identify uncommitted execution source. Final Git commit is created after artifact review.'),indent=2)+'\n')
thesis=base/'docs/thesis/lans-v2v-completion-v1'
subprocess.run([sys.executable,'-m','integrations.connected_v2v.settling.manuscript','--output',str(thesis)],check=True)
print('Thesis rendered; capturing later analysis source separately from execution snapshots',flush=True)
analysis=base/'integrations/connected_v2v/settling'
for value in ('settling-v4','settling-native-v4'):
    dest=base/'results'/value/'analysis-source';dest.mkdir(exist_ok=False)
    manifest={}
    for p in sorted(analysis.iterdir()):
        if p.is_file() and p.suffix in ('.py','.md','.txt'):
            shutil.copyfile(p,dest/p.name);manifest[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
    (dest/'ANALYSIS-SHA256.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
roots=sorted(p for p in (base/'results').glob('settling-*') if p.is_dir())
for root in roots:
    if (root/'plan.json').exists():
        plan=json.loads((root/'plan.json').read_text())
        frozen='sources' in plan and (root/'source').is_dir()
    else:frozen=(root/'sources.json').exists() and (root/'source').is_dir()
    if root.name=='settling-native-sensor-refinement-v1':
        text='Pinned official R2025a reference sources for actuator/Radar semantics; hashes, URLs and licenses retained. No ordinary trial belongs here.\n'
    elif (root/'SETUP_ERROR.txt').exists():
        text='Setup-only attempt; no simulation launched. Retained error does not belong to any trial denominator.\n'
    elif frozen:
        text='Execution source snapshot was captured for this campaign/probe. Verify its declared hashes.\n'
    elif 'cert' in root.name or 'report' in root.name or 'verification' in root.name or 'proof' in root.name:
        text='Analysis/report artifact. Scope and input/source references are in its reports and the final ledger.\n'
    else:
        text=('Exploratory/diagnostic history: no complete contemporaneous execution-source closure was captured here.\n'
              'Native generated adapter/world files, where present, retain their actual bytes. Do not infer\n'
              'exact full-source reproduction from a later snapshot. Final campaign code/data are separate.\n')
    if (root/'ABORTED.json').exists() or any(root.glob('*/ABORTED.json')):
        text+='This root has an ABORTED/PARTIAL marker. Read its scope; do not count failed or unfinished trials as successful confirmation.\n'
    (root/'SOURCE_STATUS.md').write_text('# Evidence/source status\n\n'+text)
output=analysis/'evidence'
from integrations.connected_v2v.settling.package import pack
print('Packing',len(roots),'result roots',flush=True)
print(json.dumps(pack(output,roots,thesis),indent=2),flush=True)
from integrations.connected_v2v.settling.release_checks import run
print('Verifying every archive/member and isolated extracted-source replays',flush=True)
verification=Path('/workspace/lans-setup/settling-release-checks-v1')
summary=run(output,'/workspace/lans-setup/settling-extracted-v1',verification)
shutil.copytree(verification,output/'verification')
with (output/'INDEX.md').open('a') as f:
    f.write('\nAll archives passed outer/member SHA-256 and CRC verification. Extracted raw evidence\n'
            'passed both complete independent audits, all strict integer witness inventories,\n'
            'and four isolated frozen-source control/geometry replays. Native replay does\n'
            'not rerun Webots physics. See [verification summary](verification/summary.json).\n')
print(json.dumps(summary,indent=2),flush=True)
print('FINAL ARTIFACTS READY FOR REVIEW',flush=True)
