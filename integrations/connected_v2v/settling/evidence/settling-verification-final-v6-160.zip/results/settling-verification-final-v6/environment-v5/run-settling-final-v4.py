"""Sequential gates; failed evidence is retained and no cohort is resumed."""
import json
from pathlib import Path
import subprocess
import sys
import time

base=Path('/workspace/LANS')
out=base/'results/settling-verification-final-v2'
out.mkdir(parents=True,exist_ok=False)
checks=[]

def run(label,args):
    print('START',label,flush=True)
    start=time.time()
    with (out/(label+'.txt')).open('x') as log:
        status=subprocess.run(args,cwd=base,stdout=log,stderr=subprocess.STDOUT).returncode
    checks.append(dict(label=label,returncode=status,seconds=time.time()-start,command=args))
    (out/'checks.json').write_text(json.dumps(dict(passed=all(c['returncode']==0 for c in checks),checks=checks),indent=2)+'\n')
    print('DONE',label,status,flush=True)
    if status:raise SystemExit(label+' failed; evidence preserved')

def module(label,name,*args):run(label,[sys.executable,'-m','integrations.connected_v2v.settling.'+name,*args])

p=base/'results/settling-v4/development/summary.json'
while not p.exists():time.sleep(5)
assert json.loads(p.read_text())['passed'],'Python development failed; validation remains closed'
run('full-tests',[sys.executable,'-m','pytest','-q','integrations/connected_v2v'])
module('native-development','native','--python','results/settling-v4','--output','results/settling-native-v2','--stage','development')
module('python-development-audit','audit','results/settling-v4','--stage','development')
module('native-development-audit','audit','results/settling-native-v2','--native','--stage','development')
module('python-development-inputs','verify_inputs','results/settling-v4','--stage','development')
module('python-development-certificates','certify','results/settling-v4','--stage','development','--output','results/settling-cert-python-dev-v4')
module('native-development-certificates','certify','results/settling-native-v2','--native','--stage','development','--output','results/settling-cert-native-dev-v2')
module('negative-controls','negative_checks','--python','results/settling-v4','--native','results/settling-native-v2')
module('unreachable-python','diagnostics','--output','results/settling-unreachable-python-v2')
module('unreachable-native','diagnostics','--native','--output','results/settling-unreachable-native-v2')
run('exported-smt-replay',[sys.executable,'-c',
    "from pathlib import Path;import z3,json;p=Path('results/settling-v4/proof2d');r={};"+
    "\nfor f in sorted(p.glob('*.smt2')):\n s=z3.Solver();s.from_file(str(f));r[f.name]=str(s.check())\n"+
    "assert len(r)==6 and set(r.values())=={'unsat'};print(json.dumps(dict(passed=True,solver=z3.get_version_string(),results=r),indent=2))"])
print('ALL DEVELOPMENT CHECKS PASSED; OPENING NEW PYTHON VALIDATION SEEDS',flush=True)
module('python-validation','study','--output','results/settling-v4','--stage','validation')
module('native-validation','native','--python','results/settling-v4','--output','results/settling-native-v2','--stage','validation')
module('python-final-audit','audit','results/settling-v4')
module('native-final-audit','audit','results/settling-native-v2','--native')
module('python-validation-inputs','verify_inputs','results/settling-v4','--stage','validation')
module('python-validation-certificates','certify','results/settling-v4','--stage','validation','--output','results/settling-cert-python-validation-v4')
module('native-validation-certificates','certify','results/settling-native-v2','--native','--stage','validation','--output','results/settling-cert-native-validation-v2')
module('final-report','report','--python','results/settling-v4','--native','results/settling-native-v2','--output','results/settling-report-final-v2')
print('ALL FINAL GATES COMPLETED',flush=True)
