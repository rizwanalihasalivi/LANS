"""Final native campaign after measured-capacity and Radar input refinements."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

base=Path('/workspace/LANS');sys.path.insert(0,str(base))
from integrations.connected_v2v.settling.study import verify_sources
out=base/'results/settling-verification-final-v4';out.mkdir(parents=True,exist_ok=False)
checks=[]

def record(item):
    checks.append(item)
    (out/'checks.json').write_text(json.dumps(dict(passed=all(c['returncode']==0 for c in checks),checks=checks),indent=2)+'\n')

def run(label,args):
    print('START',label,flush=True);start=time.time()
    with (out/(label+'.txt')).open('x') as log:
        status=subprocess.run(args,cwd=base,stdout=log,stderr=subprocess.STDOUT).returncode
    record(dict(label=label,returncode=status,seconds=time.time()-start,command=args))
    print('DONE',label,status,flush=True)
    if status:raise RuntimeError(label+' failed; evidence retained')

def module(label,name,*args):run(label,[sys.executable,'-m','integrations.connected_v2v.settling.'+name,*args])

plan=json.loads((base/'results/settling-v4/plan.json').read_text());verify_sources(plan['sources'])
for stage,n in [('development',96),('validation',240)]:
    s=json.loads((base/f'results/settling-v4/{stage}/summary.json').read_text());assert s['passed'] and len(s['results'])==n
probe=json.loads((base/'results/settling-native-brake-probe-v6/summary.json').read_text());assert probe['passed']
verify_sources(json.loads((base/'results/settling-native-brake-probe-v6/sources.json').read_text()))
(out/'reused-python-checkpoint.json').write_text(json.dumps(dict(common_sources_unchanged=True,
    source_files=len(plan['sources']),development=96,validation=240,
    plan_sha256=hashlib.sha256((base/'results/settling-v4/plan.json').read_bytes()).hexdigest(),
    prior_development_audit='results/settling-verification-final-v2/python-development-audit.txt',
    prior_development_inputs='results/settling-verification-final-v2/python-development-inputs.txt',
    prior_development_certificates='results/settling-cert-python-dev-v4',
    reason='Only native adapter/protocol files changed, outside the frozen33-file Python runtime.'),indent=2)+'\n')
run('full-tests',[sys.executable,'-m','pytest','-q','integrations/connected_v2v'])
module('native-development','native','--python','results/settling-v4','--output','results/settling-native-v3','--stage','development')
module('native-development-audit','audit','results/settling-native-v3','--native','--stage','development')
module('native-development-certificates','certify','results/settling-native-v3','--native','--stage','development','--output','results/settling-cert-native-dev-v3')
print('Waiting for independent common-Python checks already running',flush=True)
while True:
    p=base/'results/settling-verification-final-v3/checks.json'
    try:state=json.loads(p.read_text())
    except (FileNotFoundError,json.JSONDecodeError):time.sleep(2);continue
    assert state['passed'],'Unchanged Python verification failed'
    labels={c['label']:c for c in state['checks']}
    wanted=['python-final-audit','python-validation-inputs','python-validation-certificates']
    if all(k in labels for k in wanted):break
    time.sleep(5)
certificate=json.loads((base/'results/settling-cert-python-validation-v4/summary.json').read_text())
assert certificate['validation']['passed'] and len(certificate['validation']['results'])==240
for label in wanted:
    source=base/'results/settling-verification-final-v3'/(label+'.txt')
    record(dict(label=label+'-reused',returncode=0,reused=True,source=str(source.relative_to(base)),
        sha256=hashlib.sha256(source.read_bytes()).hexdigest(),original_check=labels[label]))
module('negative-controls','negative_checks','--python','results/settling-v4','--native','results/settling-native-v3')
module('unreachable-python','diagnostics','--output','results/settling-unreachable-python-v3')
module('unreachable-native','diagnostics','--native','--output','results/settling-unreachable-native-v3')
run('original150-regression',[sys.executable,'/workspace/lans-setup/run-original150-regression-v2.py'])
run('exported-smt-replay',[sys.executable,'-c',
    "from pathlib import Path;import z3,json;p=Path('results/settling-v4/proof2d');r={};"+
    "\nfor f in sorted(p.glob('*.smt2')):\n s=z3.Solver();s.from_file(str(f));r[f.name]=str(s.check())\n"+
    "assert len(r)==6 and set(r.values())=={'unsat'};print(json.dumps(dict(passed=True,solver=z3.get_version_string(),results=r),indent=2))"])
print('ALL DEVELOPMENT CHECKS PASSED; OPENING12007-SERIES NATIVE VALIDATION',flush=True)
module('native-validation','native','--python','results/settling-v4','--output','results/settling-native-v3','--stage','validation')
module('native-final-audit','audit','results/settling-native-v3','--native')
module('native-validation-certificates','certify','results/settling-native-v3','--native','--stage','validation','--output','results/settling-cert-native-validation-v3')
module('final-report','report','--python','results/settling-v4','--native','results/settling-native-v3','--output','results/settling-report-final-v4')
print('ALL FINAL GATES COMPLETED',flush=True)
