"""Continue complete frozen checkpoints; correct a reused diagnostic output path."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
base=Path('/workspace/LANS');sys.path.insert(0,str(base))
from integrations.connected_v2v.settling.study import verify_sources
out=base/'results/settling-verification-final-v6';out.mkdir(parents=True,exist_ok=False)
checks=[]
def record(item):
 checks.append(item);(out/'checks.json').write_text(json.dumps(dict(passed=all(c['returncode']==0 for c in checks),checks=checks),indent=2)+'\n')
def run(label,args):
 print('START',label,flush=True);start=time.time()
 with (out/(label+'.txt')).open('x') as log:status=subprocess.run(args,cwd=base,stdout=log,stderr=subprocess.STDOUT).returncode
 record(dict(label=label,returncode=status,seconds=time.time()-start,command=args));print('DONE',label,status,flush=True)
 if status:raise RuntimeError(label+' failed; evidence retained')
def module(label,name,*args):run(label,[sys.executable,'-m','integrations.connected_v2v.settling.'+name,*args])
prior=base/'results/settling-verification-final-v5'
print('Waiting for existing pipeline to finish its complete frozen development checks',flush=True)
while True:
 state=json.loads((prior/'checks.json').read_text())
 if not state['passed']:break
 time.sleep(5)
failed=[c for c in state['checks'] if c['returncode']]
assert len(failed)==1 and failed[0]['label']=='unreachable-python',failed
text=(prior/'unreachable-python.txt').read_text()
assert 'FileExistsError' in text and 'settling-unreachable-python-v3' in text,text
note=dict(classification='ORCHESTRATION_OUTPUT_PATH_COLLISION',prior=str(prior.relative_to(base)),
 reason='Existing completed diagnostic output was requested again. No ordinary trial failed, resumed, overwritten or relabelled. Reuse only completed source-frozen development and common-Python checks; run new diagnostics in fresh roots.')
(out/'continuation.json').write_text(json.dumps(note,indent=2)+'\n')
(prior/'ORCHESTRATION_STOP.json').write_text(json.dumps(note,indent=2)+'\n')
verify_sources(json.loads((base/'results/settling-v4/plan.json').read_text())['sources'])
verify_sources(json.loads((base/'results/settling-native-v4/plan.json').read_text())['sources'])
for stage,number,root in [('development',48,'settling-native-v4'),('development',96,'settling-v4'),('validation',240,'settling-v4')]:
 s=json.loads((base/f'results/{root}/{stage}/summary.json').read_text());assert s['passed'] and len(s['results'])==number
wanted=['full-tests','native-development','native-development-audit','native-development-certificates','python-final-audit-reused','python-validation-inputs-reused','python-validation-certificates-reused','negative-controls']
labels={c['label']:c for c in state['checks']}
for label in wanted:
 c=labels[label];assert c['returncode']==0
 p=prior/(label+'.txt')
 if not p.exists():p=base/c['source']
 record(dict(label=label,returncode=0,reused=True,source=str(p.relative_to(base)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),original_check=c))
module('unreachable-python','diagnostics','--output','results/settling-unreachable-python-v4')
module('unreachable-native','diagnostics','--native','--output','results/settling-unreachable-native-v4')
run('original150-regression',[sys.executable,'/workspace/lans-setup/run-original150-regression-v3.py'])
run('exported-smt-replay',[sys.executable,'-c',"from pathlib import Path;import z3,json;p=Path('results/settling-v4/proof2d');r={};"+"\nfor f in sorted(p.glob('*.smt2')):\n s=z3.Solver();s.from_file(str(f));r[f.name]=str(s.check())\n"+"assert len(r)==6 and set(r.values())=={'unsat'};print(json.dumps(dict(passed=True,solver=z3.get_version_string(),results=r),indent=2))"])
print('ALL DEVELOPMENT CHECKS PASSED; OPENING16001-SERIES NATIVE VALIDATION',flush=True)
module('native-validation','native','--python','results/settling-v4','--output','results/settling-native-v4','--stage','validation')
module('native-final-audit','audit','results/settling-native-v4','--native')
module('native-validation-certificates','certify','results/settling-native-v4','--native','--stage','validation','--output','results/settling-cert-native-validation-v4')
module('final-report','report','--python','results/settling-v4','--native','results/settling-native-v4','--output','results/settling-report-final-v6')
print('ALL FINAL GATES COMPLETED',flush=True)
