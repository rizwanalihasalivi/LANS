LANS — RESEARCH SUBMISSION CANDIDATE, 21 OCTOBER 2026

Files
- Manuscript (.docx and .pdf): revised teacher-aligned results, including post hoc 42-scenario diagnostics.
- Verification addendum: Tables S1-S2, separate actuator/arrival tests, matched-observer MPC, feasibility and limitations.
- Highlights / cover letter / author checklist: drafts requiring author approval.
- Original supplementary ZIP: provided by the author, archived independently, dated 7 October 2026.
- Post hoc per-episode CSV + summary + standalone test script and minimal Gymnasium interface shim.

IMPORTANT RESEARCH LIMITATIONS
1. The 42-case new comparisons use one frozen PPO seed (42) and two physical random seeds, not policy-retrained experiments.
2. The selected MPC original-observer and LANS-selected-observer comparisons differ in their chosen estimator settings.
3. No tire-force-limited high-speed dynamic or physical vehicle validation is established.
4. No fully linked embedded target and certified WCET bound is established. A successful host-GCC C rebuild is not WCET.
5. Historical PPO training cannot be reproduced bit for bit from the reconstruction.
6. Authors must approve novelty, affiliation, funding, conflict-of-interest, journal type and current guidelines.

Reproduction procedure (in an external Python environment)
A. Extract original supplementary ZIP separately. Run saved scripts under the package's pinned Gymnasium/SB3 stack for full training/evaluation replication where available.
B. For the post hoc diagnostic, copy the extracted LANS_JSA_Supplementary/audited_code, saved config JSONs and compiled C actor library to the expected paths in the standalone script, then install Python NumPy and SciPy.
C. The provided tiny Gymnasium interface shim supports the archived simulation's basic Env/Box protocol; it DOES NOT support PPO training or replace Gymnasium officially.
D. Execute 'python lans_targeted_experiments_atomic.py --seeds 3200 3201 --policies 42', from the verified analysis environment.
E. Verify reported new summary against new per-case CSV; no new numbers replace the historical pooled tables.

The manuscript is a technically prepared submission CANDIDATE, not a declaration of certified real-time operation or guaranteed acceptance.
