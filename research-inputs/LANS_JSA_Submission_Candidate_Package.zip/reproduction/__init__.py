"""Minimal protocol shim exclusively for archival LANS env replay; not Gymnasium replacement for training."""
import numpy as np
from . import spaces
class Env:
 def __init__(self):
  self.np_random=np.random.default_rng()
 def reset(self,*,seed=None,options=None):
  if seed is not None:
   self.np_random=np.random.default_rng(seed)
  return None
 def close(self):pass
