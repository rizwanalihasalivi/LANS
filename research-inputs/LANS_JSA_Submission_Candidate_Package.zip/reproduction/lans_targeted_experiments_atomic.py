"""Supplementary targeted LANS follow-up experiments, with 37-input frozen C actor.
Requires only NumPy/SciPy and tiny interface shim for absent Gymnasium. Existing controller code unchanged.
IMPORTANT: no SB3 training is claimed or performed.
"""
import os,sys,csv,json,ctypes,time,argparse
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/lans_work/LANS_JSA_Supplementary')
sys.path[:0]=['/mnt/data/lans_work/shims',str(ROOT/'audited_code')]
os.chdir(ROOT/'audited_code')
from scripts.paper_env import BenchEnv,NOISE
from scripts.stress_env import PROFILES
from controllers.transport_feedback import TransportFeedback
LIB=ctypes.CDLL(str(ROOT/'c_port_validation/liblans.so'))
LIB.lans_policy.argtypes=[ctypes.c_int,ctypes.POINTER(ctypes.c_float),ctypes.POINTER(ctypes.c_float)]
LIB.lans_policy.restype=ctypes.c_int

def infer(seed,obs):
 arr=np.ascontiguousarray(obs,dtype=np.float32);out=ctypes.c_float()
 rc=LIB.lans_policy(seed-42,arr.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),ctypes.byref(out))
 if rc:raise RuntimeError('actor code:'+str(rc))
 return float(out.value)

class RemoveArrivalButKeepActuatorLead(TransportFeedback):
 def compute(self,x,kappa):
  # Preserve original bounded lead with current executed steering, but do not
  # roll ahead through pending physical command targets.
  saved=self.owner.known_command_sequence
  try:
   self.owner.known_command_sequence=[]
   return super().compute(x,kappa)
  finally:self.owner.known_command_sequence=saved

def evaluate(case,mode,train_seed,observer):
 is_mpc=mode.startswith('mpc')
 if is_mpc:
  # Explicitly MATCH LANS observer config; no retraining or MPC tuning.
  env=BenchEnv(variant='mpc', profile=case['profile'],path=case['path'],heldout=True)
  if observer=='matched_lans':
   from controllers.noise_observer import NoiseAwareEKF
   # Keep MPC base with its own q_bias, use identical R_adapt options of LANS.
   c=env.framework_controller
   c.filter=NoiseAwareEKF(env.vx,env.dt,env.L,c.filter.q_bias,**NOISE['lans'])
 else:
  env=BenchEnv(variant='full',profile=case['profile'],path=case['path'],heldout=True)
  c=env.framework_controller
  original=c.inner.analytical
  if mode in ('no_arrival','no_lead','no_arrival_no_lead'):
   assert isinstance(original,TransportFeedback),str(type(original))
   kw=dict(damping=(0.0 if mode in ('no_lead','no_arrival_no_lead') else original.damping),nominal_tau=original.nominal_tau,nominal_rate=original.nominal_rate)
   if mode in ('no_arrival','no_arrival_no_lead'):
    c.inner.analytical=RemoveArrivalButKeepActuatorLead(c,original.base,**kw)
   else:
    c.inner.analytical=TransportFeedback(c,original.base,**kw)
 obs,_=env.reset(seed=case['physical_seed'])
 errors=[float(env.state[0])];fallback=0;received=0;done=False
 for tick in range(1000):
  a=(infer(train_seed,obs) if not is_mpc else 0.)
  obs,_,term,trunc,info=env.step(np.array([a],dtype=np.float32))
  errors.append(float(info['error']));fallback+=int(info['fallback_used']);received+=int(info.get('remote_residual_accepted',0.)!=0)
  if term or trunc:
   done=not term;break
 n=len(errors)-1;sq=np.sum(np.square(errors))
 out=dict(**case,mode=mode,train_seed=train_seed,observer=observer,steps=n,completed=bool(done),rmse_m=float(np.sqrt(sq/(n+1))),penalized_rmse_m=float(np.sqrt((sq+(1000-n)*max(2.5,abs(errors[-1]))**2)/1001)),max_error_m=float(max(map(abs,errors))),fallback_count=fallback,accepted_residual_steps=received)
 env.close();return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--seeds',type=int,nargs='+',default=[3200,3201]);ap.add_argument('--policies',type=int,nargs='+',default=[42]);ap.add_argument('--profiles',nargs='+',default=list(PROFILES));ap.add_argument('--paths',nargs='+',default=['dlc','sine_noise_test','chirp_noise_test']);a=ap.parse_args()
 modes=['full','no_arrival','no_lead','no_arrival_no_lead','mpc_original','mpc_matched']
 outpath=Path('/tmp/LANS_targeted_ablation_results.csv')
 rows=[];begin=time.time()
 for physical_seed in a.seeds:
  for path in a.paths:
   for profile in a.profiles:
    case=dict(physical_seed=physical_seed,path=path,profile=profile)
    for seed in a.policies:
     for mode in modes:
      rr=evaluate(case,mode,seed,('matched_lans' if mode=='mpc_matched' else 'original'))
      rows.append(rr)
      if len(rows)==1:
       f=open(outpath,'w',newline='');w=csv.DictWriter(f,fieldnames=list(rr));w.writeheader()
      w.writerow(rr);f.flush()
    print('finished',len(rows), 'seed',physical_seed,path,profile,'secs',round(time.time()-begin,1),flush=True)
 f.close()
 import pandas as pd
 df=pd.DataFrame(rows)
 s=df.groupby('mode').agg(executions=('completed','size'), completed=('completed','sum'),mean_rmse_m=('rmse_m','mean'),mean_penalized_rmse_m=('penalized_rmse_m','mean')).reset_index()
 s['completion_pct']=100*s.completed/s.executions
 s.to_csv('/tmp/LANS_targeted_ablation_summary.csv',index=False)
 print(s.to_string(index=False));print('elapsed',time.time()-begin)
if __name__=='__main__':main()
