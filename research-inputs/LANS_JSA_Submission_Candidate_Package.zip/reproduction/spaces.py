class Box:
 def __init__(self,low,high,shape=None,dtype=None):
  self.low,self.high,self.shape,self.dtype=low,high,shape,dtype
