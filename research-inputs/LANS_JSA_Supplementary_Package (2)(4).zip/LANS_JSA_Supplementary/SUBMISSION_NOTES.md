# Submission notes

Use the root revised DOCX/PDF and SUPPLEMENTARY_GUIDE.md. The paper reports measured software timing, conditional queue/iteration checks and native C numerical validation; it does not claim a verified full-LANS WCET. Author confirmation is still needed for names, affiliation, correspondence, funding, competing interests and submission eligibility. No submission has been made. Older editorial notes are retained in historical_editorial/ and do not describe the current pagination.
