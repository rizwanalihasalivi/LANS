# Supplementary evidence guide
Revision: 7 October 2026. Companion to the revised LANS manuscript.

All experiments reported in the paper are mapped below. These are existing recorded results, not experiments rerun during manuscript editing. Summaries and retained raw records are distinguished; this archive is not a complete history of every training run.

| Paper evidence | Files or directories |
|---|---|
| Tracking, controller ablations and frozen suites; Tables 5–8 | tables/legacy_01_controller_ablation.csv, legacy_15_cross_suite_context.csv, legacy_16_combined_frozen_validation.csv; historical_results/ |
| Paired physical-cell and seed sensitivity; Table 21 | tables/paired_physical_cells.csv, paired_cluster_summary.csv, paired_profile_differences.csv, paired_cell_bootstrap.csv |
| Reward on/off, pilots and standalone diagnostics; Tables 9–11 | tables/legacy_05_reward_paired.csv, legacy_06_reward_seed_effect.csv, legacy_13_reward_comparison.csv, pilot_*.csv, standalone_*.csv |
| Paths and observer comparisons; Tables 12, 16 | tables/selected_paths.csv; historical_results/ |
| Prepared-state timing; Tables 13, 17, 19–20 | tables/windows_timing_summary.csv, legacy_07_fair_timing.csv, wcet_*.csv; sources/; WCET_AUDIT.json |
| Simulated command/actuator response; Table 14 | tables/response_*.csv |
| Measured CPU-package energy; Table 15 | energy_analysis/, tables/energy_*.csv; this is not whole-system energy |
| Equations, code excerpts and nominal certificate | EQUATION_AUDIT.csv, EQUATION_VERIFICATION.json, equations.md, verify_equations.py, audited_code/, code_excerpts/ |
| Figures and their source data | figures/, add_figures.py, draw_architecture.py, tables/example_trace.csv |
| Contiguous software-loop timing and temporal-interface tests; Appendix E, Table 22 | LANS_Software_Timing_Tests.zip: loop_samples.csv, loop_summary.csv, environment.json, queue_stress.csv, clock_sensitivity.csv, scripts and source snapshot |
| Conditional queue and iteration verification; Appendix F | LANS_Conditional_Timing_Verification.zip: conditional_bounds.csv, proof_results.json, *.smt2, source_conformance.csv, verify_bounds.py, source snapshot |
| C numerical implementation validation; Appendix G, Table 23 | c_port_validation/results/: shadow_all.csv, paired_all.csv, closed_loop_all.csv, recovery_cases.csv, contracts.csv, sanitizers.txt, summary.json |
| C sources, frozen policies and reproduction | c_port_validation/src/, frozen/reference/, README.md, build/run/validation scripts |
| Embedded target analysis outcome | c_port_validation/patmos/: compile and link logs, object files; results/summary.json records 40 unresolved symbols and no WCET certificate |
| Citation audit | REFERENCE_AUDIT.csv, REFERENCE_AUDIT.md, references.json |

## Reading the evidence correctly
- Main robustness comparisons and the restricted port-validation grid are different campaigns. The 63/63 port survival result must not replace the 147-cell baseline comparison.
- Table 23 reports observed numerical agreement, not formal equivalence.
- Conditional source-level proofs do not assign hardware execution costs.
- Prepared-state maxima, arithmetic timing proxies and contiguous software-cycle measurements are different metrics.
- Physical sensor-to-actuator latency, measured hardware clock synchronization, whole-system energy, a full nonlinear safety proof and a verified full-LANS WCET are not supplied.
- Synthetic clock calculations, simulated actuator response and CPU-package telemetry must retain those labels.
- Earlier audit notes and build scripts document their respective revisions. The root revised DOCX/PDF and this guide define the current manuscript; rewrite_complete.py records the current editing pass.

FILE_MANIFEST.json gives SHA-256 hashes of all other files in this archive. Existing nested verification packages retain their own provenance. No public repository identifier is asserted.
