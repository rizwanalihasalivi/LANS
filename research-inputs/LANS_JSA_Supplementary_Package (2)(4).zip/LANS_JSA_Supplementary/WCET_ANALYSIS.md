# WCET analysis and claim status

The current evidence establishes observed timing maxima, not a verified WCET upper bound. This distinction follows Wilhelm et al., ACM TECS 7(3), Article 36 (2008), DOI 10.1145/1347375.1347389, especially pp. 2–3: https://www.es.mdh.se/pdf_publications/1258.pdf.

## Data examined

Two existing raw timing logs, kept separate by host: Windows Intel i5-1235U and Linux AMD EPYC 9V74. Each contains 35,100 rows: 13 methods × 3 policy-seed contexts × 3 stress profiles × 300 post-warm-up ticks. There are 2,700 unique common-state keys per host. The shared frontend observation is repeated across methods and is not an independent measurement each time.

The audit checks finite nonnegative durations, unique method/seed/profile/tick keys, group counts, tick range, identical shared frontend values per state, and equality of decision time to policy plus controller time. No timing samples or failures are removed. Percentiles use NumPy's default linear interpolation. No new timing workload was executed for this analysis.

## Main findings

| Host / method | Samples | Maximum decision (ms) | Decision > 10 ms | Maximum frontend-plus-decision proxy (ms) | Proxy > 10 ms |
|---|---:|---:|---:|---:|---:|
| Windows LANS | 2700 | 8.431100 | 0 | 10.204300 | 1 |
| Windows MPC | 2700 | 6.193100 | 0 | 7.947500 | 0 |
| Windows residual off | 2700 | 5.138800 | 0 | 6.680400 | 0 |
| Linux LANS | 2700 | 2.722340 | 0 | 3.015122 | 0 |
| Linux MPC | 2700 | 2.100691 | 0 | 2.670711 | 0 |
| Linux residual off | 2700 | 4.632744 | 0 | 5.178959 | 0 |

The proxy adds separately timed frontend and decision durations associated with the same recorded state. It is neither a directly timed integrated-loop measurement nor physical sensor-to-actuator latency. Exceedances of this proxy are not measured physical deadline misses. The 10 ms budget is a comparison threshold, not an established deployment contract.

## Supported wording

“In the recorded Windows workload, LANS had a maximum observed prepared-state decision duration of 8.4311 ms, with zero 10 ms budget exceedances among 2,700 samples. The frontend-plus-decision software-time proxy reached 10.2043 ms, with one exceedance. These finite-record results do not establish a verified WCET bound or a hard end-to-end deadline.”

## Why a verified WCET claim is not supported

The records do not cover every admissible path, state, interference condition, cold start or platform state. The implementation uses Python, native numerical libraries, optimization and a general-purpose OS; no sound target-specific timing analysis or bounded interference model is provided. Loop/queue capacities and solver iteration bounds must be assessed as part of a complete executable and deployment contract. Sequential data also do not establish the independent, stationary and representative sampling needed for a justified statistical tail claim. No EVT extrapolation, arbitrary safety-factor bound, or zero-miss binomial guarantee is asserted.

A future certified bound needs a precisely scoped executable and target, bounded inputs/queues/iterations, an admissible interference contract, and a sound analysis covering the resulting executions. End-to-end guarantees additionally need scheduling, sensing, transport and actuation bounds. More samples alone cannot establish these guarantees.

## Files

- tables/wcet_observed_summary.csv: all 26 host/method combinations, with verified_WCET_ms left empty because no bound is established.
- tables/wcet_by_seed_profile.csv: 234 subgroup summaries.
- tables/wcet_worst_observed_samples.csv: the original maximum-duration row for each host/method.
- WCET_AUDIT.json: arithmetic/coverage checks and input checksums.
- analyze_wcet.py: reproducible analysis.

Tables 19–20 and Appendix C in the paper contain these results and their limitations.
