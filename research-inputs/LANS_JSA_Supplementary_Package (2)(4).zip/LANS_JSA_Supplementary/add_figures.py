from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyBboxPatch,Arc
R=Path(__file__).resolve().parent;F=R/'figures'
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
def save(name):
 plt.savefig(F/(name+'.png'),dpi=400,bbox_inches='tight');plt.savefig(F/(name+'.pdf'),bbox_inches='tight');plt.close()
fig,ax=plt.subplots(figsize=(5.8,2.7));x=np.linspace(0,10,200);y=.035*(x-2)**2
ax.plot(x,y,'k-',lw=1.2,label='Reference path');xx=5;yr=.035*9;yy=1.5;psi=.34
ax.plot([xx,xx],[yr,yy],'--',color='#315f80');ax.annotate('',(xx,yy),(xx,yr),arrowprops={'arrowstyle':'<->','color':'#315f80'});ax.text(xx-.35,(yr+yy)/2,'$e_y$',ha='right')
ax.plot(xx,yy,'ko',ms=4);ax.annotate('',(xx+2.4*np.cos(psi),yy+2.4*np.sin(psi)),(xx,yy),arrowprops={'arrowstyle':'->','lw':1.5});ax.text(7.4,2.3,'Vehicle heading $\psi$')
a=np.arctan(.07*(xx-2));ax.plot([xx,xx+2.4],[yy,yy+2.4*np.tan(a)],'--',color='gray');ax.text(7.5,1.9,'Reference heading $\psi_{ref}$',fontsize=7)
ax.add_patch(Arc((xx,yy),3.5,3.5,theta1=np.degrees(a),theta2=np.degrees(psi)));ax.text(6.55,1.75,'$e_\psi$',fontsize=8)
ax.set(xlim=(0,10),ylim=(-.1,3.1),xlabel='Longitudinal position $X$',ylabel='Lateral position $Y$');ax.set_xticks([]);ax.set_yticks([]);ax.legend(loc='upper left',frameon=False);fig.tight_layout();save('fig09_geometry')
fig,ax=plt.subplots(figsize=(7.1,2.45));ax.set(xlim=(-1.8,10.7),ylim=(-.65,3.7));ax.axis('off')
for i,(label,start,end,color,txt) in enumerate([('Sensor',0,2,'#447c9d','Pose transport'),('Remote PPO',.7,6,'#b07838','Inference / communication'),('Local command',2.3,3.1,'#568773','Decision'),('Actuator',3.1,5.8,'#82658c','Queue + lag / rate')]):
 y=3-i;ax.text(-.3,y,label,ha='right',va='center');ax.plot([0,10.3],[y,y],color='#aaa',lw=.6);ax.add_patch(Rectangle((start,y-.19),end-start,.38,color=color,alpha=.3));ax.text((start+end)/2,y+.28,txt,ha='center',fontsize=7)
ax.annotate('Generation timestamp',xy=(.7,2),xytext=(.7,3.48),ha='center',fontsize=7,arrowprops={'arrowstyle':'->','lw':.6});ax.annotate('Late residual discarded\nif generation age > 200 ms',xy=(6,2),xytext=(8.1,2.8),ha='center',fontsize=7,arrowprops={'arrowstyle':'->','lw':.6});ax.annotate('Local loop continues',xy=(3.1,1),xytext=(8,1.25),ha='center',fontsize=7,arrowprops={'arrowstyle':'->','lw':.6});ax.text(7.9,-.2,'Fallback uses this same actuator path',ha='center',fontsize=7);save('fig10_timing_channels')
fig,ax=plt.subplots(figsize=(7.1,2.8));ax.set(xlim=(0,10),ylim=(0,4.6));ax.axis('off')
def box(x,y,w,h,t,c='#f0f3f5'):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.03',fc=c,ec='#465663',lw=.8));ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=8)
def arr(a,b):ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','lw':.8})
box(.1,3,2.7,1.2,'Observer development\n10 candidates × 28 cells\nper controller')
box(3.5,3,2.7,1.2,'Freeze configurations\nLANS and MPC selected\nindependently')
box(7,3,2.8,1.2,'Original residual policies\n3 training seeds\n51,200 steps each')
arr((2.8,3.6),(3.5,3.6));arr((7,3.6),(6.2,3.6))
box(.1,.3,2.7,1.4,'Earlier validation\n105 physical cells\n5 evaluation seeds')
box(3.5,.3,2.7,1.4,'Component validation\n42 physical cells\n2 evaluation seeds')
box(7,.3,2.8,1.4,'Separate retraining\nReward on / off\nStandalone PPO pilots')
arr((4.85,3),(1.45,1.7));arr((4.85,3),(4.85,1.7));arr((4.85,3),(8.4,1.7));save('fig11_protocol')
ep=pd.read_csv(R/'sources/episodes.csv');fig,axs=plt.subplots(1,2,figsize=(6.8,2.6));colors=['#215a82','#cc873b','#49927c']
for m,col,lab in zip(['full','zero','mpc'],colors,['LANS','Residual off','MPC']):
 z=ep[ep.method==m];a=z.groupby('eval_seed').agg(rmse=('rmse_m','mean'),survival=('survived','mean')) if 'survived' in z.columns else None
 if a is None:
  z=z.assign(survived=z.steps>=1000);a=z.groupby('eval_seed').agg(rmse=('rmse_m','mean'),survival=('survived','mean'))
 axs[0].plot(a.index.astype(str),a.rmse,'o-',label=lab,color=col);axs[1].plot(a.index.astype(str),100*a.survival,'o-',color=col)
axs[0].set_ylabel('Mean RMSE (m)');axs[1].set_ylabel('Survival (%)');axs[1].set_ylim(0,105)
for a in axs:a.set_xlabel('Physical evaluation seed')
axs[0].legend(fontsize=7,frameon=False);fig.tight_layout();save('fig12_seed_comparison')
