from docx.shared import Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import re

def add_algorithm(doc):
 def border(p,edge):
  pr=p._p.get_or_add_pPr();bd=pr.find(qn('w:pBdr'))
  if bd is None:bd=OxmlElement('w:pBdr');pr.append(bd)
  el=OxmlElement('w:'+edge);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'5');el.set(qn('w:space'),'2');bd.append(el)
 def para(text,level=0):
  p=doc.add_paragraph();p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.left_indent=Pt(level*9);p.paragraph_format.space_after=Pt(1);p.paragraph_format.line_spacing=Pt(9);p.paragraph_format.keep_with_next=True
  for t in re.split(r'(\bif\b|\bthen\b|\belse\b|Input:|Output:|Algorithm 1:)',text):
   ru=p.add_run(t);ru.font.size=Pt(7.3);ru.bold=t in ['if','then','else','Input:','Output:','Algorithm 1:']
  if level:border(p,'left')
  return p
 p=para('Algorithm 1: Local LANS command selection (tick k)');border(p,'top');border(p,'bottom')
 para('Input: Stamped pose, reference, applied steering history, pending commands and remote packets.')
 para('Output: Selected steering uₖ and unresolved-recovery flag.')
 steps=[(0,'Assimilate each new consecutive pose timestamp once.'),(0,'Propagate its estimate using applied steering history.'),(0,'Predict pending commands; compute analytical base b̃ₖ.'),(0,'Deliver remote packets; retain newest generation stamp.'),(0,'if a held packet has generation age ≤ 200 ms then'),(1,'r̄ₖ ← held residual × exp(−age / 100 ms).'),(0,'else'),(1,'r̄ₖ ← 0.'),(0,'Form u⁺ ← sat₀.₅(b̃ₖ + r̄ₖ).'),(0,'if J(u⁺) ≥ J(b̃ₖ) then'),(1,'r̄ₖ ← 0.'),(0,'uₖ ← sat₀.₅(b̃ₖ + r̄ₖ); evaluate diagnostic D(uₖ).'),(0,'Update envelope latch from predicted/current errors.'),(0,'if diagnostic exceeds threshold or latch is set then'),(1,'uₖ ← b̃ₖ.'),(1,'if D(b̃ₖ) > 10.2231 then'),(2,'Run bounded scalar recovery search.'),(2,'Compare valid solver output, b̃ₖ, ±0.5 and 0.'),(2,'uₖ ← candidate with lowest finite diagnostic.'),(1,'Clear inner local queue; retain physical queue.'),(0,'Flag unresolved if D(uₖ) is nonfinite or > 10.2231.'),(0,'Enqueue uₖ on common physical actuator path.'),(0,'Log residual, fallback and recovery status.')]
 for i,(lv,txt) in enumerate(steps,1):p=para(f'{i:2}  '+txt,lv)
 p.paragraph_format.keep_with_next=False;border(p,'bottom')
