"""Finite-record timing audit. Produces no verified WCET upper bound."""
from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
R=Path(__file__).resolve().parent
rows=[];groups=[];worst=[];quality=[]
for host in ['windows','linux']:
 p=R/'sources'/f'{host}_timing_samples.csv';d=pd.read_csv(p)
 assert d.groupby('method').size().eq(2700).all()
 assert d.groupby(['method','train_seed','profile']).size().eq(300).all()
 assert set(d.tick)==set(range(100,400))
 assert not d.duplicated(['method','train_seed','profile','tick']).any()
 assert np.isfinite(d[['policy_ms','controller_ms','decision_ms','common_frontend_ms']]).all().all()
 assert (d[['policy_ms','controller_ms','decision_ms','common_frontend_ms']]>=0).all().all()
 err=float(abs(d.decision_ms-d.policy_ms-d.controller_ms).max());assert err<1e-8
 # The common frontend is repeated across methods for one common state; do not count as independent samples.
 assert d.groupby(['train_seed','profile','tick']).common_frontend_ms.nunique().max()==1
 quality.append(dict(host=host,rows=len(d),unique_states=len(d[['train_seed','profile','tick']].drop_duplicates()),sum_error_ms=err,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 for method,g in d.groupby('method',sort=False):
  v=g.decision_ms.to_numpy();proxy=v+g.common_frontend_ms.to_numpy()
  row=dict(host=host,method=method,n=len(g),mean_ms=v.mean(),p95_ms=np.quantile(v,.95),p99_ms=np.quantile(v,.99),p999_ms=np.quantile(v,.999),max_observed_ms=v.max(),budget_ms=10.,exceedances_10ms=int((v>10).sum()),observed_margin_ms=10-v.max(),frontend_plus_decision_proxy_max_ms=proxy.max(),proxy_exceedances_10ms=int((proxy>10).sum()),verified_WCET_ms=np.nan,claim='finite-sample observation only; WCET upper bound not established')
  rows.append(row)
  w=g.loc[g.decision_ms.idxmax()].to_dict();w['host']=host;worst.append(w)
 for (method,seed,profile),g in d.groupby(['method','train_seed','profile']):
  groups.append(dict(host=host,method=method,seed=seed,profile=profile,n=len(g),max_observed_ms=g.decision_ms.max(),exceedances_10ms=int((g.decision_ms>10).sum())))
pd.DataFrame(rows).to_csv(R/'tables/wcet_observed_summary.csv',index=False)
pd.DataFrame(groups).to_csv(R/'tables/wcet_by_seed_profile.csv',index=False)
pd.DataFrame(worst).to_csv(R/'tables/wcet_worst_observed_samples.csv',index=False)
(R/'WCET_AUDIT.json').write_text(json.dumps(dict(result='PASS: raw-record arithmetic and coverage checks',quality=quality,formal_wcet_verified=False,statistical_tail_bound_claimed=False,note='Repeated state trajectories do not establish iid representative timing samples. No EVT or binomial deadline guarantee inferred.'),indent=2))
print(pd.DataFrame(rows).query("method in ['full','mpc','zero']")[['host','method','n','max_observed_ms','exceedances_10ms','frontend_plus_decision_proxy_max_ms','proxy_exceedances_10ms']].to_string(index=False))
