"""Single source of truth for all controllers and environments."""
import numpy as np
from scipy.linalg import solve_continuous_are, expm

# ---- Vehicle ----
VEHICLE = dict(m=1650.0, Iz=4224.0, lf=1.2, lr=1.4,
               Cf=80000.0, Cr=80000.0)
L = VEHICLE["lf"] + VEHICLE["lr"]      # 2.6
VX = 25.0
DT = 0.01
DELTA_MAX = 0.5

# Legacy dynamic design supplies a fixed diagnostic P only in reviewer runs.
# Canonical prediction and analytical control are kinematic.
def _error_model(vx, p):
    m, Iz = p["m"], p["Iz"]
    lf, lr, Cf, Cr = p["lf"], p["lr"], p["Cf"], p["Cr"]
    A = np.array([
        [0, 1, 0, 0],
        [0, -(Cf+Cr)/(m*vx), (Cf+Cr)/m, (lr*Cr - lf*Cf)/(m*vx)],
        [0, 0, 0, 1],
        [0, (lr*Cr - lf*Cf)/(Iz*vx), (lf*Cf - lr*Cr)/Iz,
         -(lf**2*Cf + lr**2*Cr)/(Iz*vx)],
    ])
    B = np.array([[0], [Cf/m], [0], [lf*Cf/Iz]])
    return A, B

# Retained diagnostic design; K_LQR is a legacy compatibility value.
# Reviewer controller computes its own discrete kinematic LQR gain.
Q_FILTER = np.diag([25.0, 2.5, 12.5, 1.25])
R_FILTER = np.array([[1.0]])
K_SCALE  = 0.1

def make_filter(vx=VX):
    A, B = _error_model(vx, VEHICLE)
    P = solve_continuous_are(A, B, Q_FILTER, R_FILTER)
    K_care = np.linalg.solve(R_FILTER, B.T @ P).flatten()
    K = K_SCALE * K_care
    # Exact ZOH discretization for the filter prediction
    M = np.zeros((5, 5))
    M[:4, :4] = A * DT
    M[:4, 4]   = (B.flatten()) * DT
    Mexp = expm(M)
    A_d = Mexp[:4, :4]
    B_d = Mexp[:4, 4]
    return K, P, A_d, B_d

K_LQR, P_LQR, A_D, B_D = make_filter(VX)

# Frozen inherited threshold; not a certified invariant-set boundary.
V_MAX = 10.2231
V_MAX_NOMINAL = V_MAX
V_MAX_PERTURBED = V_MAX
DEFAULT_DELAY_RANGE_MS = (0.0, 200.0)


def validate_config():
    """Raise a clear error if the diagnostic matrix dimensions or positivity are invalid."""
    assert K_LQR.shape == (4,)
    assert P_LQR.shape == (4, 4)
    assert A_D.shape == (4, 4)
    assert B_D.shape == (4,)
    assert np.allclose(P_LQR, P_LQR.T, atol=1e-10)
    assert np.all(np.linalg.eigvalsh(P_LQR) > 0.0)
    if not np.isfinite(V_MAX) or V_MAX <= 0.0:
        raise ValueError("V_MAX must be a positive finite scalar")
    return True


validate_config()
