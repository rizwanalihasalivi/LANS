"""Causal augmented EKF using only noisy lateral position/heading and applied u.
No true plant gain, disturbance signal or derivative-like simulator feature.
"""
import numpy as np
from controllers.framework_controller import LANSFrameworkController
from controllers.analytical_branch import AnalyticalCommand

class PoseBiasEKF:
    def __init__(self,v=25.,dt=.01,L=2.6,q_bias=.0004):
        self.v,self.dt,self.L=v,dt,L
        self.q_bias=q_bias
        self.reset()
    def reset(self):
        self.z=None
        self.P=np.diag([.0004,.0004,.25,.04,.0625])
    def update(self,y,psi,u):
        measurement=np.array([y,psi])
        if not np.all(np.isfinite(measurement)) or not np.isfinite(u):raise ValueError('Nonfinite measurement/input')
        if self.z is None:
            self.z=np.array([y,psi,0.,0.,1.]);return self.z.copy()
        z=self.z.copy();dt=self.dt;rate=self.v*np.tan(u)/self.L
        F=np.eye(5);F[0,1]=self.v*np.cos(z[1])*dt;F[0,2]=dt;F[1,3]=dt;F[1,4]=rate*dt
        z[0]+=(self.v*np.sin(z[1])+z[2])*dt
        z[1]+=(z[4]*rate+z[3])*dt
        Q=np.diag([1e-7,1e-7,self.q_bias,self.q_bias*.25,1e-7])
        prior=F@self.P@F.T+Q
        H=np.zeros((2,5));H[0,0]=H[1,1]=1.
        R=np.diag([.0004,.0004])
        gain=np.linalg.solve(H@prior@H.T+R,H@prior).T
        z+=gain@(measurement-H@z)
        I=np.eye(5)-gain@H
        self.P=I@prior@I.T+gain@R@gain.T
        # Parameter projections are engineering bounds, not probabilistic guarantees.
        z[2]=np.clip(z[2],-1.5,1.5);z[3]=np.clip(z[3],-.6,.6);z[4]=np.clip(z[4],.5,1.5)
        self.z=z
        return z.copy()

class BiasPrediction:
    def __init__(self,original,bias_y,bias_psi,gain):
        self.original=original
        self.position=original.position;self.vx=original.vx;self.dt=original.dt;self.L=original.L
        self.curvature=original.curvature
        self.bias_y,self.bias_psi,self.gain=bias_y,bias_psi,gain
    def __call__(self,x,commands,gain=1.):
        p=self.original;px=p.position;py=p.y_ref(px)+x[0];psi=p.heading(px)+x[2];out=[]
        for u in commands:
            u=float(np.clip(u,-p.delta_max,p.delta_max))
            px+=p.vx*np.cos(psi)*p.dt
            py+=(p.vx*np.sin(psi)+self.bias_y)*p.dt
            nominal_rate=self.gain*p.vx*np.tan(u)/p.L
            psi+=(nominal_rate+self.bias_psi)*p.dt
            ep=psi-p.heading(px)
            out.append([py-p.y_ref(px),p.vx*np.sin(ep),ep,nominal_rate-p.vx*p.curvature(px)])
        return np.asarray(out)

class AdaptiveAnalytical:
    def __init__(self,owner,base):
        self.owner=owner;self.base=base
    def compute(self,x,kappa):
        o=self.owner;dy,dp,g=o.estimates
        ep=x[2]+np.arcsin(np.clip(dy/o.vx,-.5,.5))
        feedback=-self.base.gain[0]*x[0]-self.base.gain[2]*ep
        pure=float(np.clip(np.arctan(feedback/g),-.5,.5))
        total=float(np.clip(np.arctan((feedback+o.L*kappa-o.L/o.vx*dp)/g),-.5,.5))
        return AnalyticalCommand(pure,total-pure,total)

class ObservedController:
    def __init__(self,vx=25.,dt=.01,L=2.6,q_bias=.0004,adaptive=True):
        self.vx,self.dt,self.L=vx,dt,L
        self.adaptive=adaptive
        self.inner=LANSFrameworkController(vx=vx,wheelbase=L,authority_override=1.)
        self.filter=PoseBiasEKF(vx,dt,L,q_bias)
        self.estimates=np.array([0.,0.,1.]);self.filtered=np.zeros(4)
        if adaptive:self.inner.analytical=AdaptiveAnalytical(self,self.inner.analytical)
        self.reset()
    @property
    def analytical(self):return self.inner.analytical
    @property
    def delay(self):return self.inner.delay
    def reset(self):
        self.inner.reset();self.filter.reset();self.last_position=None;self.last_u=0.
        self.estimates=np.array([0.,0.,1.]);self.filtered=np.zeros(4)
    def prepare(self,x,predictor):
        if self.last_position==predictor.position:return
        p=predictor
        z=self.filter.update(p.y_ref(p.position)+x[0],p.heading(p.position)+x[2],self.last_u)
        self.estimates=z[2:].copy() if self.adaptive else np.array([0.,0.,1.])
        ey=z[0]-p.y_ref(p.position);ep=z[1]-p.heading(p.position)
        self.filtered=np.array([ey,self.vx*np.sin(ep),ep,z[4]*self.vx*np.tan(self.last_u)/self.L-self.vx*p.curvature(p.position)])
        self.last_position=p.position
    def step(self,x_k,ppo_residual,delay_ms=0.,gain_context=1.,kappa_k=0.,predictor=None):
        if predictor is None:raise ValueError('ObservedController requires kinematic reference predictor')
        self.prepare(x_k,predictor)
        p=BiasPrediction(predictor,*self.estimates) if self.adaptive else predictor
        u,info=self.inner.step(self.filtered,ppo_residual,delay_ms,self.estimates[2],kappa_k,p)
        self.last_u=u
        info.update(estimated_lateral_bias=float(self.estimates[0]),estimated_yaw_bias=float(self.estimates[1]),estimated_gain=float(self.estimates[2]))
        return u,info
