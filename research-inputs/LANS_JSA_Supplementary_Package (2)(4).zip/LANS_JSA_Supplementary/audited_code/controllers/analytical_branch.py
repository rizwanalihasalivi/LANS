"""Analytical branch: LQR feedback plus curvature feedforward."""

from dataclasses import dataclass

import numpy as np

from config import DELTA_MAX, K_LQR, L, VX


@dataclass(frozen=True)
class AnalyticalCommand:
    u_lqr: float
    u_ff: float
    u_analytical: float


class AnalyticalBranch:
    def __init__(self, gain=None, wheelbase=L, delta_max=DELTA_MAX):
        self.gain = K_LQR.copy() if gain is None else np.asarray(gain, float)
        self.wheelbase = float(wheelbase)
        self.delta_max = float(delta_max)

    def compute(self, x_k, kappa_k: float) -> AnalyticalCommand:
        x_k = np.asarray(x_k, dtype=float).reshape(4)
        u_lqr = float(np.clip(-self.gain @ x_k,
                              -self.delta_max, self.delta_max))
        u_ff = self.wheelbase * float(kappa_k)
        u_analytical = float(np.clip(u_lqr + u_ff,
                                     -self.delta_max, self.delta_max))
        return AnalyticalCommand(u_lqr=u_lqr, u_ff=u_ff,
                                 u_analytical=u_analytical)
