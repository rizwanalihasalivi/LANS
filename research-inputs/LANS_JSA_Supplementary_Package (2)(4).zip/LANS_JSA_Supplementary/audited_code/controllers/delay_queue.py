"""Timestamped FIFO channel; ordered delivery, hold-last actuator semantics.

A command generated at tick k requests arrival k+round(delay/dt). To prevent
reordering, effective arrival is at least one tick after the last queued arrival.
A delay decrease therefore cannot jump ahead of older packets. Requested delay
and realized command age differ during jitter. clear() models actuator-side
cancellation on fresh fallback, not a free physical communications capability.
"""
from collections import deque
import numpy as np


class FIFOCommandDelay:
    def __init__(self, dt):
        self.dt = float(dt)
        if not np.isfinite(self.dt) or self.dt <= 0:
            raise ValueError('dt must be finite and positive')
        self.buffer = deque()
        self.arrivals = deque()
        self.generated = deque()
        self.reset()

    def reset(self):
        self.buffer.clear(); self.arrivals.clear(); self.generated.clear()
        self.tick = 0
        self.last_output = 0.0
        self.last_generated = None
        self.last_age_steps = -1  # initial hold has no generated command

    def delay_steps(self, delay_ms):
        if not np.isfinite(delay_ms) or delay_ms < 0:
            raise ValueError('Delay must be finite and nonnegative')
        return int(round(float(delay_ms) / (1000 * self.dt)))

    def _arrival(self, delay_ms):
        due = self.tick + self.delay_steps(delay_ms)
        return max(due, self.arrivals[-1] + 1) if self.arrivals else due

    def preview_outputs(self, command, delay_ms):
        due = self._arrival(delay_ms)
        pending = deque(zip(self.arrivals, self.buffer))
        pending.append((due, float(command)))
        output = self.last_output
        sequence = []
        for t in range(self.tick, due + 1):
            if pending and pending[0][0] <= t:
                _, output = pending.popleft()
            sequence.append(output)
        return sequence

    def push(self, command, delay_ms):
        command = float(command)
        if not np.isfinite(command):
            raise ValueError('Command must be finite')
        self.arrivals.append(self._arrival(delay_ms))
        self.buffer.append(command); self.generated.append(self.tick)
        if self.arrivals[0] <= self.tick:
            self.arrivals.popleft()
            self.last_output = self.buffer.popleft()
            self.last_generated = self.generated.popleft()
        self.last_age_steps = (-1 if self.last_generated is None
                               else self.tick - self.last_generated)
        self.tick += 1
        return self.last_output

    @property
    def queue_len(self):
        return len(self.buffer)

    def clear(self, hold_command=None):
        self.buffer.clear(); self.arrivals.clear(); self.generated.clear()
        if hold_command is not None:
            self.last_output = float(hold_command)
            self.last_generated = max(0, self.tick - 1)
            self.last_age_steps = 0
