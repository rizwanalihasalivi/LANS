"""Checked analytical fallback with bounded one-step recovery.

Unresolved recovery is explicitly reported. No invariant-set guarantee.
"""
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.linalg import solve_discrete_are
from config import A_D, B_D, DT, DELTA_MAX, L, P_LQR, V_MAX, VX
from controllers.analytical_branch import AnalyticalBranch
from controllers.delay_queue import FIFOCommandDelay
from controllers.fusion import ResidualFusion
from controllers.residual_authority import FirstMatchResidualAuthority, AuthorityDecision


class LANSFrameworkController:
    def __init__(self, vx=VX, V_max=V_MAX, wheelbase=L, delta_max=DELTA_MAX,
                 enable_fallback=True, compensate_delay=True, authority_override=None):
        self.enable_fallback = bool(enable_fallback)
        self.compensate_delay = bool(compensate_delay)
        self.authority_override = authority_override
        self.vx, self.V_max = float(vx), float(V_max)
        self.delta_max = float(delta_max)
        # Discrete LQR for the plant's lateral/heading small-angle dynamics.
        A = np.array([[1., vx * DT], [0., 1.]])
        B = np.array([[0.], [vx * DT / wheelbase]])
        R = np.array([[10.]])
        S = solve_discrete_are(A, B, np.diag([1., 4.]), R)
        K = np.linalg.solve(R + B.T @ S @ B, B.T @ S @ A).ravel()
        self.analytical = AnalyticalBranch(gain=np.array([K[0], 0., K[1], 0.]),
                                           wheelbase=wheelbase, delta_max=delta_max)
        self.authority = FirstMatchResidualAuthority(P=P_LQR, V_max=V_max)
        self.fusion = ResidualFusion(delta_max=delta_max)
        self.delay = FIFOCommandDelay(dt=DT)
        self.recovery_latched = False

    def reset(self):
        self.delay.reset()
        self.recovery_latched = False

    def step(self, x_k, ppo_residual, delay_ms=0.0, gain_context=1.0,
             kappa_k=0.0, predictor=None):
        x_k = np.asarray(x_k, dtype=float).reshape(4)
        if not np.all(np.isfinite(x_k)) or not np.isfinite(ppo_residual):
            raise ValueError("State and residual must be finite")
        if not np.isfinite(delay_ms) or delay_ms < 0:
            raise ValueError("Delay must be finite and nonnegative")
        # Legacy support only. Canonical trainer supplies kinematic predictor.
        if predictor is None:
            def predictor(x, commands, gain):
                result = []
                for u in commands:
                    x = A_D @ x + B_D * (gain * u)
                    result.append(x.copy())
                return np.asarray(result)
            prediction_mode = 'legacy_dynamic'
        else:
            prediction_mode = 'kinematic'

        def one_step(u):
            state = predictor(x_k, [u], gain_context)[0]
            value = float(state @ P_LQR @ state)
            return value if np.isfinite(value) else float('inf')

        analytical = self.analytical.compute(x_k, kappa_k)
        queued_analytical = analytical
        # Transport-delay compensation: simulate only already known commands
        # before the new command reaches the actuator. Fresh fallback uses x_k.
        pending = self.delay.preview_outputs(0., delay_ms)[:-1]
        if self.compensate_delay and pending and prediction_mode == 'kinematic':
            future = predictor(x_k, pending, gain_context)[-1]
            future_kappa = predictor.curvature(
                predictor.position + self.vx * DT * len(pending))
            queued_analytical = self.analytical.compute(future, future_kappa)
        authority = self.authority.decide(x_k, delay_ms, gain_context)
        if self.authority_override is not None:
            authority = AuthorityDecision(float(self.authority_override), "ABLATION",
                                          "FIXED_AUTHORITY", authority.V_ratio)
        u_c = self.fusion.combine(queued_analytical.u_lqr, queued_analytical.u_ff,
                                  ppo_residual, authority.alpha)
        commands = self.delay.preview_outputs(u_c, delay_ms)
        states = predictor(x_k, commands, gain_context)
        values = np.einsum('ni,ij,nj->n', states, P_LQR, states)
        V_horizon = float(np.max(values)) if np.all(np.isfinite(values)) else float('inf')
        # Engineering tracking envelope, independent of quadratic threshold.
        # Hysteresis keeps fresh feedback active during recovery instead of
        # repeatedly holding one old steering command while FIFO refills.
        envelope_risk = bool(np.any(np.abs(states[:, 0]) > .30)
                             or np.any(np.abs(states[:, 2]) > .06))
        if envelope_risk:
            self.recovery_latched = True
        elif abs(x_k[0]) < .10 and abs(x_k[2]) < .02:
            self.recovery_latched = False
        u_q = self.delay.push(u_c, delay_ms)
        V_candidate = one_step(u_q)
        V_fallback = one_step(analytical.u_analytical)
        fallback_used = (V_horizon > self.V_max or V_candidate > self.V_max
                         or self.recovery_latched) and self.enable_fallback
        recovery_used = False
        command = u_q
        if fallback_used:
            command = analytical.u_analytical
            if V_fallback > self.V_max:
                recovery_used = True
                # Bounded search is a recovery heuristic, not a proof of
                # feasibility or global optimality for a nonlinear predictor.
                result = minimize_scalar(one_step, bounds=(-self.delta_max, self.delta_max),
                                         method='bounded', options={'xatol': 1e-7})
                candidates = [command, -self.delta_max, self.delta_max, 0.0]
                if result.success and np.isfinite(result.x):
                    candidates.append(float(result.x))
                command = min(candidates, key=one_step)
            self.delay.clear(hold_command=command)
        predicted = predictor(x_k, [command], gain_context)[0]
        V_applied = one_step(command)
        unresolved = not np.isfinite(V_applied) or V_applied > self.V_max
        return float(command), {
            'u_lqr': analytical.u_lqr, 'u_ff': analytical.u_ff,
            'u_analytical': analytical.u_analytical, 'residual_raw': float(ppo_residual),
            'authority': authority.alpha, 'authority_mode': authority.mode,
            'authority_rule': authority.rule, 'V_ratio': authority.V_ratio,
            'u_c': u_c, 'u_q': u_q, 'u_k': float(command),
            'V_pred': V_candidate, 'V_horizon': V_horizon,
            'V_fallback': V_fallback, 'V_applied': V_applied,
            'fallback_used': bool(fallback_used),
            'fallback_failed': bool(fallback_used and V_fallback > self.V_max),
            'recovery_used': recovery_used, 'recovery_unresolved': bool(unresolved),
            'envelope_risk': envelope_risk, 'recovery_latched': self.recovery_latched,
            'u_lqr_queued': queued_analytical.u_lqr,
            'predicted_state': predicted, 'prediction_mode': prediction_mode,
            'delay_ms': float(delay_ms), 'gain_context': float(gain_context),
            'queue_len': self.delay.queue_len,
            'command_age_steps': 0 if fallback_used else self.delay.last_age_steps,
        }
