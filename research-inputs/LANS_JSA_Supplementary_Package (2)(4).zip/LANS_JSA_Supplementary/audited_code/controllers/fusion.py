"""Fusion and steering clipping block."""

import numpy as np

from config import DELTA_MAX


class ResidualFusion:
    def __init__(self, delta_max=DELTA_MAX):
        self.delta_max = float(delta_max)

    def combine(self, u_lqr: float, u_ff: float, a_k: float,
                alpha_k: float) -> float:
        return float(np.clip(float(u_lqr) + float(u_ff)
                             + float(alpha_k) * float(a_k),
                             -self.delta_max, self.delta_max))
