"""Causal noise adaptation/innovation clipping; not a safety certificate."""
import numpy as np

class NoiseAwareEKF:
    def __init__(self,v=25.,dt=.01,L=2.6,q_bias=.0004,adaptive_noise=False,alpha=.2,r_factor=1.,clip_sigma=None,parameter_rates=None):
        self.v,self.dt,self.L=v,dt,L
        self.adaptive_noise=adaptive_noise;self.alpha=float(alpha);self.r_factor=float(r_factor);self.clip_sigma=clip_sigma;self.parameter_rates=parameter_rates
        self.q_bias=q_bias
        self.reset()
    def reset(self):
        self.z=None
        self.history=[];self.noise_variance=np.full(2,.0004*self.r_factor)
        self.P=np.diag([.0004,.0004,.25,.04,.0625])
    def update(self,y,psi,u):
        measurement=np.array([y,psi])
        if not np.all(np.isfinite(measurement)) or not np.isfinite(u):raise ValueError('Nonfinite measurement/input')
        if self.adaptive_noise and len(self.history)==2:
            d2=measurement-2*self.history[-1]+self.history[-2]
            # Independent noise contributes 6*variance to second differences.
            # Actual signal curvature also contributes: this is a heuristic.
            self.noise_variance=np.clip((1-self.alpha)*self.noise_variance+self.alpha*d2*d2/6.,.0004,.0225)
        self.history=(self.history+[measurement.copy()])[-2:]
        if self.z is None:
            self.z=np.array([y,psi,0.,0.,1.]);return self.z.copy()
        z=self.z.copy();dt=self.dt;rate=self.v*np.tan(u)/self.L
        F=np.eye(5);F[0,1]=self.v*np.cos(z[1])*dt;F[0,2]=dt;F[1,3]=dt;F[1,4]=rate*dt
        z[0]+=(self.v*np.sin(z[1])+z[2])*dt
        z[1]+=(z[4]*rate+z[3])*dt
        Q=np.diag([1e-7,1e-7,self.q_bias,self.q_bias*.25,1e-7])
        prior=F@self.P@F.T+Q
        H=np.zeros((2,5));H[0,0]=H[1,1]=1.
        R=np.diag(self.noise_variance)
        gain=np.linalg.solve(H@prior@H.T+R,H@prior).T
        innovation=measurement-H@z
        if self.clip_sigma is not None:
            bounds=self.clip_sigma*np.sqrt(np.diag(H@prior@H.T+R))
            innovation=np.clip(innovation,-bounds,bounds)
        z+=gain@innovation
        I=np.eye(5)-gain@H
        self.P=I@prior@I.T+gain@R@gain.T
        # Parameter projections are engineering bounds, not probabilistic guarantees.
        z[2]=np.clip(z[2],-1.5,1.5);z[3]=np.clip(z[3],-.6,.6);z[4]=np.clip(z[4],.5,1.5)
        if self.parameter_rates is not None:
            limit=np.asarray(self.parameter_rates)*dt
            z[2:]=np.clip(z[2:],self.z[2:]-limit,self.z[2:]+limit)
        self.z=z
        return z.copy()

