"""First-match residual-authority block.

The rule order is explicit because the framework diagram specifies a
first-match authority decision, not an averaged or learned gate.
"""

from dataclasses import dataclass

import numpy as np

from config import P_LQR, V_MAX


@dataclass(frozen=True)
class AuthorityDecision:
    alpha: float
    mode: str
    rule: str
    V_ratio: float


class FirstMatchResidualAuthority:
    def __init__(self, P=None, V_max=V_MAX):
        self.P = P_LQR.copy() if P is None else np.asarray(P, dtype=float)
        self.V_max = float(V_max)
        self.rules = (
            ("SAFE_V_CRITICAL", 100, lambda x, d, g, v: v > 0.90,
             "SAFE", 0.00),
            # Keep a small residual authority under delay.  The finite-horizon
            # quadratic check is the safety gate; disabling PPO completely at
            # 50 ms made the high-delay controller behave like delayed LQR.
            ("DELAY_HIGH_CONSERVATIVE", 90, lambda x, d, g, v: d >= 50.0,
             "DEGRADED", 0.15),
            ("RECOVERY_ERROR_LARGE", 80, lambda x, d, g, v: abs(x[0]) > 0.30,
             "RECOVERY", 0.00),
            ("UNCERTAIN_GAIN_OFFSET", 50, lambda x, d, g, v: abs(g - 1.0) > 0.02,
             "UNCERTAIN", 1.00),
            ("DEGRADED_DELAY_MED", 40, lambda x, d, g, v: 5.0 < d < 50.0,
             "DEGRADED", 0.30),
            ("NOMINAL_DEFAULT", 0, lambda x, d, g, v: True,
             "NOMINAL", 0.00),
        )

    def decide(self, x_k, delay_ms: float, gain_context: float = 1.0):
        x_k = np.asarray(x_k, dtype=float).reshape(4)
        v_ratio = float(x_k @ self.P @ x_k) / self.V_max
        delay_ms = float(delay_ms)
        gain_context = float(gain_context)
        for name, _priority, predicate, mode, alpha in self.rules:
            if predicate(x_k, delay_ms, gain_context, v_ratio):
                return AuthorityDecision(alpha=alpha, mode=mode, rule=name,
                                         V_ratio=v_ratio)
        return AuthorityDecision(alpha=0.0, mode="NOMINAL",
                                 rule="NOMINAL_DEFAULT", V_ratio=v_ratio)
