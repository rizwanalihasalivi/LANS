"""Local feedback with an asynchronous, expiring remote residual channel.

Only the neural channel is delayed here. This does NOT compensate a delayed
actuator/sensor/local controller. All comparison baselines get the same local path.
"""
from collections import deque
import heapq
import numpy as np
from scipy.linalg import solve_discrete_are
from controllers.adaptive_observer import ObservedController, BiasPrediction

class ResidualMailbox:
    def __init__(self,dt=.01,ttl_ms=200.):
        self.dt=dt;self.ttl_ms=float(ttl_ms);self.buffer=deque();self.reset()
    def reset(self):
        self.pending=[];self.buffer.clear();self.tick=0;self.last_generated=None
        self.last_output=0.;self.last_age_steps=-1;self.available=True;self.rejected=0
    def push(self,command,delay_ms):
        if not np.isfinite(command) or not np.isfinite(delay_ms) or delay_ms<0:
            raise ValueError('Residual and nonnegative delay must be finite')
        if self.available:
            heapq.heappush(self.pending,(self.tick+round(delay_ms/(1000*self.dt)),self.tick,float(command)))
        while self.pending and self.pending[0][0]<=self.tick:
            _,generated,value=heapq.heappop(self.pending)
            if self.available and (self.last_generated is None or generated>self.last_generated):
                self.last_generated=generated;self.last_output=value
            else:self.rejected+=1
        self.last_age_steps=-1 if self.last_generated is None else self.tick-self.last_generated
        age_ms=self.last_age_steps*self.dt*1000
        valid=self.last_generated is not None and age_ms<=self.ttl_ms
        output=self.last_output*np.exp(-age_ms/100.) if valid else 0.
        self.buffer.clear();self.buffer.extend(p[2] for p in sorted(self.pending))
        self.tick+=1
        return float(output)
    @property
    def queue_len(self):return len(self.pending)

class SplitController(ObservedController):
    def __init__(self,vx=25.,dt=.01,L=2.6,q_bias=.0016,gain_scale=1.,gate=True):
        self.remote=ResidualMailbox(dt)
        super().__init__(vx,dt,L,q_bias,True)
        self.gain_scale=float(gain_scale);self.gate=bool(gate)
        self.inner.analytical.base.gain*=self.gain_scale
        A=np.array([[1.,vx*dt],[0.,1.]])
        B=np.array([[0.],[vx*dt/L]])
        self.S=solve_discrete_are(A,B,np.diag([1.,4.]),np.array([[10.]]))
        self.arrived_residual=0.;self.accepted_residual=0.
    @property
    def delay(self):return self.remote
    def reset(self):
        super().reset();self.remote.reset();self.arrived_residual=0.;self.accepted_residual=0.
    def step(self,x_k,ppo_residual,delay_ms=0.,gain_context=1.,kappa_k=0.,predictor=None):
        if predictor is None:raise ValueError('Reference predictor required')
        self.prepare(x_k,predictor)
        residual=self.remote.push(ppo_residual,delay_ms)
        self.arrived_residual=residual
        base=self.analytical.compute(self.filtered,kappa_k).u_analytical
        candidate=float(np.clip(base+residual,-.5,.5))
        p=BiasPrediction(predictor,*self.estimates)
        def cost(u):
            z=p(self.filtered,[u])[0]
            error=np.array([z[0],z[2]+np.arcsin(np.clip(self.estimates[0]/self.vx,-.5,.5))])
            return float(error@self.S@error+10.*u*u)
        rejected=self.gate and residual!=0. and cost(candidate)>=cost(base)
        if rejected:residual=0.
        self.accepted_residual=residual
        # The inner controller operates locally: its ACTUATOR delay is zero.
        u,info=self.inner.step(self.filtered,residual,0.,self.estimates[2],kappa_k,p)
        self.last_u=u
        info.update(remote_delay_ms=float(delay_ms),delay_ms=float(delay_ms),
            actuator_delay_ms=0.,remote_age_steps=self.remote.last_age_steps,
            queue_len=self.remote.queue_len,remote_available=self.remote.available,
            remote_residual_arrived=self.arrived_residual,remote_residual_accepted=residual,
            residual_rejected=bool(rejected),estimated_lateral_bias=float(self.estimates[0]),
            estimated_yaw_bias=float(self.estimates[1]),estimated_gain=float(self.estimates[2]))
        return u,info
