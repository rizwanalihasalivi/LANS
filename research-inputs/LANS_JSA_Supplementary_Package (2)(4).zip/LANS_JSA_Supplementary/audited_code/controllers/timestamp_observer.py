"""Known-timestamp delayed pose update, then causal forward prediction.
Uses measured steering history. No true gain/disturbance or actuator parameters.
"""
import numpy as np
from controllers.split_controller import SplitController

class TimestampController(SplitController):
    def reset(self):
        super().reset();self.last_pose_stamp=None;self.pose_stamp=0;self.now_tick=0;self.executed_inputs=[]
    def prepare(self,x,predictor):
        if self.last_position==predictor.position:return
        p=predictor;self.current_predictor=p;stamp=self.pose_stamp
        if self.last_pose_stamp is None or stamp>self.last_pose_stamp:
            # Fixed sensor delay yields consecutive delivered timestamps; repeated
            # initial/held observations are not assimilated a second time.
            if self.last_pose_stamp is not None and stamp!=self.last_pose_stamp+1:
                raise ValueError('This filter requires ordered consecutive pose packets')
            previous=self.executed_inputs[stamp-1] if stamp>0 else 0.
            z=self.filter.update(p.y_ref(p.position)+x[0],p.heading(p.position)+x[2],previous)
            self.last_pose_stamp=stamp
        else:z=self.filter.z.copy()
        # Do not overwrite delayed filter state with a propagated state.
        z=z.copy()
        for u in self.executed_inputs[stamp:self.now_tick]:
            z[0]+=(self.vx*np.sin(z[1])+z[2])*self.dt
            z[1]+=(z[4]*self.vx*np.tan(u)/self.L+z[3])*self.dt
        self.estimates=z[2:].copy()
        ey=z[0]-p.y_ref(p.position);ep=z[1]-p.heading(p.position)
        actual=self.executed_inputs[-1] if self.executed_inputs else 0.
        self.filtered=np.array([ey,self.vx*np.sin(ep),ep,z[4]*self.vx*np.tan(actual)/self.L-self.vx*p.curvature(p.position)])
        self.last_position=p.position
