"""Arrival-state feedback plus measured-steering damping.
Uses own queued commands and a FIXED nominal actuator model (not test-profile truth).
"""
import numpy as np
from controllers.adaptive_observer import BiasPrediction
from controllers.analytical_branch import AnalyticalCommand

class TransportFeedback:
    def __init__(self,owner,base,damping=1.,nominal_tau=.08,nominal_rate=.7):
        self.owner=owner;self.base=base;self.damping=damping;self.nominal_tau=nominal_tau;self.nominal_rate=nominal_rate
    def compute(self,x,kappa):
        c=self.owner;p=c.current_predictor
        actual=c.executed_inputs[-1] if c.executed_inputs else 0.
        commands=[]
        for target in getattr(c,'known_command_sequence',[]):
            movement=np.clip((-np.expm1(-c.dt/self.nominal_tau))*(target-actual),-self.nominal_rate*c.dt,self.nominal_rate*c.dt)
            actual=float(np.clip(actual+movement,-.5,.5));commands.append(actual)
        future=x;position=p.position
        if commands:
            future=BiasPrediction(p,*c.estimates)(x,commands)[-1]
            position+=c.vx*c.dt*len(commands);kappa=p.curvature(position)
        # MPC reference preview must start at the same estimated arrival position.
        self.base.control_position=position
        desired=self.base.compute(future,kappa).u_analytical
        command=float(np.clip(desired+self.damping*(desired-actual),-.5,.5))
        return AnalyticalCommand(command,0.,command)
