"""Nominal Euler rollout from measured errors, without true gain/disturbances.

Reference sampling and integration match the simulation. The retained P is a
diagnostic quadratic metric, not a kinematic stability certificate.
"""
import numpy as np


class KinematicPrediction:
    def __init__(self, position, vx, dt, wheelbase, delta_max,
                 reference_y, reference_heading, reference_curvature):
        self.position = float(position)
        self.vx, self.dt, self.L = vx, dt, wheelbase
        self.delta_max = delta_max
        self.y_ref, self.heading, self.curvature = reference_y, reference_heading, reference_curvature

    def __call__(self, x, commands, gain=1.0):
        px = self.position
        py = self.y_ref(px) + float(x[0])
        psi = self.heading(px) + float(x[2])
        states = []
        for command in commands:
            u = float(np.clip(command, -self.delta_max, self.delta_max))
            px += self.vx * np.cos(psi) * self.dt
            py += self.vx * np.sin(psi) * self.dt
            yaw_rate = gain * self.vx * np.tan(u) / self.L
            psi += yaw_rate * self.dt
            ep = psi - self.heading(px)
            states.append([py - self.y_ref(px), self.vx * np.sin(ep),
                           ep, yaw_rate - self.vx * self.curvature(px)])
        return np.asarray(states, dtype=float).reshape(-1, 4)
