import argparse,csv,gzip,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv,VecNormalize
from scripts.stress_env import PROFILES
from scripts.noise_env import NoiseEnv
from scripts.strong_baselines import IntegralLQR
ROOT=Path('noise_results')

def main(worker,workers):
    torch.set_num_threads(1);cfg=json.loads((ROOT/'controller_selection.json').read_text())['configs'];noise=json.loads((ROOT/'selection.json').read_text())['noise_configs'];cache={}
    for seed in [42,43,44]:
        base=Path('robustness_models')/f'ppo_seed{seed}'
        norm=VecNormalize.load(str(base)+'_norm.pkl',DummyVecEnv([lambda:NoiseEnv()]));norm.training=False;norm.norm_reward=False
        cache[seed]=(PPO.load(str(base),device='cpu'),norm)
    cases=[]
    for es in [2300,2301,2302,2303,2304]:
        for path in ['dlc','sine_noise_test','chirp_noise_test']:
            for profile in PROFILES:
                for method,seed in [('new_zero',-1),('original_mpc',-1),('selected_mpc',-1)]+[(m,s) for m in ['original_lans','new_lans'] for s in [42,43,44]]:
                    cases.append(dict(case_id=len(cases),method=method,train_seed=seed,eval_seed=es,path=path,profile=profile))
    if worker==0:(ROOT/'final_cases.json').write_text(json.dumps(cases,indent=2))
    with (ROOT/f'part{worker}_episodes.csv').open('w',newline='') as f,gzip.open(ROOT/f'part{worker}_traces.csv.gz','wt',newline='') as tf:
        w=None;tw=csv.writer(tf);tw.writerow(['case_id','tick','lateral_error','heading_error','commanded_steering','actual_steering','pose_age_steps','actuator_delay_ms','remote_delay_ms','accepted_residual','fallback','recovery_unresolved','quadratic_exceeded','estimated_gain','estimated_yaw_bias','estimated_drift'])
        completed=0
        for c in cases:
            if c['case_id']%workers!=worker:continue
            args=dict(profile=c['profile'],path=c['path'],heldout=True)
            if c['method'] in ('original_mpc','selected_mpc'):
                nc=None if c['method']=='original_mpc' else noise['mpc']
                e=NoiseEnv(**args,**cfg['mpc'],noise_config=nc)
            else:
                nc=None if c['method']=='original_lans' else noise['lans']
                e=NoiseEnv(**args,**cfg['lans'],noise_config=nc,residual_scale=.01)
            obs,_=e.reset(seed=c['eval_seed']);errors=[float(e.state[0])];headings=[float(e.state[2])];rates=[];last=0.;fallback=unresolved=envelope=accepted=0
            for tick in range(1000):
                if c['train_seed']<0:a=np.zeros(1)
                else:
                    model,norm=cache[c['train_seed']];a=model.predict(norm.normalize_obs(obs[None,:]),deterministic=True)[0][0]
                obs,_,term,trunc,info=e.step(a)
                errors.append(info['error']);headings.append(e.state[2]);rates.append((e.actual_delta-last)/e.dt);last=e.actual_delta
                fallback+=int(info['fallback_used']);unresolved+=int(info['recovery_unresolved']);envelope+=int(abs(e.state[0])>.3 or abs(e.state[2])>.06);accepted+=int(info.get('remote_residual_accepted',0.)!=0.)
                tw.writerow([c['case_id'],tick,info['error'],e.state[2],info['commanded_steering'],info['actual_steering'],info['pose_age_steps'],e.settings['command_ms'],info['delay_ms'],info.get('remote_residual_accepted',0.),int(info['fallback_used']),int(info['recovery_unresolved']),int(info['actual_V_exceeded']),info.get('estimated_gain',float('nan')),info.get('estimated_yaw_bias',float('nan')),info.get('estimated_lateral_bias',float('nan'))])
                if term or trunc:break
            sumsq=float(np.sum(np.square(errors)));padding=max(2.5,abs(errors[-1]))
            row=dict(c,initial_error_m=errors[0],initial_heading_rad=headings[0],steps=len(errors)-1,terminated=term,survived=not term,rmse_m=float(np.sqrt(sumsq/len(errors))),failure_penalized_rmse_m=float(np.sqrt((sumsq+(1001-len(errors))*padding**2)/1001)),max_error_m=float(np.max(np.abs(errors))),max_heading_rad=float(np.max(np.abs(headings))),steering_rate_rms=float(np.sqrt(np.mean(np.square(rates)))),fallbacks=fallback,recovery_unresolved=unresolved,envelope_exceeded=envelope,accepted_residual_steps=accepted,actuator_tau=e.settings['tau'],actuator_rate_limit=e.settings['rate'],sensor_ms=e.settings['sensor_ms'],actuator_command_ms=e.settings['command_ms'])
            if w is None:w=csv.DictWriter(f,fieldnames=list(row));w.writeheader()
            w.writerow(row);f.flush();e.close()
            completed+=1
            if completed%20==0:print('WORKER',worker,completed,'/',len(cases[worker::workers]),flush=True)
    for _,norm in cache.values():norm.close()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--worker',type=int,default=0);p.add_argument('--workers',type=int,default=1);a=p.parse_args()
    if not 0<=a.worker<a.workers:raise ValueError('Invalid worker index')
    main(a.worker,a.workers)
