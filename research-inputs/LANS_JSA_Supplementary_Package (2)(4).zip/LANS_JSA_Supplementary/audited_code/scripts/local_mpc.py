"""Matched local finite-horizon linear MPC with box steering constraints.
Same pose/bias observer as split LANS, same fresh sensing/actuator access.
The tangent-steering/nonlinear plant is approximated in the QP; no safety proof.
"""
import numpy as np
from scipy.linalg import solve_discrete_are,block_diag
from scipy.optimize import minimize
from controllers.analytical_branch import AnalyticalCommand
from scripts.observer_env import ObserverEnv

class MPCBranch:
    def __init__(self,env,horizon=12,q_scale=1.):
        self.env=env;self.H=horizon;v=env.vx;dt=env.dt;L=env.L
        self.A=np.array([[1.,v*dt],[0.,1.]])
        B=np.array([[0.],[v*dt/L]]);Q=np.diag([1.,4.])*q_scale
        S=solve_discrete_are(self.A,B,Q,np.array([[10.]]))
        self.W=block_diag(*([Q]*(horizon-1)+[S]))
        self.F=np.vstack([np.linalg.matrix_power(self.A,i+1) for i in range(horizon)])
        self.G=np.zeros((2*horizon,horizon))
        for i in range(horizon):
            for j in range(i+1):self.G[2*i:2*i+2,j]=(np.linalg.matrix_power(self.A,i-j)@B).ravel()
        self.GW=self.G.T@self.W;self.H0=self.GW@self.G
        self.last_key=None;self.last_command=None
    def compute(self,x,kappa):
        e=self.env;dy,dp,g=e.framework_controller.estimates
        position=getattr(self,'control_position',e.x_position)
        key=(float(x[0]),float(x[2]),float(dy),float(dp),float(g),position)
        if key==self.last_key:return self.last_command
        c=np.zeros(2);offset=[]
        for i in range(self.H):
            curv=e._get_reference_curvature(position+e.vx*e.dt*i)
            c=self.A@c+np.array([dy*e.dt,dp*e.dt-e.vx*e.dt*curv]);offset.extend(c)
        free=self.F@np.array([x[0],x[2]])+np.asarray(offset)
        h=g*g*self.H0+10.*np.eye(self.H);b=g*self.GW@free
        u=-np.linalg.solve(h,b)
        if np.max(np.abs(u))>.5:
            result=minimize(lambda z:(float(z@h@z+2*b@z),2*(h@z+b)),np.clip(u,-.5,.5),jac=True,bounds=[(-.5,.5)]*self.H,method='L-BFGS-B')
            if result.success:u=result.x
            else:u=np.clip(u,-.5,.5)
        command=float(np.clip(u[0],-.5,.5))
        self.last_key=key;self.last_command=AnalyticalCommand(command,0.,command)
        return self.last_command

class LocalMPCEnv(ObserverEnv):
    def __init__(self,*,q_scale=1.,q_bias=.0064,**kwargs):
        super().__init__(q_bias=q_bias,**kwargs)
        self.framework_controller.inner.analytical=MPCBranch(self,q_scale=q_scale)
