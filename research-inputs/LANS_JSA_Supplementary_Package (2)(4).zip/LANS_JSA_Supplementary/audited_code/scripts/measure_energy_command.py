"""Optional real Linux powercap measurement; never substitutes TDP estimates.
Example: python scripts/measure_energy_command.py --output energy.csv -- python workload.py
Measures whole CPU package domains during a command, not isolated process energy.
"""
import argparse,csv,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',default='energy_measurement.csv');p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();cmd=a.command[1:] if a.command[:1]==['--'] else a.command
if not cmd:raise SystemExit('Provide a workload after --')
# Top-level package domains only; do not double-count child/core domains.
paths=[]
for base in [Path('/sys/class/powercap'),Path('/sys/devices/virtual/powercap')]:
 if base.exists():
  for energy in base.glob('**/energy_uj'):
   try:
    name=(energy.parent/'name').read_text().strip()
    if name.startswith('package-') and energy.resolve() not in paths:paths.append(energy.resolve())
   except OSError:pass
records=[]
for f in paths:
 try:records.append((f,int(f.read_text()),int((f.parent/'max_energy_range_uj').read_text())))
 except (OSError,ValueError):pass
if not records:
 with open(a.output,'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['status','joules','seconds','mean_watts']);w.writeheader();w.writerow(dict(status='UNAVAILABLE_NO_READABLE_PACKAGE_COUNTER'))
 raise SystemExit('No readable package energy counter; no energy value fabricated and workload not run.')
start=time.perf_counter();result=subprocess.run(cmd,check=False);elapsed=time.perf_counter()-start
with open(a.output,'w',newline='') as out:
 w=csv.DictWriter(out,fieldnames=['status','counter','joules','seconds','mean_watts','workload_exit_code']);w.writeheader()
 for f,before,modulus in records:
  after=int(f.read_text());joules=((after-before)%modulus)/1e6
  w.writerow(dict(status='MEASURED_PACKAGE_NOT_PROCESS; assumes_at_most_one_counter_wrap',counter=str(f),joules=joules,seconds=elapsed,mean_watts=joules/elapsed,workload_exit_code=result.returncode))
