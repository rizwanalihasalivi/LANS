import argparse,gzip,shutil
from pathlib import Path
import pandas as pd
root=Path('noise_results');p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=1);a=p.parse_args()
parts=[pd.read_csv(root/f'part{i}_episodes.csv') for i in range(a.workers)]
x=pd.concat(parts).sort_values('case_id');assert len(x)==945 and x.case_id.nunique()==945
assert x.case_id.tolist()==list(range(945));x.to_csv(root/'final_episodes.csv',index=False)
with gzip.open(root/'final_traces.csv.gz','wt') as out:
    for i in range(a.workers):
        with gzip.open(root/f'part{i}_traces.csv.gz','rt') as f:
            header=next(f)
            if i==0:out.write(header)
            shutil.copyfileobj(f,out)
print('Merged 945 episodes; all case IDs unique and complete.')
