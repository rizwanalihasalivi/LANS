import csv,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from scripts.noise_env import NoiseEnv
from scripts.stress_env import PROFILES
from scripts.robust_development import run
ROOT=Path('noise_results')
CANDIDATES={'original':None,'fixed4':dict(r_factor=4.),'fixed16':dict(r_factor=16.),'adaptive_slow':dict(adaptive_noise=True,alpha=.1),'adaptive_fast':dict(adaptive_noise=True,alpha=.3),'adaptive_clip':dict(adaptive_noise=True,alpha=.2,clip_sigma=3.)}
if __name__=='__main__':
    cfg=json.loads((ROOT/'controller_selection.json').read_text())['configs'];rows=[]
    for controller in ['lans','mpc']:
        for name,noise in CANDIDATES.items():
            for seed in [210,211]:
                for path in ['dlc','sine_robust_test']:
                    for profile in PROFILES:
                        e=NoiseEnv(path=path,profile=profile,heldout=True,**cfg[controller],noise_config=noise)
                        result=run(e,seed);e.close();rows.append(dict(controller=controller,candidate=name,seed=seed,path=path,profile=profile,**result))
            r=[x for x in rows if x['controller']==controller and x['candidate']==name]
            print(controller,name,sum(x['terminated'] for x in r),max(x['max_error_m'] for x in r),np.mean([x['rmse_m'] for x in r]),flush=True)
            with (ROOT/'development.csv').open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    def score(controller,name):
        r=[x for x in rows if x['controller']==controller and x['candidate']==name]
        return [int(sum(x['terminated'] for x in r)),float(max(x['max_error_m'] for x in r)),float(np.mean([x['rmse_m'] for x in r]))]
    selected={c:min(CANDIDATES,key=lambda n:score(c,n)) for c in ['lans','mpc']}
    (ROOT/'selection.json').write_text(json.dumps(dict(selected=selected,noise_configs={c:CANDIDATES[n] for c,n in selected.items()},scores={c:{n:score(c,n) for n in CANDIDATES} for c in ['lans','mpc']},criterion='Fewest terminations, then smallest observed peak, then mean RMSE. Original filter is eligible for each controller.'),indent=2))
