from scripts.stress_env import RobustEnv
from controllers.noise_observer import NoiseAwareEKF

class NoiseEnv(RobustEnv):
    def __init__(self,*,noise_config=None,**kwargs):
        super().__init__(**kwargs)
        if noise_config is not None:
            q=self.framework_controller.filter.q_bias
            self.framework_controller.filter=NoiseAwareEKF(self.vx,self.dt,self.L,q,**noise_config)
