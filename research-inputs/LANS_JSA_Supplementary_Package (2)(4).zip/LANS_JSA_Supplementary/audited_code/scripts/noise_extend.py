import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
from scripts.noise_development import ROOT,CANDIDATES
from scripts.noise_env import NoiseEnv
from scripts.stress_env import PROFILES
from scripts.robust_development import run
new={'rate_only':dict(parameter_rates=[2.,1.,.5]),'rate_slow':dict(parameter_rates=[1.,.5,.25]),'adaptive_rate':dict(adaptive_noise=True,alpha=.1,parameter_rates=[2.,1.,.5]),'clipped_rate':dict(adaptive_noise=True,alpha=.2,clip_sigma=3.,parameter_rates=[2.,1.,.5])}
CANDIDATES.update(new)
if __name__=='__main__':
    cfg=json.loads((ROOT/'controller_selection.json').read_text())['configs'];rows=pd.read_csv(ROOT/'development.csv').to_dict('records')
    assert len(rows)==336,'Run noise_development.py to completion first'
    for controller in ['lans','mpc']:
        for name,noise in new.items():
            for seed in [210,211]:
                for path in ['dlc','sine_robust_test']:
                    for profile in PROFILES:
                        e=NoiseEnv(path=path,profile=profile,heldout=True,**cfg[controller],noise_config=noise)
                        result=run(e,seed);e.close();rows.append(dict(controller=controller,candidate=name,seed=seed,path=path,profile=profile,**result))
            r=[x for x in rows if x['controller']==controller and x['candidate']==name]
            print(controller,name,sum(x['terminated'] for x in r),max(x['max_error_m'] for x in r),np.mean([x['rmse_m'] for x in r]),flush=True)
            pd.DataFrame(rows).to_csv(ROOT/'development.csv',index=False)
    def score(controller,name):
        r=[x for x in rows if x['controller']==controller and x['candidate']==name]
        return [int(sum(x['terminated'] for x in r)),float(max(x['max_error_m'] for x in r)),float(np.mean([x['rmse_m'] for x in r]))]
    selected={c:min(CANDIDATES,key=lambda n:score(c,n)) for c in ['lans','mpc']}
    (ROOT/'selection.json').write_text(json.dumps(dict(selected=selected,noise_configs={c:CANDIDATES[n] for c,n in selected.items()},all_candidates=CANDIDATES,scores={c:{n:score(c,n) for n in CANDIDATES} for c in ['lans','mpc']},criterion='Fewest terminations, smallest observed peak, then mean RMSE. Original filter eligible for each controller.'),indent=2))
