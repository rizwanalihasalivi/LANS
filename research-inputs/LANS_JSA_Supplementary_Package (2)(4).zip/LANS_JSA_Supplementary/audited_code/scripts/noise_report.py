"""Describe all frozen cases, retaining failures and paired comparisons."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path('noise_results')
x=pd.read_csv(ROOT/'final_episodes.csv');assert len(x)==945 and x.case_id.nunique()==945

def aggregate(frame,keys):
    s=frame.groupby(keys).agg(episodes=('steps','size'),survived=('survived','sum'),worst_observed_m=('max_error_m','max'),mean_rmse_m=('rmse_m','mean'),failure_penalized_rmse_m=('failure_penalized_rmse_m','mean'),simulated_steps=('steps','sum'),envelope_exceeded_steps=('envelope_exceeded','sum'))
    s.insert(2,'survival_percent',100*s.survived/s.episodes)
    return s

def table(frame):
    d=frame.reset_index();lines=['| '+' | '.join(d.columns)+' |','| '+' | '.join(['---']*len(d.columns))+' |']
    for row in d.itertuples(index=False,name=None):lines.append('| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |')
    return '\n'.join(lines)
s=aggregate(x,'method');s.to_csv(ROOT/'summary.csv')
for keys,name in [(['method','profile'],'profiles'),(['method','path'],'paths'),(['method','train_seed'],'training_seeds'),(['method','eval_seed'],'evaluation_seeds')]:aggregate(x,keys).to_csv(ROOT/(name+'.csv'))
keys=['eval_seed','path','profile'];rows=[]
for a,b in [('new_lans','original_lans'),('new_lans','new_zero'),('new_lans','original_mpc'),('new_lans','selected_mpc')]:
    left=x[x.method==a].groupby(keys)[['survived','rmse_m','failure_penalized_rmse_m']].mean()
    right=x[x.method==b].groupby(keys)[['survived','rmse_m','failure_penalized_rmse_m']].mean()
    p=left.join(right,lsuffix='_a',rsuffix='_b',validate='one_to_one');assert len(p)==105
    p.to_csv(ROOT/f'paired_{a}_vs_{b}.csv')
    rows.append(dict(comparison=f'{a} minus {b}',paired_cells=len(p),survival_difference_pp=100*(p.survived_a-p.survived_b).mean(),mean_rmse_difference_m=(p.rmse_m_a-p.rmse_m_b).mean(),penalized_rmse_difference_m=(p.failure_penalized_rmse_m_a-p.failure_penalized_rmse_m_b).mean()))
paired=pd.DataFrame(rows).set_index('comparison');paired.to_csv(ROOT/'paired_summary.csv')
selected=json.loads((ROOT/'selection.json').read_text())['selected']
cols=['episodes','survived','survival_percent','worst_observed_m','mean_rmse_m','failure_penalized_rmse_m']
l=s.loc['new_lans'];m=s.loc['selected_mpc'];beats=bool(l.survival_percent>m.survival_percent);dominates=bool(l.survival_percent>=m.survival_percent and l.worst_observed_m<=m.worst_observed_m and l.mean_rmse_m<=m.mean_rmse_m)
report=f'''# LANS noise-observer experiment — frozen validation

Strictly higher observed survival than the independently selected MPC: **{beats}**.
No worse on survival, observed peak and ordinary mean RMSE simultaneously: **{dominates}**.
These are finite empirical comparisons, not universal rankings or safety guarantees.

## Results on the same new test cells

{table(s[cols])}

`original_lans` and `new_lans` each include all three previously trained policies; other methods run once per physical test cell. `new_zero` disables only the PPO residual. `selected_mpc` gets the same ten noise-filter choices as LANS. The frozen development choices were {selected}.

## Paired changes

{table(paired)}

For each physical cell, the three PPO policies are averaged before pairing against a baseline. Positive survival difference favors the first method; negative RMSE difference favors it. There are 105 physical cells, not 315 independent test scenarios for LANS. Five evaluation seeds and three old training seeds do not establish statistical superiority across arbitrary conditions. Historical 95.24% versus 96.83% came from a different test set; compare old and new methods within this table instead.

## Training seeds

{table(aggregate(x[x.method.isin(['new_lans','original_lans'])],['method','train_seed'])[cols])}

## Stress profiles

{table(aggregate(x,['method','profile'])[cols])}

## What changed and what was tested

A timestamp-aware EKF can now estimate pose measurement variance from causal second differences, clip innovations, or limit the rate of change of disturbance/gain estimates. Ten candidates were tested independently for each controller on the same 28 development cells: 560 development episodes. Selection uses fewest failures, then lowest observed peak error, then lowest mean RMSE. All candidates and failures are retained. The original filter was eligible.

The variance estimator uses EWMA(second_difference**2/6), bounded between 0.0004 and 0.0225 per pose component. Actual signal curvature can inflate this estimate; it is a heuristic. Rate constraints are engineering priors on lateral disturbance, yaw disturbance and steering gain, not access to hidden simulator parameters. They can miss abrupt real changes. Projected EKF covariance is not a calibrated uncertainty certificate. Repeated delayed pose packets are not assimilated again.

No new PPO training occurred in this experiment. Three frozen 37-feature policies, previously trained for 51,200 steps each, and their original normalization were reused. Observer changes cause observation-distribution shift; transfer was tested, not assumed. Controller gains, residual limit (0.01 rad), reward, termination threshold and physical stress definitions stayed unchanged. PPO expires when the latest remote packet is older than 200 ms, so local analytical control carries prolonged outages.

Final validation was frozen before execution: five seeds 2300–2304, three trajectories, seven stress profiles, nine executions per cell = 945 episodes. New sine is 2*sin(2*pi*0.18*t); chirp is 1.3*sin(2*pi*(0.05*t+0.016*t*t)). DLC is also retained. Validation was not used to change parameters or select policy seeds. Source/model/config hashes are recorded before validation.

## Physical fairness and interpretation

Every method sees the same seeded disturbances, sensor noise, delayed pose, actuator lag/rate limits, steering saturation and whole-command delay. Fallback commands use the same actuator path and cannot bypass it. The arrival predictor uses a fixed nominal actuator time constant/rate, not the hidden actual parameters. Fresh measured steering and longitudinal position are assumed available to all methods. The MPC is the provided finite-horizon linear MPC, not every possible MPC design.

Survival means completing 10 seconds without |lateral error| > 2.5 m. It does not mean collision avoidance or lane compliance. The separate tighter diagnostic envelope is |lateral error| <= 0.3 m and |heading error| <= 0.06 rad. Worst observed error includes initial state and samples until termination; it is not a mathematical worst-case bound. A small difference in peak error near the failure cutoff is weak evidence about robustness.

Ordinary RMSE uses available samples and may favor short failed runs. Failure-penalized RMSE fills the remainder of the 10-second horizon with max(2.5 m, last absolute error). This is an explicit artificial penalty, not a simulated continuation. Raw traces, initial errors, all failures and per-profile/per-seed tables are included so the ranking can be audited.

The model remains a constant-speed kinematic simulation without tire slip, friction limits, obstacles or emergency braking. No Lyapunov/invariant-set guarantee for the delayed saturated nonlinear system has been proven. Novelty, hardware timing, energy claims and the full revised manuscript have not been revalidated by this experiment. It does not clear all reviewer comments.
'''
(ROOT/'NOISE_REPORT.md').write_text(report)
x[x.terminated].to_csv(ROOT/'failed_episodes.csv',index=False)
print(s[cols].to_string());print(paired.to_string());print('STRICT SURVIVAL WIN:',beats,'ALL THREE NO WORSE:',dominates)
