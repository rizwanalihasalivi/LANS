import numpy as np
from gymnasium import spaces
from scripts.optimization_env import OptimizationEnv
from controllers.adaptive_observer import ObservedController
from models.kinematic_prediction import KinematicPrediction

class ObserverEnv(OptimizationEnv):
    def __init__(self,*,q_bias=.0004,adaptive=True,**kwargs):
        self.ready=False
        super().__init__(**kwargs)
        self.framework_controller=ObservedController(self.vx,self.dt,self.L,q_bias,adaptive)
        self.delay_buffer=self.framework_controller.delay.buffer
        self.observation_space=spaces.Box(-np.inf,np.inf,shape=(31,),dtype=np.float32)
        self.ready=True
    def _get_observation(self,x_ctrl=None):
        if not self.ready:return super()._get_observation(x_ctrl)
        x=self._measurement if x_ctrl is None else x_ctrl
        predictor=KinematicPrediction(self.x_position,self.vx,self.dt,self.L,.5,self._get_reference_y,self._get_reference_heading,self._get_reference_curvature)
        self.framework_controller.prepare(x,predictor)
        obs=super()._get_observation(self.framework_controller.filtered)
        return np.concatenate([obs,self.framework_controller.estimates]).astype(np.float32)
    def step(self,action):
        # The parent writes its three memory features into the last three slots;
        # restore layout explicitly because this observer appends three estimates.
        obs,r,t,tr,info=super().step(action)
        obs[25:28]=self.memory;obs[28:31]=self.framework_controller.estimates
        return obs,r,t,tr,info
