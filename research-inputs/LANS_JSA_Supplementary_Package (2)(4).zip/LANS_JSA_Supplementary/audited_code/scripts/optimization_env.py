"""Small normalized residual, zero-start policy, mixed training conditions.

This changes policy parameterization and training reward, not the plant or
supervisor. Baselines use exactly the same controller and disturbances.
"""
import numpy as np
from gymnasium import spaces
from scripts.reviewer_env import ReviewerEnv

class OptimizationEnv(ReviewerEnv):
    def __init__(self, *, residual_scale=.03, mixed_training=False,
                 reward_mode='tracking', context_gate=False, path='dlc', difficulty=1.,
                 delay_range=(0.,200.), **kwargs):
        self.context_gate=bool(context_gate)
        self.residual_scale=float(residual_scale)
        self.mixed_training=mixed_training
        self.reward_mode=reward_mode
        self.memory=np.zeros(3,dtype=np.float32)
        super().__init__(path=path,difficulty=difficulty,delay_range=delay_range,**kwargs)
        self.framework_controller.authority_override=1.
        self.action_space=spaces.Box(-1.,1.,shape=(1,),dtype=np.float32)
        self.observation_space=spaces.Box(-np.inf,np.inf,shape=(28,),dtype=np.float32)
        self.previous_action=0.

    def reset(self, *, seed=None, options=None):
        # Seed before drawing curriculum context, then let the base reuse the RNG.
        if seed is not None:
            self.np_random=np.random.default_rng(seed)
        if self.mixed_training:
            difficulty=float(self.np_random.choice([0.,.5,1.]))
            self.difficulty=difficulty
            self.plant_gain_range=(1-.25*difficulty,1+.25*difficulty)
            self.disturbance_amp=.5*difficulty
            self.sensor_noise_std=.02*difficulty
        self.memory[:]=0.;self.previous_action=0.
        return super().reset(seed=None,options=options)

    def _generate_reference_path(self):
        if self.path not in ('sine_new','chirp_new','sine_observer_test','chirp_observer_test','sine_latency_test','chirp_latency_test','sine_robust_test','chirp_robust_test','sine_noise_test','chirp_noise_test'):
            return super()._generate_reference_path()
        t=np.arange(0.,10.01,self.dt)
        if self.path=='sine_noise_test':
            self.y_ref=2.0*np.sin(2*np.pi*.18*t)
        elif self.path=='chirp_noise_test':
            self.y_ref=1.3*np.sin(2*np.pi*(.05*t+.016*t*t))
        elif self.path=='sine_robust_test':
            self.y_ref=1.8*np.sin(2*np.pi*.21*t)
        elif self.path=='chirp_robust_test':
            self.y_ref=1.2*np.sin(2*np.pi*(.08*t+.014*t*t))
        elif self.path=='sine_latency_test':
            self.y_ref=2.*np.sin(2*np.pi*.23*t)
        elif self.path=='chirp_latency_test':
            self.y_ref=1.4*np.sin(2*np.pi*(.07*t+.018*t*t))
        elif self.path=='sine_observer_test':
            self.y_ref=2.4*np.sin(2*np.pi*.19*t)
        elif self.path=='chirp_observer_test':
            self.y_ref=1.6*np.sin(2*np.pi*(.06*t+.012*t*t))
        elif self.path=='sine_new':
            self.y_ref=2.2*np.sin(2*np.pi*.13*t)
        else:
            self.y_ref=1.8*np.sin(2*np.pi*(.04*t+.015*t*t))
        return self.y_ref

    def _get_observation(self,x_ctrl=None):
        return np.concatenate([super()._get_observation(x_ctrl),self.memory]).astype(np.float32)

    def step(self,action):
        action=float(np.clip(np.asarray(action).reshape(-1)[0],-1.,1.))
        residual=self.residual_scale*action
        if self.context_gate:
            self.framework_controller.authority_override=float(np.clip((abs(self.memory[1])-.025)/.05,0.,1.))
        obs,old_reward,terminated,truncated,info=super().step(np.array([residual],dtype=np.float32))
        # Memory is built only from noisy measured features returned by the env.
        measured=self._measurement
        self.memory[0]=np.clip(.995*self.memory[0]+self.dt*measured[0],-.5,.5)
        self.memory[1]=.95*self.memory[1]+.05*measured[0]
        self.memory[2]=.95*self.memory[2]+.05*measured[2]
        obs[-3:]=self.memory
        if self.reward_mode=='tracking':
            reward=-100.*float(self.state[0])**2-20.*float(self.state[2])**2
            reward-=.02*action**2+.05*(action-self.previous_action)**2
            reward-=.05*float(info['fallback_used'])
            if terminated:reward-=100.
        else:
            reward=old_reward
        self.previous_action=action
        info['normalized_residual']=action
        info['scaled_residual_rad']=residual
        return obs,float(reward),terminated,truncated,info
