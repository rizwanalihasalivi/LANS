"""Explicit component interventions; unchanged seeded physical stress model."""
import json
from pathlib import Path
import numpy as np
from controllers.split_controller import ResidualMailbox
from controllers.framework_controller import LANSFrameworkController
from scripts.noise_env import NoiseEnv
ROOT=Path('bench_results')
CFG=json.loads((ROOT/'controller_selection.json').read_text())['configs']
NOISE=json.loads((ROOT/'selection.json').read_text())['noise_configs']
class UnitGainMailbox(ResidualMailbox):
    def push(self,command,delay_ms):
        super().push(command,delay_ms)
        # Attenuation only is ablated; transport, outages and stale-packet expiry remain.
        return float(self.last_output if self.last_generated is not None and self.last_age_steps*self.dt*1000<=self.ttl_ms else 0.)

class BenchEnv(NoiseEnv):
    def __init__(self,variant='full',latency_reward=False,**kwargs):
        self.variant=variant;self.latency_reward=bool(latency_reward)
        family='mpc' if variant=='mpc' else 'lans'
        super().__init__(**CFG[family],noise_config=NOISE[family],residual_scale=.01,**kwargs)
        c=self.framework_controller
        if variant in ['no_latency_gain','zero_no_gain','ppo_reuse']:
            c.remote=UnitGainMailbox(self.dt);self.delay_buffer=c.delay.buffer
        if variant=='no_cost_gate':c.gate=False
        if variant=='no_fallback':c.inner.enable_fallback=False
        if variant=='no_arrival_prediction':
            # Remove queued-command arrival prediction and actuator compensation together.
            c.inner.analytical=c.inner.analytical.base
        if variant in ['lqr_feedback','lqr_feedforward','ppo_reuse']:
            branch=LANSFrameworkController().analytical
            original=c.step
            def direct(x_k,ppo_residual,delay_ms=0.,gain_context=1.,kappa_k=0.,predictor=None):
                # Keep measured observation construction for frozen-policy compatibility.
                # Supervisory calculations are diagnostic only, never applied to direct methods.
                _,info=original(x_k,ppo_residual if variant=='ppo_reuse' else 0.,delay_ms,gain_context,kappa_k,predictor)
                command=branch.compute(c.filtered,kappa_k)
                u=c.arrived_residual if variant=='ppo_reuse' else command.u_lqr if variant=='lqr_feedback' else command.u_analytical
                u=float(np.clip(u,-.5,.5));c.last_u=u
                info.update(u_k=u,u_c=u,u_q=u,fallback_used=False,recovery_used=False,recovery_unresolved=False,remote_residual_accepted=u if variant=='ppo_reuse' else 0.)
                return u,info
            c.step=direct
    def step(self,action):
        obs,r,term,trunc,info=super().step(action)
        # Exact delay-weighted tracking term present in inherited original trainer.
        term_delay=-.02*(info['delay_ms']/200.)*abs(info['error'])
        if self.latency_reward:r+=term_delay
        info['latency_reward_term']=term_delay if self.latency_reward else 0.
        return obs,r,term,trunc,info
