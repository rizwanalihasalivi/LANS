import argparse,csv,gzip,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv,VecNormalize
from scripts.paper_env import BenchEnv
from scripts.stress_env import PROFILES
ROOT=Path('bench_results')
SAVED={'full':3,'lqr_feedback':1,'lqr_feedforward':1,'ppo_reuse':3,'no_latency_gain':3,'zero':1,'zero_no_gain':1,'no_cost_gate':3,'no_fallback':3,'no_arrival_prediction':3,'mpc':1}
def cases():
    out=[]
    for es in [3200,3201]:
      for path in ['dlc','sine_noise_test','chirp_noise_test']:
       for profile in PROFILES:
        for method,n in {**SAVED,'reward_off':3,'reward_on':3}.items():
         for seed in ([42,43,44] if n==3 else [-1]):out.append(dict(case_id=len(out),method=method,train_seed=seed,eval_seed=es,path=path,profile=profile))
    return out

def load_policy(method,seed):
    if method.startswith('reward_'):base=Path('bench_models')/f'reward_{int(method=="reward_on")}_seed{seed}'
    else:base=Path('robustness_models')/f'ppo_seed{seed}'
    norm=VecNormalize.load(str(base)+'_norm.pkl',DummyVecEnv([lambda:BenchEnv()]));norm.training=False;norm.norm_reward=False
    return PPO.load(str(base),device='cpu'),norm

def main(stage,worker,workers):
    torch.set_num_threads(1);cache={};allcases=cases();(ROOT/'cases.json').write_text(json.dumps(allcases,indent=2)) if worker==0 else None
    subset=[c for c in allcases if c['method'].startswith('reward_')==(stage=='reward')];subset=subset[worker::workers]
    prefix=f'{stage}{worker}'
    with (ROOT/f'{prefix}_episodes.csv').open('w',newline='') as f,gzip.open(ROOT/f'{prefix}_traces.csv.gz','wt',newline='') as tf:
      w=None;tw=csv.writer(tf);tw.writerow(['case_id','tick','error_m','heading_rad','command_rad','actual_rad','delay_ms','pose_age_ms','accepted_residual','fallback'])
      for ix,c in enumerate(subset):
        variant='full' if c['method'].startswith('reward_') else c['method'];e=BenchEnv(variant=variant,profile=c['profile'],path=c['path'],heldout=True)
        obs,_=e.reset(seed=c['eval_seed']);errors=[float(e.state[0])];initial_heading=float(e.state[2]);fbs=0;poses=[];accepted=0;delays=[];rs=[];last=0.
        for tick in range(1000):
          if c['train_seed']<0:a=np.zeros(1)
          else:
            key=(c['method'] if c['method'].startswith('reward_') else 'saved',c['train_seed'])
            if key not in cache:cache[key]=load_policy(c['method'],c['train_seed'])
            model,norm=cache[key];a=model.predict(norm.normalize_obs(obs[None,:]),deterministic=True)[0][0]
          obs,_,term,trunc,info=e.step(a);errors.append(info['error']);fbs+=int(info['fallback_used']);age=max(0,(e.t_step-e.pose_stamp-1)*e.dt*1000);poses.append(age);delays.append(info['delay_ms']);accepted+=int(info.get('remote_residual_accepted',0.)!=0);rs.append((e.actual_delta-last)/e.dt);last=e.actual_delta
          tw.writerow([c['case_id'],tick,info['error'],e.state[2],info['u_k'],e.actual_delta,info['delay_ms'],age,info.get('remote_residual_accepted',0.),int(info['fallback_used'])])
          if term or trunc:break
        sq=float(np.sum(np.square(errors)));n=len(errors)-1
        row=dict(c,initial_error_m=errors[0],initial_heading_rad=initial_heading,steps=n,survived=not term,rmse_m=float(np.sqrt(sq/(n+1))),max_error_m=float(np.max(np.abs(errors))),failure_penalized_rmse_m=float(np.sqrt((sq+(1000-n)*max(2.5,abs(errors[-1]))**2)/1001)),fallbacks=fbs,accepted_residual_steps=accepted,steering_rate_rms=float(np.sqrt(np.mean(np.square(rs)))),mean_pose_age_ms=float(np.mean(poses)),max_pose_age_ms=max(poses),mean_remote_delay_ms=float(np.mean(delays)),command_delay_ms=e.settings['command_ms'],actuator_tau_s=e.settings['tau'],actuator_rate_rad_s=e.settings['rate'],sensor_delay_ms=e.settings['sensor_ms'])
        if w is None:w=csv.DictWriter(f,fieldnames=list(row));w.writeheader()
        w.writerow(row);f.flush();e.close()
        if (ix+1)%20==0:print(stage,worker,ix+1,'/',len(subset),flush=True)
    for _,norm in cache.values():norm.close()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--stage',choices=['saved','reward'],required=True);p.add_argument('--worker',type=int,default=0);p.add_argument('--workers',type=int,default=1);a=p.parse_args();main(a.stage,a.worker,a.workers)
