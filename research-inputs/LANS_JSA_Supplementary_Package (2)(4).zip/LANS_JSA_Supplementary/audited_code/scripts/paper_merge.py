import gzip,csv
import numpy as np
from pathlib import Path
import pandas as pd
r=Path('bench_results');parts=sorted(r.glob('saved[0-9]*_episodes.csv'))+sorted(r.glob('reward[0-9]*_episodes.csv'))
x=pd.concat([pd.read_csv(p) for p in parts]).sort_values('case_id');assert len(x)==1218 and x.case_id.nunique()==1218
assert x.case_id.tolist()==list(range(1218))
# Reconstruct age at decision tick, not the next observation after plant advancement.
# This corrects an off-by-one instrumentation field; actions/outcomes are untouched.
ages={int(v.case_id):int(round(v.sensor_delay_ms/10)) for v in x.itertuples()}
x['logged_mean_pose_age_ms_before_correction']=x.mean_pose_age_ms
x['logged_max_pose_age_ms_before_correction']=x.max_pose_age_ms
x['mean_pose_age_ms']=[float(np.minimum(np.arange(v.steps),ages[v.case_id]).mean()*10) for v in x.itertuples()]
x['max_pose_age_ms']=[float(min(v.steps-1,ages[v.case_id])*10) for v in x.itertuples()]
x.to_csv(r/'episodes.csv',index=False)
with gzip.open(r/'traces.csv.gz','wt',newline='') as out:
 writer=csv.writer(out)
 for i,p in enumerate(parts):
  with gzip.open(str(p).replace('_episodes.csv','_traces.csv.gz'),'rt') as f:
   reader=csv.reader(f);h=next(reader);h.append('pose_age_ms_logged_before_correction')
   if i==0:writer.writerow(h)
   for row in reader:
    row.append(row[7]);row[7]=min(int(row[1]),ages[int(row[0])])*10
    writer.writerow(row)
print('Merged all 1218 executions across 42 physical cells.')
