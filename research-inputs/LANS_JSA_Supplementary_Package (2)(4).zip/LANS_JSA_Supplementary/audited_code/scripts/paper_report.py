from pathlib import Path
import pandas as pd
r=Path('paper_tables');s=pd.read_csv(r/'01_controller_ablation.csv').set_index('method');tim=pd.read_csv(r/'07_fair_timing.csv').set_index('method');combined=pd.read_csv(r/'16_combined_frozen_validation.csv').set_index('method')
def table(d):
 d=d.reset_index();lines=['| '+' | '.join(d.columns)+' |','| '+' | '.join(['---']*len(d.columns))+' |']
 for row in d.itertuples(index=False,name=None):lines.append('| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |')
 return '\n'.join(lines)
cols=['executions','survivors','survival_percent','rmse_mean_m','worst_observed_m','penalized_rmse_mean_m']
text=f'''# Additional experiments for the LANS paper

## Completed work

Six matched reward-training runs (three seeds per condition,51,200 steps each);
1,218 frozen-policy executions across42 matched physical cells;38 existing unit
tests plus explicit intervention checks; independently recomputed metrics from
1,041,795 simulated steps; and{int(tim.samples.sum()):,} isolated CPU timing samples.
Original three saved policies were preserved and reused for component ablations.
No model was chosen by the new test outcome.

## New evaluation results

{table(s[cols])}

`ppo_reuse` is a residual-policy deletion experiment. These policies were trained
to add at most0.01rad to an analytical controller, with analytical features in
their observations. They were not trained to generate full steering themselves.
The poor reuse outcome is NOT evidence against a properly trained standalone
PPO baseline. User-requested reuse was performed without retraining it.

Nominal LQR feedback and LQR+feedforward are explicitly separate. They share the
measured filtered state and physical channels, but have no adaptive analytic
compensation, recovery action or PPO. Their nominal gain was not retuned to the
stress suite. `zero` is the complete adaptive analytical LANS stack without PPO;
it is not the same as plain LQR.

## What the ablations actually show

- Arrival prediction plus actuator compensation has a substantial effect in this
  pilot: removing that combined wrapper reduces survival to{s.loc['no_arrival_prediction','survival_percent']:.2f}%.
- Removing fallback yields{s.loc['no_fallback','survival_percent']:.2f}% survival versus{s.loc['full','survival_percent']:.2f}% for full LANS.
  This is evidence that the current recovery heuristic can harm this finite test
  distribution. It is not a safety proof for either controller. Retuning based
  on these tests requires new validation; no setting was changed here.
- Removing latency attenuation does not change survival and slightly lowers mean
  RMSE here. Its claimed benefit is not established by these results. Transport,
  outage behavior and200ms stale-packet expiry still operate in this ablation.
- PPO-off and PPO-off-without-attenuation trajectories/metrics are identical.
  A scalar multiplying a zero residual cannot change the steering command.
- PPO-off survival equals full LANS survival. Its small average RMSE difference
  does not establish a broad neural robustness benefit.
- Cost-gate removal has little measured effect at this small residual scale.

These are two evaluation seeds, three trajectories and seven synthetic stress
profiles. Each neural method runs all three policy seeds. Policy repeats share
physical scenarios; SD across executions is not an independent-trial standard
error. No population-level superiority or formal worst-case bound follows.

## Latency-reward experiment

The original code term is `-0.02*(delay_ms/200)*abs(next_ey)`. It couples externally
imposed delay to controllable tracking error. Steering does not reduce the
injected delay itself. Current tracking/risk reward previously overwrote that
term, so this experiment explicitly restores it for the reward-on condition.
Both conditions were trained afresh with matched seeds, architecture, initial
weights, hyperparameters and step budget. Training trajectories may diverge as
policies change; the scenario distribution is matched, not every visited state.

Reward-off mean RMSE: **{s.loc['reward_off','rmse_mean_m']:.6f}m**.
Reward-on mean RMSE: **{s.loc['reward_on','rmse_mean_m']:.6f}m**.
Both survival: **{s.loc['reward_on','survival_percent']:.2f}%**.
This weight and short budget show a very small mean change and no survival gain.
They do not show reduced computation/transport latency, nor test all reward
weights. Report paired per-seed effects from CSV05/06; do not claim significance
from hundreds of correlated episode-policy rows. This is not a reproduction of
an unprovided original manuscript reward equation beyond the available code term.

## Fair CPU timing

{table(tim[['samples','mean_ms','median_ms','p95_ms','p99_ms','max_observed_ms']])}

All methods use the same CPU, one thread, batch1,100 warmup ticks, random method
order and common prepared input states. Decision time includes normalized PPO
prediction when used and steering/supervisory computation. Common estimator and
observation construction is measured separately. Copying/loading, logging,
simulator stepping and injected waiting are excluded. These Python CPU kernels
are not complete sensing-to-actuation measurements, GPU comparisons, worst-case
execution guarantees or proofs that every10ms real-world deadline will be met.
Serial full-LANS timing does not assume asynchronous overlap for its neural path.

The measured ratio PPO-reuse decision time / full-LANS decision time is
**{tim.loc['ppo_reuse','mean_ms']/tim.loc['full','mean_ms']:.3f}**, not49.
Full LANS took more computation time in this scope. The49x claim must be removed
or replaced by these scoped measurements. The100Hz simulation period was never
used as PPO inference time. CSV09 separately reports the same policy network
inference timing across ablations; removing a scalar reward term at training
cannot by itself justify a large architecture-identical inference-frequency claim.

## Retain earlier validation context

{table(combined[cols])}

CSV15 shows the previous five-seed suite and this new two-seed suite separately.
Both use the same selected full-LANS and MPC settings/models; only evaluation
seeds differ, with the same three path definitions and stress distributions.
MPC led survival in the prior suite; LANS leads in the new small suite. Across
all seven seeds, survival ties at{combined.loc['full','survival_percent']:.2f}%.
Ordinary mean RMSE is lower for MPC, while failure-penalized RMSE is lower for
LANS. Do not report only the favorable subset or claim universal superiority.

## Measurements that remain unavailable

No readable CPU package-energy counters or GPU power telemetry exist in this
runtime. CSV12 therefore has empty Joule/Watt fields and an explicit unavailable
status. No TDP-based number is presented as a measurement. The optional
`measure_energy_command.py` can record actual package counters on compatible
hardware, with whole-package attribution and counter-wrap limitations.

CSV11 is a partial model calculation: nominal25m/s multiplied by simulated pose
transport age plus measured mean computation and simulated command transport.
It excludes unmeasured sensing acquisition, localization, communication overhead
and actuator settling. Computation is a pooled microbenchmark mean, not a
synchronized per-episode measurement. Remote PPO delay is listed separately
because local analytical control does not wait for that remote packet.
Full measured end-to-end latency remains empty. Do not publish these estimates
as full measured blind distance or use different CPU/GPU assumptions to claim
an energy or blind-distance advantage.

## Reproducibility and integrity

`bench_results/protocol.json`, model metadata, frozen hashes, raw traces, training
logs, timing samples, environment metadata and verification outputs are included.
A decision-tick pose-age logging off-by-one is corrected in the merge stage;
original logged values are retained in separate columns. No action, reward,
trajectory, failure or tracking metric was changed by that instrumentation fix.
Energy status and all failures are retained. Timing/energy/full-end-to-end scope
must remain with the numbers when copying tables into the manuscript.

This experiment supplies evidence for reviewer responses. It does not complete
the Lyapunov proof, establish neuro-symbolic novelty, certify the physical
vehicle or constitute a full line-by-line manuscript audit.
'''
Path('BENCHMARK_REPORT.md').write_text(text)
rows=[]
for p in sorted(r.glob('*.csv')):
 rows.append(dict(file=p.name,rows=len(pd.read_csv(p)),meaning={'01':'Controller ablations; PPO reuse diagnostic must retain label','05':'Matched on/off rows, same policy and physical seeds','07':'Prepared-state CPU decision timing; excludes physical latency','10':'Scoped49x speedup check','11':'Partial modeled distance, not measured end-to-end','12':'Unavailable physical energy measurements; numeric blanks intentional','15':'Both old and new suites; preserve context','16':'All seven evaluation seeds pooled; correlated policy replicates'}.get(p.name[:2],'See README and BENCHMARK_REPORT for definitions')))
pd.DataFrame(rows).to_csv(r/'00_TABLE_INDEX.csv',index=False)
