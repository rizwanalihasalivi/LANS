import json
from pathlib import Path
import numpy as np
import pandas as pd
r=Path('bench_results');out=Path('paper_tables');out.mkdir(exist_ok=True)
x=pd.read_csv(r/'episodes.csv');t=pd.read_csv(r/'timing_samples.csv')
def agg(d,keys):
 s=d.groupby(keys).agg(executions=('steps','size'),survivors=('survived','sum'),rmse_mean_m=('rmse_m','mean'),rmse_sd_m=('rmse_m','std'),worst_observed_m=('max_error_m','max'),penalized_rmse_mean_m=('failure_penalized_rmse_m','mean'),mean_fallback_steps=('fallbacks','mean'))
 s['survival_percent']=100*s.survivors/s.executions;return s
main=agg(x,'method')
main['comparison_role']=['diagnostic_residual_policy_reuse_NOT_trained_standalone_PPO' if n=='ppo_reuse' else 'matched_short_retraining' if n.startswith('reward_') else 'fixed_policy_component_ablation' if n not in ['mpc','lqr_feedback','lqr_feedforward'] else 'analytic_baseline' for n in main.index]
main.to_csv(out/'01_controller_ablation.csv')
agg(x,['method','profile']).to_csv(out/'02_stress_profiles.csv')
agg(x,['method','train_seed']).to_csv(out/'03_training_seeds.csv')
agg(x,['method','path']).to_csv(out/'04_trajectories.csv')
a=x[x.method=='reward_on'];b=x[x.method=='reward_off'];keys=['train_seed','eval_seed','path','profile'];p=a.merge(b,on=keys,suffixes=('_on','_off'),validate='one_to_one')
for col in ['rmse_m','failure_penalized_rmse_m','survived']:p[col+'_difference_on_minus_off']=p[col+'_on'].astype(float)-p[col+'_off'].astype(float)
p.to_csv(out/'05_reward_paired.csv',index=False)
p.groupby('train_seed').agg(cells=('case_id_on','size'),rmse_difference_m=('rmse_m_difference_on_minus_off','mean'),penalized_rmse_difference_m=('failure_penalized_rmse_m_difference_on_minus_off','mean'),survival_fraction_difference=('survived_difference_on_minus_off','mean')).to_csv(out/'06_reward_seed_effect.csv')
g=t.groupby('method').decision_ms
s=g.agg(samples='size',mean_ms='mean',sd_ms='std',median_ms='median',min_ms='min',max_observed_ms='max');s['p95_ms']=g.quantile(.95);s['p99_ms']=g.quantile(.99);s['nominal_decisions_per_second_from_mean']=1000/s.mean_ms;s['observed_over_10ms_percent']=100*g.apply(lambda z:(z>10).mean());s.to_csv(out/'07_fair_timing.csv')
t.groupby(['method','train_seed','profile']).decision_ms.agg(['size','mean','median','max']).to_csv(out/'08_timing_by_seed_profile.csv')
policy=t[t.policy_ms>0].groupby('method').policy_ms.agg(['size','mean','median','max']);policy.to_csv(out/'09_policy_inference.csv')
ratio=s.loc['ppo_reuse','mean_ms']/s.loc['full','mean_ms']
pd.DataFrame([dict(comparison='PPO_reuse_decision_time / full_LANS_decision_time',ratio=ratio,claim_49x_supported=bool(ratio>=49),scope='matched prepared-state serial CPU kernels; excludes common frontend and simulator')]).to_csv(out/'10_speedup_check.csv',index=False)
common=t.groupby('method').common_frontend_ms.mean();d=x.groupby(['method','profile']).agg(pose_age_mean_ms=('mean_pose_age_ms','mean'),command_delay_mean_ms=('command_delay_ms','mean'),remote_delay_mean_ms=('mean_remote_delay_ms','mean'),actuator_tau_mean_s=('actuator_tau_s','mean')).reset_index()
d['speed_m_s']=25.;d['decision_mean_ms']=d.method.map(s.mean_ms);d['common_frontend_mean_ms']=d.method.map(common);d['modeled_transport_only_m']=25*(d.pose_age_mean_ms+d.command_delay_mean_ms)/1000;d['estimated_age_plus_serial_compute_plus_transport_m']=25*(d.pose_age_mean_ms+d.command_delay_mean_ms+d.decision_mean_ms+d.common_frontend_mean_ms)/1000;d['measured_full_end_to_end_ms']=np.nan;d['compute_timing_basis']='Pooled mean CPU microbenchmark over nominal/combined/full_command_delay DLC replay; not synchronized per episode';d['status']='MODELED_PARTIAL_NOT_MEASURED_END_TO_END';d.to_csv(out/'11_partial_blind_distance.csv',index=False)
energy=[]
for n in s.index:energy.append(dict(method=n,measured_joules=np.nan,measured_watts=np.nan,measurement_status='UNAVAILABLE_NO_READABLE_HARDWARE_COUNTER',scope='No CPU powercap or GPU telemetry available in execution environment; no TDP-based energy invented'))
pd.DataFrame(energy).to_csv(out/'12_energy_availability.csv',index=False)
agg(x[x.method.isin(['reward_off','reward_on'])],'method').to_csv(out/'13_reward_comparison.csv')
x[~x.survived].to_csv(out/'14_failed_runs.csv',index=False)
print(agg(x,'method').to_string());print('SPEED RATIO PPO/LANS',ratio);print(s[['mean_ms','p95_ms','p99_ms']].to_string())

prior=pd.read_csv(r/'prior_validation_episodes.csv');prior=prior[prior.method.isin(['new_lans','selected_mpc'])].copy();prior['method']=prior.method.replace({'new_lans':'full','selected_mpc':'mpc'});prior['suite']='prior_5_eval_seeds';current=x[x.method.isin(['full','mpc'])].copy();current['suite']='new_2_eval_seeds'
combined=pd.concat([prior,current],ignore_index=True);agg(combined,['suite','method']).to_csv(out/'15_cross_suite_context.csv');agg(combined,'method').to_csv(out/'16_combined_frozen_validation.csv')
# Policy repetitions remain visible; pooling uses equal cells per policy, not independent trials.
print('ALL SEVEN EVALUATION SEEDS:',agg(combined,'method').to_string())
