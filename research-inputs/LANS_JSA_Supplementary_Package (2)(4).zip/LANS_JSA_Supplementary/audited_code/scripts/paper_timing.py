"""Matched prepared-state decision timing, plus separately timed common frontend.
No simulated waiting, plant update, deepcopy, file I/O or model loading is timed.
"""
import copy,csv,json,platform,sys,time
from types import SimpleNamespace
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from scripts.paper_env import BenchEnv,UnitGainMailbox,CFG
from scripts.paper_evaluate import load_policy
from scripts.local_mpc import MPCBranch
from controllers.transport_feedback import TransportFeedback
from controllers.framework_controller import LANSFrameworkController
from models.kinematic_prediction import KinematicPrediction
R=Path('bench_results')
METHODS=['full','zero','zero_no_gain','no_latency_gain','no_cost_gate','no_fallback','no_arrival_prediction','mpc','lqr_feedback','lqr_feedforward','ppo_reuse','reward_off','reward_on']

def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);rng=np.random.default_rng(19)
 cache={(family,seed):load_policy(family,seed) for family in ['full','reward_off','reward_on'] for seed in [42,43,44]}
 branch=LANSFrameworkController().analytical
 metadata=dict(python=sys.version,platform=platform.platform(),torch=torch.__version__,threads=torch.get_num_threads(),batch=1,warmup_ticks=100,maximum_ticks=400,profiles=['nominal','combined','full_command_delay'],physical_seed=3400,policy_seeds=[42,43,44],scope='Matched prepared-state serial decision kernels; optional common frontend measured separately; not full vehicle end-to-end latency',clock='perf_counter_ns',ordering='random permutation of methods for each common state',cpu_info=Path('/proc/cpuinfo').read_text().split('flags')[0])
 (R/'timing_environment.json').write_text(json.dumps(metadata,indent=2))
 with (R/'timing_samples.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['method','train_seed','profile','tick','policy_ms','controller_ms','decision_ms','common_frontend_ms']);w.writeheader()
  for seed in [42,43,44]:
   for profile in metadata['profiles']:
    e=BenchEnv(variant='zero',profile=profile,path='dlc',heldout=True);frontend=[0.]
    orig=e._get_observation
    def timed_obs(*a,**kw):
     t=time.perf_counter_ns();out=orig(*a,**kw);frontend[0]=(time.perf_counter_ns()-t)/1e6;return out
    e._get_observation=timed_obs;obs,_=e.reset(seed=3400)
    for tick in range(400):
     p=KinematicPrediction(e.x_position,e.vx,e.dt,e.L,.5,e._get_reference_y,e._get_reference_heading,e._get_reference_curvature);k=p.curvature(p.position)
     for method in rng.permutation(METHODS):
      c=copy.deepcopy(e.framework_controller);c.current_predictor=p
      if method in ['no_latency_gain','zero_no_gain','ppo_reuse']:
       c.remote.__class__=UnitGainMailbox
      if method=='no_cost_gate':c.gate=False
      if method=='no_fallback':c.inner.enable_fallback=False
      if method=='no_arrival_prediction':c.inner.analytical=c.inner.analytical.base
      if method=='mpc':
       owner=SimpleNamespace(vx=e.vx,dt=e.dt,L=e.L,framework_controller=c,x_position=e.x_position,_get_reference_curvature=e._get_reference_curvature)
       c.inner.analytical=TransportFeedback(c,MPCBranch(owner,q_scale=CFG['mpc']['mpc_q']),damping=CFG['mpc']['damping'])
      neural=method not in ['zero','zero_no_gain','mpc','lqr_feedback','lqr_feedforward']
      policy_ms=0.;residual=0.
      if neural:
       family=method if method.startswith('reward_') else 'full';model,norm=cache[(family,seed)]
       t=time.perf_counter_ns();action=model.predict(norm.normalize_obs(obs[None,:]),deterministic=True)[0][0];residual=.01*float(np.clip(np.asarray(action).reshape(-1)[0],-1.,1.));policy_ms=(time.perf_counter_ns()-t)/1e6
      t=time.perf_counter_ns()
      if method=='ppo_reuse':c.remote.push(residual,e.current_delay_ms)
      elif method in ['lqr_feedback','lqr_feedforward']:branch.compute(c.filtered,k)
      else:c.step(e._measurement,residual,e.current_delay_ms,1.,k,p)
      controller_ms=(time.perf_counter_ns()-t)/1e6
      if tick>=100:w.writerow(dict(method=method,train_seed=seed,profile=profile,tick=tick,policy_ms=policy_ms,controller_ms=controller_ms,decision_ms=policy_ms+controller_ms,common_frontend_ms=frontend[0]))
     obs,_,term,trunc,_=e.step(np.zeros(1))
     if term or trunc:break
    e.close();f.flush();print('TIMED',seed,profile,flush=True)
 for _,norm in cache.values():norm.close()
if __name__=='__main__':main()
