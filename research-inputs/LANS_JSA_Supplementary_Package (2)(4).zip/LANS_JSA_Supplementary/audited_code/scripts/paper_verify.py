from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
r=Path('bench_results');x=pd.read_csv(r/'episodes.csv').set_index('case_id');t=pd.read_csv(r/'traces.csv.gz',usecols=['case_id','error_m']);assert len(x)==1218 and x.index.is_unique
assert np.isfinite(t.error_m).all();t['sq']=t.error_m**2;t['absolute']=t.error_m.abs();g=t.groupby('case_id').agg(n=('sq','size'),sq=('sq','sum'),peak=('absolute','max'),last=('absolute','last'))
np.testing.assert_array_equal(g.n,x.steps);np.testing.assert_allclose(np.sqrt((g.sq+x.initial_error_m**2)/(g.n+1)),x.rmse_m,rtol=1e-9,atol=1e-10);np.testing.assert_allclose(np.maximum(g.peak,x.initial_error_m.abs()),x.max_error_m,rtol=1e-9,atol=1e-10)
np.testing.assert_allclose(np.sqrt((g.sq+x.initial_error_m**2+(1000-g.n)*g['last'].clip(lower=2.5)**2)/1001),x.failure_penalized_rmse_m,rtol=1e-9,atol=1e-10)
keys=['eval_seed','path','profile'];assert x.groupby(keys).size().eq(29).all();assert x.groupby(keys)[['initial_error_m','initial_heading_rad','actuator_tau_s','actuator_rate_rad_s','sensor_delay_ms','command_delay_ms']].nunique().eq(1).all().all()
a=x[x.method=='zero'].set_index(keys);b=x[x.method=='zero_no_gain'].set_index(keys)
np.testing.assert_array_equal(a[['steps','rmse_m','max_error_m','survived']],b[['steps','rmse_m','max_error_m','survived']])
m=json.loads((r/'frozen_manifest.json').read_text())['sha256'];assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in m.items())
print(f'PASS: {len(x)} executions, {len(t)} actual steps; raw metrics, physical matching, zero-residual gain invariance and frozen source/model hashes verified.')
