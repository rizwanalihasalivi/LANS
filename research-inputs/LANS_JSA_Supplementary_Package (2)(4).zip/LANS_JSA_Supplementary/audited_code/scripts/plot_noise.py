from pathlib import Path
from io import BytesIO
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
r=Path('noise_results');s=pd.read_csv(r/'summary.csv').set_index('method')
order=['original_lans','new_lans','new_zero','original_mpc','selected_mpc'];s=s.loc[order]
labels=['Original LANS','Selected LANS','Selected / PPO off','Original MPC','Selected MPC'];colors=['#7c9cba','#145eab','#8896a1','#ba9272','#b35422']
fig,axes=plt.subplots(1,3,figsize=(14,4.8),layout='constrained')
for ax,col,title in zip(axes,['survival_percent','mean_rmse_m','failure_penalized_rmse_m'],['Survival (%) ↑','Mean episode RMSE (m) ↓','Failure-penalized RMSE (m) ↓']):
    bars=ax.barh(labels,s[col],color=colors);ax.invert_yaxis();ax.set_title(title);ax.set_xlim(0,max(s[col])*1.2);ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True)
    ax.bar_label(bars,fmt='%.2f' if col=='survival_percent' else '%.3f',padding=4)
fig.suptitle('Frozen validation: 105 matched physical cells; all three LANS policies retained\nFinite simulation outcomes — not formal safety or universal superiority',fontsize=13)
b=BytesIO();fig.savefig(b,format='png',dpi=160);(r/'comparison.png').write_bytes(b.getvalue());plt.close(fig)
