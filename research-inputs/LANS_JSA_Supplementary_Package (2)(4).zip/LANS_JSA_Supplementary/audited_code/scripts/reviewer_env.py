"""Canonical reviewer protocol. No wall-clock features or true-gain context.

Training references: DLC, 0.1 Hz sine, 0.4 Hz snake (inherited). Held-out
references below use different shapes/parameters, not proof of generalization.
"""
import numpy as np
from scripts.train_ppo_delay_aware_v2 import DelayAwareEnvV2


class ReviewerEnv(DelayAwareEnvV2):
    def __init__(self, *, path='train', difficulty=1., delay_range=(0., 200.),
                 delay_reward=False, controller_variant='full'):
        self.path = path
        self.controller_variant = controller_variant
        super().__init__(difficulty=difficulty, delay_range=delay_range,
                         mode='train' if path == 'train' else 'eval',
                         use_delay_reward=delay_reward)
        c = self.framework_controller
        if controller_variant == 'no_gate':
            c.authority_override = 1.
        elif controller_variant == 'no_fallback':
            c.enable_fallback = False
        elif controller_variant == 'no_prediction':
            c.compensate_delay = False
        elif controller_variant == 'delayed_lqr':
            c.enable_fallback = False
            c.compensate_delay = False
        elif controller_variant != 'full':
            raise ValueError(controller_variant)

    def _get_observation(self, x_ctrl=None):
        obs = super()._get_observation(x_ctrl)
        # Remove machine load from training/evaluation behavior. Injected delay
        # remains at index 11; indexes 9/10 reserved as zero for compatibility.
        obs[9:11] = 0.
        return obs

    def _generate_reference_path(self):
        if self.path in ('train', 'dlc'):
            return super()._generate_reference_path()
        t = np.arange(0., 10.01, self.dt)
        if self.path == 'sine_ood':
            self.y_ref = 2. * np.sin(2 * np.pi * .17 * t)
        elif self.path == 'slalom_ood':
            self.y_ref = 1.5 * np.sin(2 * np.pi * .25 * t) + .4 * np.sin(2 * np.pi * .55 * t)
        elif self.path == 'smooth_step':
            self.y_ref = 1.75 * (1 + np.tanh((t - 3.) / .6))
        else:
            raise ValueError(self.path)
        return self.y_ref
