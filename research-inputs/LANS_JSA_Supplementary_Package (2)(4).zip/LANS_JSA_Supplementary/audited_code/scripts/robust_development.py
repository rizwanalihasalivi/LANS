import csv,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from scripts.stress_env import RobustEnv,StressIntegralEnv,PROFILES
from scripts.strong_baselines import IntegralLQR
ROOT=Path('robustness_results')
CONFIGS={**{f'lans_g{g}_q{q}':dict(gain_scale=g,q_bias=q) for g in [.5,1.,1.5] for q in [.0016,.0064]},**{f'mpc_q{q}':dict(controller='mpc',mpc_q=q,q_bias=.0064) for q in [1.,4.]},**{f'integral_g{g}':dict(integral_scale=g) for g in [.5,1.,2.]},'previous':dict(controller='previous',gain_scale=1.5,q_bias=.0064)}

def make(name,profile,path):
    cfg=CONFIGS[name].copy()
    if 'integral_scale' in cfg:
        e=StressIntegralEnv(profile=profile,path=path);e.framework_controller.analytical=IntegralLQR(e);e.framework_controller.analytical.K*=cfg['integral_scale'];return e
    return RobustEnv(profile=profile,path=path,**cfg)

def run(e,seed,model=None,norm=None):
    obs,_=e.reset(seed=seed);errors=[float(e.state[0])];headings=[float(e.state[2])];rates=[];last=0.;fb=env_exceeded=0
    for tick in range(1000):
        a=np.zeros(1) if model is None else model.predict(norm.normalize_obs(obs[None,:]),deterministic=True)[0][0]
        obs,_,term,trunc,info=e.step(a);errors.append(info['error']);headings.append(e.state[2]);rates.append((e.actual_delta-last)/e.dt);last=e.actual_delta;fb+=int(info['fallback_used']);env_exceeded+=int(abs(e.state[0])>.3 or abs(e.state[2])>.06)
        if term or trunc:break
    return dict(steps=len(errors)-1,terminated=term,rmse_m=float(np.sqrt(np.mean(np.square(errors)))),max_error_m=float(np.max(np.abs(errors))),max_heading_rad=float(np.max(np.abs(headings))),steering_rate_rms=float(np.sqrt(np.mean(np.square(rates)))),fallbacks=fb,envelope_exceeded=env_exceeded)

if __name__=='__main__':
    rows=[]
    for name in CONFIGS:
        for seed in [110,111]:
            for path in ['dlc','sine_new']:
                for profile in PROFILES:
                    e=make(name,profile,path);rows.append(dict(method=name,seed=seed,path=path,profile=profile,**run(e,seed)));e.close()
        r=[x for x in rows if x['method']==name]
        print(name,sum(x['terminated'] for x in r),max(x['max_error_m'] for x in r),np.mean([x['rmse_m'] for x in r]),flush=True)
    with (ROOT/'development.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    def score(n):
        r=[x for x in rows if x['method']==n]
        return (sum(x['terminated'] for x in r),max(x['max_error_m'] for x in r),np.mean([x['rmse_m'] for x in r]))
    selected={prefix:min([n for n in CONFIGS if n.startswith(prefix)],key=score) for prefix in ['lans','mpc','integral']}
    (ROOT/'selection.json').write_text(json.dumps(dict(selected=selected,configs={k:CONFIGS[v] for k,v in selected.items()},scores={n:score(n) for n in CONFIGS},criterion='Lexicographic: fewest terminations, smallest worst lateral error (including initial state), then smallest mean RMSE. No universal Pareto domination implied.'),indent=2))
