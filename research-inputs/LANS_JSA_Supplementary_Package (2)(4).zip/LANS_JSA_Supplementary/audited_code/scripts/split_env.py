import numpy as np
from gymnasium import spaces
from scripts.observer_env import ObserverEnv
from controllers.split_controller import SplitController

class SplitEnv(ObserverEnv):
    def __init__(self,*,gain_scale=1.,q_bias=.0016,gate=True,**kwargs):
        self.split_ready=False
        super().__init__(q_bias=q_bias,**kwargs)
        self.framework_controller=SplitController(self.vx,self.dt,self.L,q_bias,gain_scale,gate)
        self.delay_buffer=self.framework_controller.delay.buffer
        self.observation_space=spaces.Box(-np.inf,np.inf,shape=(34,),dtype=np.float32)
        self.split_ready=True
    def remote_features(self):
        c=self.framework_controller
        return np.array([c.remote.last_age_steps*self.dt,c.arrived_residual,float(c.remote.available)],dtype=np.float32)
    def _get_observation(self,x_ctrl=None):
        obs=super()._get_observation(x_ctrl)
        return np.concatenate([obs,self.remote_features()]) if self.split_ready else obs
    def step(self,action):
        obs,r,t,tr,info=super().step(action)
        obs[31:34]=self.remote_features()
        return obs,r,t,tr,info
