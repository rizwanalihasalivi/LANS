"""Shared plant/sensor stressors. Values are synthetic test conditions, not vehicle specs."""
from collections import deque
import numpy as np
from gymnasium import spaces
from scripts.split_env import SplitEnv
from scripts.optimization_env import OptimizationEnv
from scripts.local_mpc import MPCBranch
from controllers.timestamp_observer import TimestampController
from controllers.delay_queue import FIFOCommandDelay

PROFILES={
 'nominal':dict(difficulty=0.,tau=0.,rate=100.,sensor_ms=0,command_ms=0,remote_ms=80),
 'actuator':dict(difficulty=1.,tau=.08,rate=.6,sensor_ms=0,command_ms=0,remote_ms=1000),
 'sensor':dict(difficulty=1.,tau=.04,rate=1.,sensor_ms=80,command_ms=0,remote_ms=80),
 'gain_step':dict(difficulty=1.,tau=.06,rate=.8,sensor_ms=40,command_ms=0,remote_ms=80),
 'noise_burst':dict(difficulty=1.,tau=.04,rate=1.,sensor_ms=40,command_ms=0,remote_ms=80),
 'combined':dict(difficulty=1.,tau=.12,rate=.5,sensor_ms=120,command_ms=0,remote_ms=80),
 'full_command_delay':dict(difficulty=1.,tau=.06,rate=.8,sensor_ms=80,command_ms=200,remote_ms=80),
}

class StressMixin:
    def __init__(self,*,profile='nominal',random_profiles=False,heldout=False,**kwargs):
        self.heldout=heldout;self.profile=profile;self.random_profiles=random_profiles;self.settings=PROFILES[profile].copy()
        self.executed_history=[];self.pose_packets=[];self.actual_delta=0.;self.pose_stamp=0
        self.actuator_channel=FIFOCommandDelay(.01)
        kwargs.update(difficulty=self.settings['difficulty'],delay_range=(self.settings['remote_ms'],self.settings['remote_ms']))
        super().__init__(**kwargs)
    def reset(self,*,seed=None,options=None):
        if seed is not None:self.np_random=np.random.default_rng(seed)
        if self.random_profiles:self.profile=str(self.np_random.choice(list(PROFILES)))
        self.settings=PROFILES[self.profile].copy()
        if self.heldout and self.profile!='nominal':
            severity=np.random.default_rng((0 if seed is None else seed)+31000)
            self.settings['tau']*=float(severity.uniform(.8,1.25))
            self.settings['rate']*=float(severity.uniform(.8,1.1))
            self.settings['sensor_ms']=max(0,self.settings['sensor_ms']+int(severity.choice([-20,0,20])))
            if self.settings['command_ms']>0:self.settings['command_ms']+=int(severity.choice([-20,0,20]))
        d=self.settings['difficulty']
        self.difficulty=d;self.plant_gain_range=(1-.25*d,1+.25*d);self.disturbance_amp=.5*d;self.sensor_noise_std=.02*d
        self.delay_range=(self.settings['remote_ms'],self.settings['remote_ms'])
        self.executed_history=[];self.pose_packets=[];self.actual_delta=0.;self.pose_stamp=0
        self.actuator_channel.reset();self.measured_peak=0.;self.true_peak=0.
        result=super().reset(seed=None,options=options)
        self.true_peak=abs(float(self.state[0]));return result
    def _controller_state(self):
        old=self.sensor_noise_std
        if self.profile in ('noise_burst','combined') and 300<=self.t_step<450:self.sensor_noise_std=.075 if self.heldout else .06
        measured=super()._controller_state();self.sensor_noise_std=old
        # Noise draw occurs once per physical tick in every method.
        self.pose_packets.append((self.t_step,self._get_reference_y(self.x_position)+measured[0],self._get_reference_heading(self.x_position)+measured[2],measured.copy()))
        delay=round(self.settings['sensor_ms']/(1000*self.dt));stamp=max(0,self.t_step-delay)
        packet=self.pose_packets[stamp];self.pose_stamp=packet[0]
        x=packet[3].copy();x[0]=packet[1]-self._get_reference_y(self.x_position);x[2]=packet[2]-self._get_reference_heading(self.x_position)
        c=self.framework_controller;c.known_command_sequence=self.actuator_channel.preview_outputs(0.,self.settings['command_ms'])[:-1];c.pose_stamp=self.pose_stamp;c.now_tick=self.t_step;c.executed_inputs=self.executed_history
        if hasattr(c,'last_u'):c.last_u=self.actual_delta
        return x
    def _kinematic_update(self,command):
        target=self.actuator_channel.push(command,self.settings['command_ms'])
        tau=self.settings['tau'];fraction=1. if tau==0 else -np.expm1(-self.dt/tau)
        movement=np.clip(fraction*(target-self.actual_delta),-self.settings['rate']*self.dt,self.settings['rate']*self.dt)
        self.actual_delta=float(np.clip(self.actual_delta+movement,-.5,.5))
        self.executed_history.append(self.actual_delta)
        g=self.plant_gain
        if self.profile in ('gain_step','combined') and self.t_step>=500:self.plant_gain=g*(.6 if self.heldout else .65)
        result=super()._kinematic_update(self.actual_delta);self.plant_gain=g
        return result
    def step(self,action):
        if self.profile=='combined':
            self.current_delay_ms=float([0,1000,20,500,80][(self.t_step//40)%5])
            c=self.framework_controller
            if hasattr(c,'remote'):c.remote.available=not(200<=self.t_step<600)
        obs,r,t,tr,info=super().step(action)
        info.update(actual_steering=self.actual_delta,commanded_steering=info['u_k'],pose_age_steps=self.t_step-self.pose_stamp,actuator_command_delay_ms=self.settings['command_ms'])
        return obs,r,t,tr,info

class RobustEnv(StressMixin,SplitEnv):
    def __init__(self,*,gain_scale=1.,q_bias=.0016,controller='adaptive',mpc_q=1.,damping=None,risk_reward=False,**kwargs):
        self.robust_ready=False;self.risk_reward=risk_reward;self.measured_peak=0.;self.true_peak=0.
        super().__init__(gain_scale=gain_scale,q_bias=q_bias,mixed_training=False,**kwargs)
        if controller!='previous':
            self.framework_controller=TimestampController(self.vx,self.dt,self.L,q_bias,gain_scale)
            self.delay_buffer=self.framework_controller.delay.buffer
        if controller=='mpc':self.framework_controller.inner.analytical=MPCBranch(self,q_scale=mpc_q)
        if damping is not None:
            from controllers.transport_feedback import TransportFeedback
            self.framework_controller.inner.analytical=TransportFeedback(self.framework_controller,self.framework_controller.inner.analytical,damping=damping)
        self.observation_space=spaces.Box(-np.inf,np.inf,shape=(37,),dtype=np.float32);self.robust_ready=True
    def metadata(self):return np.array([(self.t_step-self.pose_stamp)*self.dt,self.actual_delta,self.measured_peak],dtype=np.float32)
    def _get_observation(self,x_ctrl=None):
        obs=super()._get_observation(x_ctrl)
        if self.robust_ready:
            raw=self._measurement if x_ctrl is None else x_ctrl
            self.measured_peak=max(self.measured_peak,abs(float(raw[0])))
        return np.concatenate([obs,self.metadata()]) if self.robust_ready else obs
    def step(self,action):
        obs,r,t,tr,info=super().step(action)
        # Parent writes memory/remote fields with its34-feature layout.
        obs[31:34]=self.remote_features();obs[34:37]=self.metadata()
        new_peak=max(self.true_peak,abs(float(self.state[0])))
        if self.risk_reward:
            r-=25.*(new_peak**2-self.true_peak**2)
            if t:r-=400.
        self.true_peak=new_peak
        return obs,r,t,tr,info

class StressIntegralEnv(StressMixin,OptimizationEnv):
    def step(self,action):
        # Integral controller uses local computation; physical actuator delay
        # is still imposed in StressMixin for every method, including fallback.
        self.current_delay_ms=0.
        return super().step(action)
