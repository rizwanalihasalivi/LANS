"""A matched leaky-integral LQR competitor, not an intentionally weak baseline."""
import numpy as np
from scipy.linalg import solve_discrete_are
from controllers.analytical_branch import AnalyticalBranch,AnalyticalCommand

class IntegralLQR(AnalyticalBranch):
    def __init__(self,env):
        self.env=env
        A=np.array([[1.,env.vx*env.dt,0.],[0.,1.,0.],[env.dt,0.,.995]])
        B=np.array([[0.],[env.vx*env.dt/env.L],[0.]])
        Q=np.diag([1.,4.,.2]);R=np.array([[10.]])
        S=solve_discrete_are(A,B,Q,R)
        self.K=np.linalg.solve(R+B.T@S@B,B.T@S@A).ravel()
        super().__init__(wheelbase=env.L)
    def compute(self,x_k,kappa_k):
        state=np.array([x_k[0],x_k[2],self.env.memory[0]])
        feedback=float(np.clip(-self.K@state,-self.delta_max,self.delta_max))
        ff=self.wheelbase*float(kappa_k)
        return AnalyticalCommand(feedback,ff,float(np.clip(feedback+ff,-self.delta_max,self.delta_max)))
