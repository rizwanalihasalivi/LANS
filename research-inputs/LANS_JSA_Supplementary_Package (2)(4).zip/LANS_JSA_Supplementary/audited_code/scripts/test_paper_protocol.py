import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from controllers.split_controller import ResidualMailbox
from scripts.paper_env import BenchEnv,UnitGainMailbox
m=ResidualMailbox();u=UnitGainMailbox()
for k in range(10):a=m.push(.01,50);b=u.push(.01,50)
assert np.isclose(a,.01*np.exp(-.5)) and b==.01
m.available=u.available=False
for k in range(25):a=m.push(.01,50);b=u.push(.01,50)
assert a==b==0.
for profile in ['nominal','combined']:
 a=BenchEnv(variant='zero',profile=profile);b=BenchEnv(variant='zero_no_gain',profile=profile)
 oa,_=a.reset(seed=8);ob,_=b.reset(seed=8)
 for k in range(100):
  oa,ra,ta,tra,ia=a.step(np.zeros(1));ob,rb,tb,trb,ib=b.step(np.zeros(1));np.testing.assert_array_equal(a.state,b.state)
 a.close();b.close()
a=BenchEnv(latency_reward=False,profile='sensor');b=BenchEnv(latency_reward=True,profile='sensor');a.reset(seed=9);b.reset(seed=9)
for k in range(10):
 _,ra,_,_,ia=a.step(np.zeros(1));_,rb,_,_,ib=b.step(np.zeros(1));np.testing.assert_array_equal(a.state,b.state);assert np.isclose(rb-ra,-.02*(ib['delay_ms']/200)*abs(ib['error']))
a.close();b.close()
e=BenchEnv(variant='ppo_reuse',profile='nominal');e.reset(seed=2);e.current_delay_ms=0.;_,_,_,_,i=e.step(np.array([.7]));assert np.isclose(i['u_k'],.007);assert not i['fallback_used']
print('Passed: attenuation removal preserves TTL; PPO-off gain invariance; exact reward-only intervention; direct reused policy applies .01-rad mapping without fallback.')
