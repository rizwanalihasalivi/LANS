"""
train_ppo_delay_aware_v2.py

Delay-aware PPO training with:

1. Recent applied-command history
2. FIFO delay-queue information
3. LQR and feed-forward analytical actions
4. Delay-aware residual authority
5. Model-based quadratic fallback
6. Applied-command and latency-aware reward
"""

import sys
import os
import argparse
import random
import time
from collections import deque

sys.path.insert(
    0,
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

import numpy as np
import gymnasium as gym
from gymnasium import spaces

from config import (
    K_LQR,
    P_LQR,
    A_D,
    B_D,
    L,
    VX,
    DT,
    DELTA_MAX,
    V_MAX,
)

from scenarios.double_lane_change import double_lane_change
from controllers.framework_controller import LANSFrameworkController
from models.kinematic_prediction import KinematicPrediction


HIST_LEN = 5
QUEUE_LEN = 5


class DelayAwareEnvV2(gym.Env):
    """
    Delay-aware PPO environment.

    Observation size: 25

    Observation layout:

        [0:4]    measured tracking-error state
        [4]      vehicle speed
        [5:9]    future preview errors
        [9]      measured execution latency
        [10]     predicted execution latency
        [11]     normalized injected delay
        [12]     analytical LQR command
        [13]     curvature feed-forward command
        [14]     analytical fallback command
        [15:20]  recent applied steering commands
        [20:25]  recent FIFO queue commands
    """

    OBS_DIM = 25

    def __init__(
        self,
        difficulty=1.0,
        delay_range=(0.0, 200.0),
        mode="train",
        use_delay_reward=True,
    ):
        super().__init__()

        self.use_delay_reward = bool(use_delay_reward)
        self.mode = mode
        self.dt = DT
        self.vx = VX
        self.L = L
        self.difficulty = difficulty

        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(self.OBS_DIM,),
            dtype=np.float32,
        )

        self.action_space = spaces.Box(
            low=-DELTA_MAX,
            high=DELTA_MAX,
            shape=(1,),
            dtype=np.float32,
        )

        self.K_lqr = K_LQR.copy()
        self.P = P_LQR.copy()
        self.A_d = A_D.copy()
        self.B_d = B_D.copy()
        self.V_max = float(V_MAX)

        self.framework_controller = LANSFrameworkController(
            vx=self.vx,
            V_max=self.V_max,
            wheelbase=self.L,
            delta_max=DELTA_MAX,
        )

        self.delay_buffer = self.framework_controller.delay.buffer

        self.plant_gain_range = (
            1.0 - 0.25 * difficulty,
            1.0 + 0.25 * difficulty,
        )

        self.disturbance_amp = 0.5 * difficulty
        self.disturbance_freq = 0.3
        self.sensor_noise_std = 0.02 * difficulty

        self.delay_range = tuple(delay_range)
        self.rng = np.random.default_rng()

        self.plant_gain = 1.0
        self.current_delay_ms = 0.0

        self.applied_history = deque(maxlen=HIST_LEN)

        self.latency_history = []
        self.latency_window = 10
        self.last_latency = 0.0
        self.pred_latency = 0.0

        self.x_global = 0.0
        self.y_global = 0.0
        self.psi = 0.0
        self.prev_delta = 0.0

        self.state = np.zeros(4, dtype=np.float32)

        self.prev_steering = 0.0
        self.prev_applied = 0.0

        self.x_position = 0.0
        self.y_actual = 0.0
        self.t_step = 0
        self.y_ref = None

    # ------------------------------------------------------------
    # Reference path
    # ------------------------------------------------------------

    def _generate_reference_path(self):
        t = np.arange(
            0.0,
            10.01,
            self.dt,
        )

        s = self.vx * t

        if self.mode == "train":
            path_type = self.rng.choice(
                ["DLC", "Snake", "Sine"]
            )

            if path_type == "DLC":
                self.y_ref = double_lane_change(
                    s,
                    lane_width=3.5,
                )

            elif path_type == "Snake":
                self.y_ref = (
                    2.5
                    * np.sin(
                        2.0
                        * np.pi
                        * 0.4
                        * t
                    )
                )

            else:
                self.y_ref = (
                    3.0
                    * np.sin(
                        2.0
                        * np.pi
                        * 0.1
                        * t
                    )
                )

        else:
            self.y_ref = double_lane_change(
                s,
                lane_width=3.5,
            )

        return self.y_ref

    def _get_reference_y(self, x):
        if self.y_ref is None:
            return 0.0

        idx = int(
            x / (self.vx * self.dt)
        )

        idx = min(
            max(idx, 0),
            len(self.y_ref) - 1,
        )

        return float(self.y_ref[idx])

    def _get_reference_heading(self, x):
        if self.y_ref is None:
            return 0.0

        if len(self.y_ref) < 2:
            return 0.0

        idx = int(
            x / (self.vx * self.dt)
        )

        idx = min(
            max(idx, 0),
            len(self.y_ref) - 2,
        )

        dy = (
            self.y_ref[idx + 1]
            - self.y_ref[idx]
        )

        dx = self.vx * self.dt

        if dx <= 0.0:
            return 0.0

        return float(
            np.arctan2(dy, dx)
        )

    def _get_reference_curvature(self, x):
        if self.y_ref is None:
            return 0.0

        if len(self.y_ref) < 3:
            return 0.0

        dx = self.vx * self.dt

        idx = int(x / dx)

        idx = min(
            max(idx, 1),
            len(self.y_ref) - 2,
        )

        d2y = (
            self.y_ref[idx + 1]
            - 2.0 * self.y_ref[idx]
            + self.y_ref[idx - 1]
        ) / (dx ** 2)

        d1y = (
            self.y_ref[idx + 1]
            - self.y_ref[idx - 1]
        ) / (2.0 * dx)

        denominator = (
            1.0 + d1y ** 2
        ) ** 1.5

        return float(
            d2y / denominator
        )

    # ------------------------------------------------------------
    # Analytical controller branch
    # ------------------------------------------------------------

    def _analytical_branch(self, x_ctrl):
        kappa = self._get_reference_curvature(
            self.x_position
        )

        command = (
            self.framework_controller
            .analytical
            .compute(
                x_ctrl,
                kappa,
            )
        )

        return (
            command.u_lqr,
            command.u_ff,
            command.u_analytical,
        )

    # ------------------------------------------------------------
    # Observation
    # ------------------------------------------------------------

    def _get_future_error(
        self,
        steps,
        e_y_current,
    ):
        future_x = (
            self.x_position
            + steps * self.vx * self.dt
        )

        y_ref_future = self._get_reference_y(
            future_x
        )

        current_ref = self._get_reference_y(
            self.x_position
        )

        current_actual = (
            current_ref
            + float(e_y_current)
        )

        return (
            y_ref_future
            - current_actual
        )

    def _get_observation(self, x_ctrl=None):
        if x_ctrl is None:
            x_ctrl = self._controller_state()

        d_lqr, d_ff, fallback_action = (
            self._analytical_branch(x_ctrl)
        )

        e_y = float(x_ctrl[0])
        e_y_dot = float(x_ctrl[1])
        e_psi = float(x_ctrl[2])
        e_psi_dot = float(x_ctrl[3])

        preview = [
            self._get_future_error(
                step,
                e_y,
            )
            for step in (1, 2, 3, 4)
        ]

        base = np.array(
            [
                e_y,
                e_y_dot,
                e_psi,
                e_psi_dot,
                self.vx,
            ]
            + preview,
            dtype=np.float32,
        )

        if self.latency_history:
            tau_pred = float(
                np.mean(self.latency_history)
            )
        else:
            tau_pred = 0.0

        self.pred_latency = tau_pred

        delay_norm = (
            self.current_delay_ms / 200.0
        )

        fallback_block = np.array(
            [
                d_lqr,
                d_ff,
                fallback_action,
            ],
            dtype=np.float32,
        )

        history = np.zeros(
            HIST_LEN,
            dtype=np.float32,
        )

        recent_commands = list(
            self.applied_history
        )[::-1]

        for index, value in enumerate(
            recent_commands[:HIST_LEN]
        ):
            history[index] = value

        queue_snapshot = np.zeros(
            QUEUE_LEN,
            dtype=np.float32,
        )

        queue_values = list(
            self.delay_buffer
        )

        if queue_values:
            recent_queue = (
                queue_values[-QUEUE_LEN:][::-1]
            )

            for index, value in enumerate(
                recent_queue[:QUEUE_LEN]
            ):
                queue_snapshot[index] = value

        observation = np.concatenate(
            [
                base,
                np.array(
                    [
                        self.last_latency,
                        tau_pred,
                        delay_norm,
                    ],
                    dtype=np.float32,
                ),
                fallback_block,
                history,
                queue_snapshot,
            ]
        ).astype(np.float32)

        return observation

    # ------------------------------------------------------------
    # Plant and state
    # ------------------------------------------------------------

    def _controller_state(self):
        if self.sensor_noise_std <= 0.0:
            return self.state.copy()

        noisy_state = (
            self.state
            + self.rng.normal(
                0.0,
                self.sensor_noise_std,
                size=4,
            )
        )

        return noisy_state.astype(
            np.float32
        )

    def _compute_error_state(self):
        y_ref = self._get_reference_y(
            self.x_position
        )

        psi_ref = self._get_reference_heading(
            self.x_position
        )

        kappa_ref = self._get_reference_curvature(
            self.x_position
        )

        e_y = (
            self.y_global
            - y_ref
        )

        e_psi = (
            self.psi
            - psi_ref
        )

        e_y_dot = (
            self.vx
            * np.sin(e_psi)
        )

        e_psi_dot = (
            self.plant_gain
            * self.vx
            * np.tan(self.prev_delta)
            / self.L
            - self.vx * kappa_ref
        )

        return np.array(
            [
                e_y,
                e_y_dot,
                e_psi,
                e_psi_dot,
            ],
            dtype=np.float32,
        )

    def _kinematic_update(self, delta):
        delta = float(
            np.clip(
                delta,
                -DELTA_MAX,
                DELTA_MAX,
            )
        )

        t = self.t_step * self.dt

        disturbance_y = (
            self.disturbance_amp
            * np.sin(
                2.0
                * np.pi
                * self.disturbance_freq
                * t
            )
        )

        disturbance_psi = (
            0.25
            * self.difficulty
            * np.sin(
                2.0
                * np.pi
                * self.disturbance_freq
                * 0.7
                * t
                + 0.5
            )
        )

        self.x_global += (
            self.vx
            * np.cos(self.psi)
            * self.dt
        )

        self.y_global += (
            self.vx * np.sin(self.psi)
            + disturbance_y
        ) * self.dt

        self.psi += (
            self.plant_gain
            * self.vx
            * np.tan(delta)
            / self.L
            + disturbance_psi
        ) * self.dt

        self.prev_delta = delta
        self.t_step += 1
        self.x_position = self.x_global
        self.y_actual = self.y_global

        self.state = self._compute_error_state()

        return self.state

    def apply_command(self, delta):
        self._kinematic_update(delta)
        return float(self.state[0])

    # ------------------------------------------------------------
    # Reset and step
    # ------------------------------------------------------------

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)

        self.rng = self.np_random

        self.plant_gain = float(
            self.rng.uniform(
                *self.plant_gain_range
            )
        )

        self.current_delay_ms = float(
            self.rng.uniform(
                *self.delay_range
            )
        )

        self.x_global = 0.0
        self.y_global = 0.0
        self.psi = 0.0
        self.prev_delta = 0.0

        self.state = np.zeros(
            4,
            dtype=np.float32,
        )

        self.x_position = 0.0
        self.y_actual = 0.0

        self.prev_steering = 0.0
        self.prev_applied = 0.0

        self.t_step = 0

        self.latency_history = []
        self.last_latency = 0.0
        self.pred_latency = 0.0

        self.framework_controller.reset()
        self.delay_buffer = (
            self.framework_controller.delay.buffer
        )

        self.applied_history.clear()

        self._generate_reference_path()

        initial_e_y = float(
            self.rng.normal(
                0.0,
                0.10,
            )
        )

        initial_e_psi = float(
            self.rng.normal(
                0.0,
                0.01,
            )
        )

        self.y_global = initial_e_y
        self.psi = initial_e_psi

        self.state = np.array(
            [
                initial_e_y,
                0.0,
                initial_e_psi,
                0.0,
            ],
            dtype=np.float32,
        )

        self.state = self._compute_error_state()
        self._measurement = self._controller_state()
        return self._get_observation(self._measurement), {}

    def step(self, action):
        start_time = time.perf_counter()

        x_ctrl = self._measurement.copy()
        predictor = KinematicPrediction(
            self.x_position, self.vx, self.dt, self.L, DELTA_MAX,
            self._get_reference_y, self._get_reference_heading,
            self._get_reference_curvature,
        )

        d_lqr, d_ff, fallback_action = (
            self._analytical_branch(x_ctrl)
        )

        d_rl = float(
            np.clip(
                action[0],
                -DELTA_MAX,
                DELTA_MAX,
            )
        )

        kappa_ref = self._get_reference_curvature(
            self.x_position
        )

        d_applied, control_info = (
            self.framework_controller.step(
                x_k=x_ctrl,
                ppo_residual=d_rl,
                delay_ms=self.current_delay_ms,
                gain_context=1.0,
                kappa_k=kappa_ref,
                predictor=predictor,
            )
        )

        fallback_used = bool(
            control_info["fallback_used"]
        )

        self.applied_history.append(
            d_applied
        )

        self._kinematic_update(
            d_applied
        )

        e_y_new = float(
            self.state[0]
        )

        e_psi_new = float(
            self.state[2]
        )

        elapsed_ms = (
            time.perf_counter()
            - start_time
        ) * 1000.0

        self.latency_history.append(
            elapsed_ms
        )

        if len(self.latency_history) > self.latency_window:
            self.latency_history.pop(0)

        self.last_latency = elapsed_ms

        # --------------------------------------------------------
        # Reward
        # --------------------------------------------------------

        reward_tracking = (
            -10.0 * (e_y_new ** 2)
            -5.0 * (e_psi_new ** 2)
        )

        reward_control = (
            -0.05 * (d_rl ** 2)
            -0.20
            * (
                (d_applied - self.prev_applied)
                ** 2
            )
        )

        v_ratio = (
            float(control_info["V_horizon"])
            / max(self.V_max, 1e-9)
        )

        reward_safety = (
            -0.10
            * max(
                0.0,
                v_ratio - 0.90,
            )
            ** 2
        )

        reward_fallback = (
            -0.02
            if fallback_used
            else 0.0
        )

        reward_delay = (
            -0.02
            * (self.current_delay_ms / 200.0)
            * abs(e_y_new)
        )

        reward = (
            reward_tracking
            + 0.1 * reward_control
            + reward_safety
            + reward_fallback
            + (reward_delay if self.use_delay_reward else 0.0)
        )

        self.prev_steering = d_rl
        self.prev_applied = d_applied

        terminated = bool(abs(e_y_new) > 2.5)
        truncated = bool(not terminated and self.t_step >= len(self.y_ref) - 1)

        info = {
            "error": e_y_new,
            "fallback_used": fallback_used,
            "delay_ms": self.current_delay_ms,
            "plant_gain": self.plant_gain,
            "queue_len": len(self.delay_buffer),
            "authority": control_info["authority"],
            "authority_rule": control_info["authority_rule"],
            "u_c": control_info["u_c"],
            "u_q": control_info["u_q"],
            "V_horizon": control_info["V_horizon"],
            "V_pred": control_info["V_pred"],
            "fallback_failed": control_info["fallback_failed"],
            "V_applied": control_info["V_applied"],
            "recovery_used": control_info["recovery_used"],
            "recovery_unresolved": control_info["recovery_unresolved"],
            "actual_V_exceeded": bool(self.state @ self.P @ self.state > self.V_max),
            "prediction_error_norm": float(np.linalg.norm(
                self.state - control_info["predicted_state"]
            )),
            "prediction_error_components": np.abs(self.state - control_info["predicted_state"]),
        }

        info.update(control_info)
        info["reward_delay"] = reward_delay if self.use_delay_reward else 0.0
        self._measurement = self._controller_state()
        return (
            self._get_observation(self._measurement),
            reward,
            terminated,
            truncated,
            info,
        )


# ------------------------------------------------------------
# Training
# ------------------------------------------------------------

if __name__ == "__main__":
    raise SystemExit("This module provides the base environment. Train with python scripts/train_robust.py --seed 42 --steps 50000")
