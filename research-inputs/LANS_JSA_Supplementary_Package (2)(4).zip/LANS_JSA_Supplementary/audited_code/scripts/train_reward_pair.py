import argparse,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv,VecNormalize
from stable_baselines3.common.logger import configure
from scripts.paper_env import BenchEnv
p=argparse.ArgumentParser();p.add_argument('--seed',type=int,required=True);a=p.parse_args();torch.set_num_threads(1)
for enabled in [False,True]:
    name=f'reward_{int(enabled)}_seed{a.seed}';base=Path('bench_models')/name
    if base.with_suffix('.zip').exists():raise RuntimeError('Refusing checkpoint overwrite')
    env=VecNormalize(DummyVecEnv([lambda:BenchEnv(latency_reward=enabled,path='train',random_profiles=True,risk_reward=True,reward_mode='tracking')]),norm_obs=True,norm_reward=True,clip_obs=10.,clip_reward=10.,gamma=.995)
    config=dict(learning_rate=3e-4,n_steps=2048,batch_size=256,n_epochs=10,gamma=.995,gae_lambda=.97,ent_coef=0.,clip_range=.2,target_kl=.03,policy_kwargs=dict(net_arch=[64,64],log_std_init=-1.5))
    model=PPO('MlpPolicy',env,seed=a.seed,device='cpu',verbose=0,**config)
    with torch.no_grad():model.policy.action_net.weight.zero_();model.policy.action_net.bias.zero_()
    model.set_logger(configure('bench_results/train_'+name,['csv']))
    start=time.perf_counter();model.learn(total_timesteps=50000);model.save(str(base));env.save(str(base)+'_norm.pkl')
    base.with_suffix('.json').write_text(json.dumps(dict(seed=a.seed,latency_reward=enabled,reward_term='-.02*(delay_ms/200)*abs(next_ey)',actual_steps=model.num_timesteps,seconds=time.perf_counter()-start,config=config),indent=2))
    print('TRAINED',name,model.num_timesteps,flush=True);env.close()
