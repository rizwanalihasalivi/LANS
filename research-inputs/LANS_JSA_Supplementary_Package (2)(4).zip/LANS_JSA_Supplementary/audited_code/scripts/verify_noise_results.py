"""Independently check reported metrics against raw traces and initial conditions."""
from pathlib import Path
import numpy as np
import pandas as pd
root=Path('noise_results');episodes=pd.read_csv(root/'final_episodes.csv').set_index('case_id')
t=pd.read_csv(root/'final_traces.csv.gz',usecols=['case_id','lateral_error','heading_error'])
assert len(episodes)==945 and episodes.index.is_unique
assert np.isfinite(t[['lateral_error','heading_error']].to_numpy()).all()
t['square']=t.lateral_error**2;t['absolute']=t.lateral_error.abs()
a=t.groupby('case_id').agg(n=('square','size'),sum_square=('square','sum'),maximum=('absolute','max'))
np.testing.assert_array_equal(a.n,episodes.steps)
np.testing.assert_allclose(np.sqrt((a.sum_square+episodes.initial_error_m**2)/(a.n+1)),episodes.rmse_m,rtol=1e-9,atol=1e-10)
np.testing.assert_allclose(np.maximum(a.maximum,episodes.initial_error_m.abs()),episodes.max_error_m,rtol=1e-9,atol=1e-10)
last=t.groupby('case_id').lateral_error.last().abs().clip(lower=2.5)
padded=np.sqrt((a.sum_square+episodes.initial_error_m**2+(1000-a.n)*last**2)/1001)
np.testing.assert_allclose(padded,episodes.failure_penalized_rmse_m,rtol=1e-9,atol=1e-10)
assert len(t)==episodes.steps.sum()
print(f'Verified {len(episodes)} episodes and {len(t)} simulated steps; RMSE, peak error and failure penalties match raw traces plus initial states.')
