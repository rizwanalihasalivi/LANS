from pathlib import Path
import pandas as pd
import json,re,copy,subprocess
from docx.enum.text import WD_TAB_ALIGNMENT
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION_START
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
R=Path(__file__).resolve().parent;T=R/'tables';doc=Document();sec=doc.sections[0]
sec.page_width=Pt(595.276);sec.page_height=Pt(793.701);sec.top_margin=Pt(42);sec.bottom_margin=Pt(40);sec.left_margin=Pt(37);sec.right_margin=Pt(37);sec.header_distance=Pt(20);sec.footer_distance=Pt(20)
width=521.276;col=(width-18)/2
# Remove inherited title rules from the runtime template.
for st in doc.styles:
 pr=st.element.find(qn('w:pPr'))
 if pr is not None:
  border=pr.find(qn('w:pBdr'))
  if border is not None:pr.remove(border)
for name in ['Normal','Body Text','Caption','Title','Subtitle','Heading 1','Heading 2']:
 st=doc.styles[name];st.font.name='Times New Roman';st.font.color.rgb=RGBColor(0,0,0)
 rf=st.element.find('.//'+qn('w:rFonts'))
 if rf is not None:
  for attr in ['asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme']:
   rf.attrib.pop(qn('w:'+attr),None)
normal=doc.styles['Normal'];normal.font.size=Pt(8);normal.paragraph_format.line_spacing=Pt(9.5);normal.paragraph_format.space_after=Pt(0);normal.paragraph_format.first_line_indent=Pt(11);normal.paragraph_format.widow_control=True
for name,size in [('Heading 1',8.5),('Heading 2',8.5)]:
 st=doc.styles[name];st.font.size=Pt(size);st.font.bold=(name=='Heading 1');st.font.italic=(name=='Heading 2');st.paragraph_format.space_before=Pt(8);st.paragraph_format.space_after=Pt(5);st.paragraph_format.first_line_indent=Pt(0)
doc.styles['Caption'].font.size=Pt(7.2);doc.styles['Caption'].paragraph_format.first_line_indent=Pt(0);doc.styles['Caption'].paragraph_format.line_spacing=Pt(8.7);doc.styles['Caption'].font.italic=False;doc.styles['Caption'].font.bold=False
header=sec.header.paragraphs[0];header.text='R. Ali and J. Tian\tLANS: timing-aware path tracking';header.paragraph_format.tab_stops.add_tab_stop(Pt(width),WD_TAB_ALIGNMENT.RIGHT)
for run in header.runs:run.font.size=Pt(6.4);run.italic=True
foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.CENTER
foot.paragraph_format.first_line_indent=Pt(0)
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');foot._p.append(field)
current_cols=1
def cols(n):
 global current_cols
 if n==current_cols:return
 s=doc.add_section(WD_SECTION_START.CONTINUOUS);cs=s._sectPr.find(qn('w:cols'));cs.set(qn('w:num'),str(n));cs.set(qn('w:space'),'360');current_cols=n
 # The empty section anchor should not consume ordinary paragraph spacing.
 p=doc.paragraphs[-1];p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0);p.paragraph_format.line_spacing=Pt(1);p.paragraph_format.first_line_indent=Pt(0)
 for r in p.runs:r.font.size=Pt(1)
def para(text,style=None):
 p=doc.add_paragraph(text,style);p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if style is None else WD_ALIGN_PARAGRAPH.LEFT
 return p
p=para('Journal of Systems Architecture — author manuscript','Subtitle');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_after=Pt(16)
for run in p.runs:run.font.size=Pt(10)
p=para('LANS: Arrival Compensation and Neural Residuals\nin Delayed Vehicle Path Tracking','Title');p.paragraph_format.space_after=Pt(8);p.paragraph_format.first_line_indent=Pt(0)
for run in p.runs:run.font.size=Pt(13.4);run.bold=False
p=para('Rizwan Ali and Jie Tian');p.paragraph_format.space_after=Pt(4);p.paragraph_format.first_line_indent=Pt(0)
for run in p.runs:run.font.size=Pt(10.6)
p=para('School of Automotive and Traffic Engineering, Nanjing Forestry University, Nanjing, China');p.runs[0].italic=True;p.runs[0].font.size=Pt(7);p.paragraph_format.first_line_indent=Pt(0)
abs_text=('This empirical study examines delayed vehicle path tracking with timestamped analytical feedback, queued-command arrival prediction, actuator compensation and an optional asynchronous PPO residual. Two frozen validation suites reverse the survival ranking: LANS versus selected linear MPC achieves 97.14% versus 99.05% on 105 physical cells, and 95.24% versus 90.48% on 42 additional cells. Paired analysis averages three frozen policies within each physical cell. Removing arrival prediction together with actuator compensation reduces survival to 76.19% in the component suite. PPO improves average tracking RMSE by only 1.0 mm without improving survival; matched reward retraining changes RMSE by 0.13 mm. Disabling the tested fallback increases survival to 97.62%. Thus the principal useful intervention is grouped analytical compensation, while the residual and supervisor have substantial limitations. Windows prepared-state LANS decisions average 0.895 ms and reach an observed maximum of 8.431 ms; the separately timed frontend-plus-decision proxy reaches 10.204 ms. These records establish neither WCET nor a hard deadline. The contribution is a diagnostic simulation case study with explicit limits on causal attribution, baseline fairness and timing guarantees.')

# Reference-style front matter with separate ruled labels and justified abstract.
t=doc.add_table(rows=2,cols=2);t.autofit=False
for c,w in zip(t.columns,[155,width-155]):c.width=Pt(w)
for row in t.rows:
 for c,w in zip(row.cells,[155,width-155]):c.width=Pt(w)
t.cell(0,0).text='A R T I C L E   I N F O';t.cell(0,1).text='A B S T R A C T'
t.cell(1,0).text='Keywords:\nLatency-aware control\nResidual reinforcement learning\nTimestamped feedback\nRuntime recovery\nPath tracking\nTiming measurement'
t.cell(1,1).text=abs_text
for ir,row in enumerate(t.rows):
 for ic,cell in enumerate(row.cells):
  pr=cell._tc.get_or_add_tcPr();bd=OxmlElement('w:tcBorders')
  for edge in ['top','bottom']:
   e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'3');e.set(qn('w:color'),'555555');bd.append(e)
  pr.append(bd)
  for p in cell.paragraphs:
   p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_before=Pt(5);p.paragraph_format.space_after=Pt(6);p.paragraph_format.line_spacing=Pt(9)
   p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if (ir==1 and ic==1) else WD_ALIGN_PARAGRAPH.LEFT
   for run in p.runs:run.font.size=Pt(7.2 if ic==0 and ir else 8)

cols(2)
table_no=0;fig_no=0
labels={'full':'LANS','zero':'Residual off','mpc':'MPC','lqr_feedback':'LQR','lqr_feedforward':'LQR + FF','ppo_reuse':'Residual-only diagnostic','zero_no_gain':'Residual off / no age gain','no_latency_gain':'No age attenuation','no_cost_gate':'No cost gate','no_fallback':'No fallback','no_arrival_prediction':'No arrival prediction','reward_off':'Reward off','reward_on':'Reward on'}
main=pd.read_csv(T/'legacy_01_controller_ablation.csv')
def tab(caption,heads,rows,wide=False,note=''):
 global table_no
 table_no+=1
 cols(1 if wide else 2)
 p=para(f'Table {table_no}\n{caption}','Caption');p.paragraph_format.keep_with_next=True;p.paragraph_format.space_before=Pt(7);p.paragraph_format.space_after=Pt(3)
 tb=doc.add_table(rows=1,cols=len(heads));tb.autofit=False
 total=width if wide else col
 first=total*.30 if len(heads)>3 else total*.35
 widths=[first]+[(total-first)/(len(heads)-1)]*(len(heads)-1)
 for tc,tw in zip(tb.columns,widths):tc.width=Pt(tw)
 for c,w in zip(tb.columns,widths):c.width=Pt(w)
 for cell,txt in zip(tb.rows[0].cells,heads):cell.text=str(txt)
 for row in rows:
  cells=tb.add_row().cells
  for cell,txt in zip(cells,row):cell.text=str(txt)
 for ir,row in enumerate(tb.rows):
  trpr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
  if ir==0:trpr.append(OxmlElement('w:tblHeader'))
  for ic,cell in enumerate(row.cells):
   cell.width=Pt(widths[ic]);tcpr=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
   for edge in ['top','bottom','left','right']:
    e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single' if (edge=='top' and ir==0) or (edge=='bottom' and ir in [0,len(tb.rows)-1]) else 'nil');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'000000');borders.append(e)
   tcpr.append(borders)
   for p in cell.paragraphs:
    p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_after=Pt(1.4);p.paragraph_format.space_before=Pt(1.4);p.paragraph_format.line_spacing=Pt(8.6);p.paragraph_format.keep_with_next=(ir<len(tb.rows)-1);p.alignment=WD_ALIGN_PARAGRAPH.LEFT if ic==0 else WD_ALIGN_PARAGRAPH.CENTER
    for run in p.runs:run.font.size=Pt(7.2);run.bold=(ir==0)
 p=doc.add_paragraph();p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.line_spacing=Pt(3);p.paragraph_format.space_after=Pt(0)
 if note:
  p=para(note,'Caption');p.paragraph_format.space_after=Pt(5)

def rows_main(methods):
 return [[labels[r.method],f'{r.survivors}/{r.executions}',f'{r.survival_percent:.2f}',f'{r.rmse_mean_m:.4f}',f'{r.worst_observed_m:.4f}',f'{r.penalized_rmse_mean_m:.4f}'] for r in main.set_index('method').loc[methods].reset_index().itertuples()]
def table(key):
 if key=='profiles':tab('Nominal synthetic stress settings before held-out perturbations.',['Profile','τ (s)','Rate (rad/s)','Sensor (ms)','Command (ms)','Remote (ms)'],[['Nominal',0,100,0,0,80],['Actuator',.08,.6,0,0,1000],['Sensor',.04,1,80,0,80],['Gain step',.06,.8,40,0,80],['Noise burst',.04,1,40,0,80],['Combined',.12,.5,120,0,'0–1000 / outage'],['Full command delay',.06,.8,80,200,80]],True)
 elif key=='observation':tab('Policy observation layout (zero-based indices).',['Indices','Features'],[['0–3','Estimated error and kinematic features'],['4','Speed'],['5–8','Four reference previews'],['9–10','Reserved zeros'],['11','Remote delay / 200 ms'],['12–14','Analytical steering components'],['15–19','Five command-history entries'],['20–24','Five remote-queue entries'],['25–27','Measured-error memory'],['28–30','Estimated biases and gain'],['31–33','Packet age, residual, availability'],['34–36','Pose age, actual steering, measured peak']])
 elif key=='training':tab('PPO hyperparameters and rollout budget.',['Parameter','Value'],[['Policy / value hidden layers','64, 64'],['Learning rate','3 × 10⁻⁴'],['Rollout / minibatch','2048 / 256'],['Epochs per rollout','10'],['Discount / GAE λ','0.995 / 0.97'],['Clip range / target KL','0.2 / 0.03'],['Entropy coefficient','0'],['Initial Gaussian log std','−1.5'],['Observation / reward clip','10 / 10'],['Requested / actual transitions','50,000 / 51,200'],['Residual policy seeds','42, 43, 44'],['Residual action scale','0.01 rad']])
 elif key=='theory':
  d=pd.read_csv(R/'sources/nominal_bounds.csv');tab('Sufficient invariant-ellipsoid check for the reduced mode only.',['d̄ (rad)','ρ candidate','Ultimate V','Condition'],[[r.residual_bound_rad,f'{r.rho_candidate:.4f}',f'{r.ultimate_V_bound:.4f}',str(r.sufficient_invariance_condition)] for r in d.itertuples()])
 elif key=='main':tab('Additional 42-cell tracking comparison. Peak is observed before termination.',['Method','Survived / n','Survival (%)','RMSE (m)','Peak (m)','Penalized (m)'],rows_main(['full','zero','mpc','lqr_feedback','lqr_feedforward','ppo_reuse']),True,'Neural methods: three policy seeds per cell; deterministic methods: one. Residual-only is a diagnostic, not standalone PPO.')
 elif key=='pooled':
  d=pd.read_csv(T/'legacy_16_combined_frozen_validation.csv');tab('Pooled frozen validation across 147 physical cells.',['Method','Survived / n','Survival (%)','RMSE (m)','Peak (m)','Penalized (m)'],[[labels[r.method],f'{r.survivors}/{r.executions}',f'{r.survival_percent:.2f}',f'{r.rmse_mean_m:.4f}',f'{r.worst_observed_m:.4f}',f'{r.penalized_rmse_mean_m:.4f}'] for r in d.itertuples()],True)
 elif key=='ablations':tab('Component interventions on the same 42-cell grid.',['Method','Survived / n','Survival (%)','RMSE (m)','Peak (m)','Penalized (m)'],rows_main(['full','no_latency_gain','no_cost_gate','no_fallback','no_arrival_prediction','zero_no_gain']),True)
 elif key=='diagnostics':
  d=pd.read_csv(T/'pilot_original_policy_diagnostics.csv');tab('Residual acceptance and subsequent fallback in original-policy diagnostics.',['Profile','Steps','Gate accepted','Accepted without fallback','Fallback'],[[r.profile.replace('_',' '),r.steps,r.gate_accepted,r.accepted_without_fallback,r.fallback_steps] for r in d.itertuples()],True,'Gate acceptance does not guarantee a nonzero physical effect after saturation or other supervision.')
 elif key=='reward':tab('Matched latency-reward retraining, three seeds per setting.',['Setting','Survived / n','RMSE (m)','Penalized (m)'],[[labels[r.method],f'{r.survivors}/{r.executions}',f'{r.rmse_mean_m:.6f}',f'{r.penalized_rmse_mean_m:.6f}'] for r in pd.read_csv(T/'legacy_13_reward_comparison.csv').itertuples()])
 elif key=='pilot':tab('Residual-contribution pilot; one training seed and separate evaluation splits.',['Split / method','Survived / n','RMSE (m)','Peak (m)','Penalized (m)'],[[r.split+' / '+r.method,f'{r.survivors}/{r.runs}',f'{r.mean_rmse_m:.6f}',f'{r.worst_error_m:.4f}',f'{r.mean_penalized_rmse_m:.6f}'] for r in pd.read_csv(T/'pilot_summary.csv').itertuples()],True)
 elif key=='standalone':
  d=pd.read_csv(T/'standalone_comparison_summary.csv');d=d[d.method.str.startswith('standalone')];tab('Independently trained standalone-PPO pilots (51,200 transitions per seed).',['Deployment','Survived / n','RMSE (m)','Penalized (m)'],[[r.method.replace('standalone_ppo_',''),f'{r.survivors}/{r.runs}',f'{r.mean_rmse_m:.4f}',f'{r.mean_penalized_rmse_m:.4f}'] for r in d.itertuples()],note='Both deployments are unsuccessful short-budget pilots; they are not tuned performance ceilings.')
 elif key=='paths':
  d=pd.read_csv(T/'selected_paths.csv');tab('Path-wise results on the additional validation suite.',['Path / method','Survival (%)','RMSE (m)','Peak (m)','Penalized (m)'],[[r.path.replace('_noise_test','')+' / '+labels[r.method],f'{r.survival_percent:.2f}',f'{r.rmse_mean_m:.4f}',f'{r.worst_observed_m:.4f}',f'{r.penalized_rmse_mean_m:.4f}'] for r in d.itertuples()],True)
 elif key=='timing':
  d=pd.read_csv(T/'windows_timing_summary.csv');tab('Windows prepared-state decision timing (2700 samples per method).',['Method','Mean (ms)','SD (ms)','p95 (ms)','p99 (ms)','Max (ms)'],[[labels[r.method],f'{r.mean_ms:.3f}',f'{r.sd_ms:.3f}',f'{r.p95_ms:.3f}',f'{r.p99_ms:.3f}',f'{r.max_ms:.3f}'] for r in d.itertuples()],True,'Common frontend is timed separately; no physical end-to-end latency or WCET bound is implied.')
 elif key=='response':
  d=pd.read_csv(T/'response_01_response_cases.csv').groupby('profile').response_95_percent_ms.agg(['mean','max']);tab('Component response simulation, aggregated over prescribed steps and computation paths.',['Profile','Mean t95 (ms)','Max t95 (ms)','Mean travel proxy (m)'],[[ix.replace('_',' '),f'{r["mean"]:.1f}',f'{r["max"]:.0f}',f'{.025*r["mean"]:.2f}'] for ix,r in d.iterrows()],True,'Each profile has 75 cases. Travel proxy is 25 m/s × simulated response time, not measured blind distance.')
 elif key=='energy':
  d=pd.read_csv(T/'energy_energy_summary.csv');tab('Windows CPU-package energy pilot, mean ± sample SD over three workloads.',['Method','Power (W)','Energy (J)','Idle-adjusted (J)'],[[labels[r.method],f'{r.cpu_package_mean_w_mean:.3f} ± {r.cpu_package_mean_w_std:.3f}',f'{r.cpu_package_energy_j_mean:.2f} ± {r.cpu_package_energy_j_std:.2f}',f'{r.baseline_adjusted_energy_j_mean:.2f} ± {r.baseline_adjusted_energy_j_std:.2f}'] for r in d.itertuples()],True,'Approximately 90 s per workload. Telemetry gaps and idle variability limit comparative interpretation.')
# Additional tables retain important earlier evidence without mixing hosts or architectures.
original_table=table
def table(key):
 if key=='observer':
  d=pd.read_csv(R/'sources/observer_summary.csv');tab('Observer comparison on 105 physical cells (five evaluation seeds).',['Configuration','Survived / n','Survival (%)','RMSE (m)','Peak (m)','Penalized (m)'],[[r.method.replace('_',' '),f'{r.survived}/{r.episodes}',f'{r.survival_percent:.2f}',f'{r.mean_rmse_m:.4f}',f'{r.worst_observed_m:.4f}',f'{r.failure_penalized_rmse_m:.4f}'] for r in d.itertuples()],True)
 elif key=='linux':
  d=pd.read_csv(T/'legacy_07_fair_timing.csv');tab('Earlier Linux prepared-state decision timing, kept separate from Windows.',['Method','Mean (ms)','p95 (ms)','p99 (ms)','Max (ms)'],[[labels[r.method],f'{r.mean_ms:.3f}',f'{r.p95_ms:.3f}',f'{r.p99_ms:.3f}',f'{r.max_observed_ms:.3f}'] for r in d.itertuples()],True,'2700 samples per method. These are the earlier host measurements used by the response simulation.')
 elif key=='diagnostic_matrix':
  import importlib.util
  spec=importlib.util.spec_from_file_location('lans_config',R/'audited_code/config.py');cfg=importlib.util.module_from_spec(spec);spec.loader.exec_module(cfg)
  tab('Inherited four-feature diagnostic matrix Pd (rounded).',['Row','Column 1','Column 2','Column 3','Column 4'],[[str(i+1)]+[f'{v:.7f}' for v in row] for i,row in enumerate(cfg.P_LQR)],True)
 else:original_table(key)
old_table=table
def table(key):
 if key in ['wcet_windows','wcet_linux']:
  host=key.split('_')[1];d=pd.read_csv(T/'wcet_observed_summary.csv');d=d[d.host==host].set_index('method').loc[list(labels)].reset_index()
  tab(host.title()+' finite-record timing audit: observed maxima, not verified WCET bounds.', ['Method','n','p99.9 (ms)','Max (ms)','>10 ms','Margin (ms)','Proxy max (ms)'], [[labels[z.method],z.n,f'{z.p999_ms:.3f}',f'{z.max_observed_ms:.3f}',z.exceedances_10ms,f'{z.observed_margin_ms:.3f}',f'{z.frontend_plus_decision_proxy_max_ms:.3f}'] for z in d.itertuples()],True,'Margin = 10 ms minus observed decision maximum. Proxy = separately measured frontend plus decision; it is not a directly timed full loop. No verified WCET bound is established for any listed method.')
 else:old_table(key)
previous_table=table
def table(key):
 if key=='paired':
  d=pd.read_csv(T/'paired_cluster_summary.csv');d=d[d.metric=='rmse_m']
  tab('Paired RMSE differences and physical-seed sensitivity.', ['Comparison','Cells','Seeds','Mean (mm)','Seed min (mm)','Seed max (mm)'], [[z.comparison,z.cells,z.seeds,f'{1000*z.difference:.3f}',f'{1000*z.seed_min:.3f}',f'{1000*z.seed_max:.3f}'] for z in d.itertuples()],True,'First named method minus second. Frozen policy means are paired within physical cells; ranges are not confidence intervals.')
 else:previous_table(key)
prior_table=table
def table(key):
 if key=='software_loop':
  d=pd.read_csv(T/'software_loop_timing.csv')
  tab('Measured contiguous simulation-cycle timing on Linux; no WCET guarantee.', ['Method','Added load','n','Mean (ms)','Max exec. (ms)','Max response (ms)','Misses'], [[z.method,z.load,z.n,f'{z.mean_execution_ms:.3f}',f'{z.max_execution_ms:.3f}',f'{z.max_response_ms:.3f}',z.deadline_misses] for z in d.itertuples()],True,'Response includes start lateness relative to the absolute release grid. Each row aggregates three profiles and two short repetitions. Physical I/O is not measured.')
 else:prior_table(key)
refs=[x['text'] for x in json.loads((R/'references.json').read_text())]

from equations import math_nodes
listing_no=0
for line in (R/'paper.txt').read_text().splitlines():
 if not line:continue
 if not line.startswith(('@fig ','@table ','@code ')):cols(1 if line.startswith(('# 4.','# 7.','## 7.1.','## 7.2.','## 7.4.','## 7.5.','## 7.6.','## 7.7.')) else 2)
 if line.startswith('# '):para(line[2:],'Heading 1')
 elif line.startswith('## '):para(line[3:],'Heading 2')
 elif line.startswith('@eq '):
  txt,n=line[4:].rsplit('|',1);p=doc.add_paragraph();p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_before=Pt(5);p.paragraph_format.space_after=Pt(5);p.paragraph_format.line_spacing=1.0
  p.paragraph_format.tab_stops.add_tab_stop(Pt(col-2),WD_TAB_ALIGNMENT.RIGHT)
  pr=p._p.get_or_add_pPr();rp=OxmlElement('w:rPr');sz=OxmlElement('w:sz');sz.set(qn('w:val'),'16');rp.append(sz);pr.append(rp)
  p._p.append(copy.deepcopy(math_nodes[n.strip()]));p.add_run('\t('+n.strip()+')')
  for run in p.runs:run.font.size=Pt(8)
 elif line.startswith('@table '):table(line[7:])
 elif line.startswith('@fig '):
  name,caption=line[5:].split('|');cols(2 if name in ['fig06_reward','fig09_geometry'] else 1);fig_no+=1;p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_before=Pt(3);p.paragraph_format.keep_with_next=True;
  from PIL import Image
  imgpath=R/'figures'/(name+'.png');iw,ih=Image.open(imgpath).size
  imagewidth=col if name in ['fig06_reward','fig09_geometry'] else min(width,(210 if name=='fig01_architecture' else 145)*iw/ih)
  p.paragraph_format.line_spacing=1.0
  p.add_run().add_picture(str(imgpath),width=Pt(imagewidth))
  p=para(f'Fig. {fig_no}. '+caption,'Caption');p.paragraph_format.space_before=Pt(2);p.paragraph_format.space_after=Pt(4)
 elif line.startswith('@code '):
  key,caption=line[6:].split('|',1);cols(2);listing_no+=1
  p=para(f'Listing {listing_no}. '+caption,'Caption');p.paragraph_format.keep_with_next=True;p.paragraph_format.space_before=Pt(8);p.paragraph_format.space_after=Pt(4)
  lines=(R/'code_excerpts'/(key+'.py')).read_text().splitlines()
  for i,txt in enumerate(lines,1):
   p=doc.add_paragraph();p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=Pt(8);p.paragraph_format.keep_with_next=(len(lines)-2 <= i < len(lines))
   run=p.add_run(f'{i:02}  '+txt);run.font.name='Liberation Mono';run.font.size=Pt(6.3)
 elif line.startswith('@algorithm'):
  from algorithm_layout import add_algorithm
  add_algorithm(doc)
 elif line=='@references':
  for i,ref in enumerate(refs,1):
   p=para(f'[{i}] '+ref);p.paragraph_format.space_after=Pt(0.5);p.paragraph_format.left_indent=Pt(14);p.paragraph_format.first_line_indent=Pt(-14);p.paragraph_format.line_spacing=Pt(7.5)
   for run in p.runs:run.font.size=Pt(6.8)
 else:para(line)
cols(1)
doc.core_properties.title='LANS: Arrival Compensation and Neural Residuals in Delayed Vehicle Path Tracking';doc.core_properties.author='Rizwan Ali and Jie Tian';doc.core_properties.subject='Timing-aware residual control simulation and scoped measurements'
doc.save(R/'LANS_JSA_Manuscript.docx')
print('Tables',table_no,'Figures',fig_no,'paragraphs',len(doc.paragraphs))
