# LANS host-C port and numerical validation

This package contains an implemented C decision path, exported deterministic PPO actors and actual comparison results. It is not a full embedded firmware release or a WCET certificate.

## Frozen baseline

The snapshot under frozen/reference contains the selected LANS controller, configuration, simulation code and three original policies (training seeds 42, 43 and 44). frozen/manifest.json records SHA-256 values. No training was performed and no benchmark parameters were retuned.

Selected parameters: gain scale 0.25, observer q_bias 0.0016, steering damping 0.5, adaptive measurement-noise alpha 0.1, residual scale 0.01 rad. The legacy quadratic threshold remains 10.2231 and is not an invariant-set certificate.

## Implemented in C

- Noise-aware five-state EKF and timestamp propagation from a bounded steering-history window.
- Reference lookup, curvature, bias-aware kinematic prediction and arrival-state feedback.
- Delayed remote-residual mailbox, stale-packet expiry, attenuation and cost gate.
- Local fallback, hysteresis and bounded scalar recovery optimization.
- Normalization and deterministic forward inference for all three 37–64–64–1 PPO actors.

Value networks and sampling distributions are not needed for deterministic deployment. Actor weights are unchanged. Numerical float32 operations in the original noise adaptation are preserved explicitly.

The controller retains 10,240 bytes of caller-owned state on the tested x86-64 host. There are no explicit heap allocations in the C decision functions. This does not establish a complete target memory bound for runtime libraries or stacks.

## Outside this port

Python still constructs the 37-feature observation, maintains simulation/environment memory, supplies measured pose and executed-steering history, and simulates the plant, sensors and actuator. The host adapter preserves these operations. This is not a standalone sensor-to-actuator executable. Source-level bounded loops do not constitute an executable WCET result.

## Input contract

- VX 25 m/s, DT 0.01 s, wheelbase 2.6 m, steering clipping ±0.5 rad.
- Exactly 1,001 reference samples at 0.25 m spacing.
- At most 22 known in-flight actuator commands.
- Pose age at most 14 ticks; at most 16 steering-history samples with their start timestamp.
- Ordered consecutive new pose packets; repeated held packets allowed.
- Remote delay 0–1,000 ms; one mailbox push/service per control tick.
- Remote storage capacity 101 packets before service; evaluated maximum after service 100.
- Finite inputs, valid array lengths/pointers and initialized state.
- Tick limit 10,000,000; float32/binary64 arithmetic, default round-to-nearest-even, no fast-math.
- Recovery optimizer capped at 500 objective evaluations. The largest observed count was 34.

Contract violations return error codes. The adapter raises an exception. A vehicle-level emergency response to a violated contract has not been implemented or validated. Do not interpret error detection as a proven safe maneuver.

## Reproduction

Tested on Linux x86-64 with GCC 13.3.0, Python 3.12, NumPy 2.3.5, SciPy 1.17.0, CPU Torch 2.14.1+cpu, Gymnasium 1.4.0 and Stable-Baselines3 2.9.0. See results/environment_packages.txt for the recorded environment. This archive is not a Windows installer.

Create an isolated Python environment with these dependencies. CPU Torch was installed from its official CPU wheel index. Run:

    bash build.sh
    PORT_PYTHON=/path/to/environment/bin/python bash run_validation.sh

The test script re-runs the host comparisons. Existing Patmos audit files are separate evidence; it does not rebuild the target. To repeat that audit with the separately saved compiler checkpoint:

    LANS_WCET_TOOLCHAIN=/absolute/path/to/wcet_toolchain bash patmos/build_audit.sh

That command currently fails at controller PML export and final linking, as documented in the report. The headers under patmos/include supply ABI declarations solely for the compile audit. They do not implement the missing math/runtime functions.

The C core is src/lans.c; actors are src/policy.c with generated src/policies.h. src/lans.h describes the API. bridge.py is the host simulation adapter. SciPy's BSD license is included for the translated bounded minimization routine.

## Results and limits

Read RESULTS.md and results/summary.json first. CSVs contain the individual cases, paired comparisons, recovery cases and contract checks. Results are observed numerical agreement over the stated inputs, not a universal equivalence proof, safety proof, superiority comparison, or WCET result.

The 63 closed-loop pairs use three training seeds × three paths × seven profiles, with one physical evaluation seed (3200). Both Python and C survived all 63 cases. This restricted port-validation set does not replace the paper's broader survival benchmark and does not compare against MPC.
