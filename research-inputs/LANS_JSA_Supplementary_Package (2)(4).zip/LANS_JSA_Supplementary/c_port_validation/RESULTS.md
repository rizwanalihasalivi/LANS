# LANS C-port validation results
7 October 2026

**The selected LANS decision path and three deterministic PPO actors have been implemented in C and tested against the frozen Python implementation. Host numerical validation is complete for the cases below. Full embedded execution and verified WCET remain unestablished.**

| Test | Executed coverage | Result |
|---|---|---|
| Same-input controller comparison | 63 cases, 63,000 steps | 0 decision-flag mismatches |
| Steering agreement, same inputs | All 63,000 steps | Maximum absolute difference 1.048 × 10⁻¹⁵ rad |
| PPO forward inference | Three unchanged saved actors | Maximum normalized-action difference 2.086 × 10⁻⁷ |
| Closed-loop comparison | 63 pairs, 126 episodes, 126,000 steps | Same survival and episode length in every pair |
| Closed-loop trajectory agreement | Same seeded physical conditions | Maximum lateral-state difference 2.980 × 10⁻⁷ m |
| Closed-loop tracking RMSE agreement | All paired episodes | Maximum RMSE difference 2.489 × 10⁻⁸ m |
| Closed-loop steering agreement | All paired episodes | Maximum difference 1.259 × 10⁻⁷ rad |
| Fallback/recovery counts | All paired episodes | No count differences |
| Off-nominal recovery tests | 2,000 inputs; 1,839 optimizer activations | 0 decision-flag mismatches |
| Recovery steering agreement | All recovery test inputs | Maximum difference 8.105 × 10⁻⁸ rad |
| Recovery evaluation count | Optimizer calls in recovery tests | Observed maximum 34; implemented cap 500 |
| Rejection checks | 10 invalid-input/capacity tests | 10 passed |
| Native sanitizer run | 20,000 queue/control steps | No reported address/undefined-behavior errors |

The closed-loop set uses training seeds 42, 43 and 44, three paths (DLC, held-out sine, held-out chirp), seven stress profiles and physical seed 3200. Each Python and C episode ran 1,000 steps. Both implementations survived 63/63 in this set. This is a port-validation result, not a new claim that LANS beats MPC or survives every condition. No competing controller was evaluated in this campaign.

Same-input checks used the Python policy action for both controller paths to isolate controller arithmetic; C policy outputs were compared separately. Closed-loop C runs used the C policy and C controller with the shared Python observation construction and simulated plant. Thus the closed-loop test includes policy approximation effects, but does not test physical I/O or a wholly C observation frontend.

The off-nominal tests used seed 7119, lateral errors in [-5,5] m, heading errors in [-0.7,0.7] rad, arrival horizons of 0/1/10/22 commands and delays including half-tick rounding boundaries. They deliberately exercised recovery, which was not activated in the main same-input sweep. Agreement here is observed numerical agreement, not proof over every input.

## Target compilation and WCET

| Stage | Status |
|---|---|
| Native host C library | Built and tested |
| Patmos controller object | Generated |
| Patmos policy object | Generated |
| Patmos linked LANS executable | Failed: 40 distinct unresolved math/runtime symbols |
| Controller timing metadata (PML) | Failed: compiler ConstantInt casting assertion |
| Numerical full-LANS WCET | Not established |
| Physical sensor-to-actuator latency | Not measured |

The missing functions include floating-point compiler helpers, memcpy/memset and transcendental math routines. The full list and linker diagnostics are in patmos/link.log and results/summary.json. No unresolved function was assigned zero cost or replaced by a dummy implementation.

The compiler assertion occurred while analyzing/exporting the controller. Disabling loop-strength reduction allowed object generation, but not controller PML export. An O0 attempt also failed. Compiler assertions were not disabled. The compile-audit headers provide declarations only, not a target runtime. Neither the target object nor the host agreement results constitute a verified executable timing bound.

The earlier 33-cycle clamp-function result is unrelated to these controller measurements and must not be used as a LANS WCET number.

## Changes and scope

The C implementation preserves the selected gains, policy weights, normalization, gating, fallback threshold and modeled dynamics. It adds fixed capacities and explicit error returns within a stated input contract. No PPO retraining or controller tuning was performed. Growing Python histories are replaced by bounded windows at the C boundary. Python still assembles observations and supplies simulation inputs. Target math/runtime integration, complete frontend/I/O integration, controller PML generation and target-model validation remain outstanding.

The source uses no explicit allocation calls in the decision functions. This does not bound hidden runtime-library behavior or the complete stack. Native sanitizer checks cover the executed cases only.

The archived code includes a final guard against integer overflow in invalid history-window arguments. That guard was checked by the sanitizer harness; it does not change arithmetic on the valid inputs used in the numerical sweep.

## Suggested manuscript wording

> A bounded-storage C implementation of the selected controller decision path and deterministic neural actors was compared with the frozen Python implementation. Across 63 paired simulated episodes, survival outcomes, episode lengths and fallback counts agreed. The maximum lateral-state difference was 2.98 × 10⁻⁷ m. These results support numerical consistency for the evaluated cases. They do not establish physical end-to-end latency, universal functional equivalence, formal safety, or a verified WCET bound.

This paragraph can support a software-validation subsection or supplement. It should not replace the main robustness experiments, and the current paper must not state that WCET is verified.

## Files

- results/shadow_all.csv: same-input comparisons.
- results/closed_loop_all.csv: 126 episode-level records.
- results/paired_all.csv: 63 paired differences.
- results/recovery_cases.csv: 2,000 recovery-case records.
- results/contracts.csv: ten rejection checks.
- results/summary.json: machine-readable summary and unresolved symbols.
- results/artifact_hashes.json and frozen/manifest.json: provenance.
- README.md: contracts, coverage and reproduction instructions.
