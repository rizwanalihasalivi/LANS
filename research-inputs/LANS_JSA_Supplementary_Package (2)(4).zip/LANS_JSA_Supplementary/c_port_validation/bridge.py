"""Host validation adapter. Python owns simulated sensors, plant and observation assembly.
The C state owns the selected controller decision path. This is NOT embedded firmware.
"""
from pathlib import Path
import ctypes as C
import numpy as np
ROOT=Path(__file__).resolve().parent
lib=C.CDLL(str(ROOT/'liblans.so'))
D=C.POINTER(C.c_double);F=C.POINTER(C.c_float);V=C.c_void_p
lib.lans_size.restype=C.c_size_t
lib.lans_init.argtypes=[V,D,C.c_int]
lib.lans_prepare.argtypes=[V,C.c_double,D,C.c_int,C.c_int,D,C.c_int,C.c_int,D,C.c_int,C.c_int]
lib.lans_state.argtypes=[V,D]
lib.lans_analytical.argtypes=[V,D];lib.lans_analytical.restype=C.c_double
lib.lans_step.argtypes=[V,C.c_double,C.c_double,C.c_int,D]
lib.lans_queue.argtypes=[V,D]
lib.lans_policy.argtypes=[C.c_int,F,F]
def arr(x):return np.ascontiguousarray(x,dtype=np.float64)
def ptr(a):return a.ctypes.data_as(D)
class Port:
 def __init__(self,env):
  self.env=env;self.c=env.framework_controller
  self.storage=C.create_string_buffer(lib.lans_size());self.initialized=False
 def reset(self):self.initialized=False
 def prepare(self,x,predictor):
  if not self.initialized:
   ref=arr(self.env.y_ref)
   rc=lib.lans_init(self.storage,ptr(ref),len(ref))
   if rc:raise ValueError(f'C init contract {rc}')
   self.initialized=True
  c=self.c
  hist=arr(c.executed_inputs[-16:]);start=len(c.executed_inputs)-len(hist)
  commands=arr(c.known_command_sequence);xx=arr(x)
  rc=lib.lans_prepare(self.storage,predictor.position,ptr(xx),c.pose_stamp,c.now_tick,ptr(hist),start,len(hist),ptr(commands),len(commands),int(np.asarray(x).dtype==np.float32))
  if rc:raise ValueError(f'C prepare contract {rc}: stamp={c.pose_stamp}, now={c.now_tick}, history={start}:{len(c.executed_inputs)}')
  state=np.empty(39);lib.lans_state(self.storage,ptr(state));return state
 def analytical(self,x):
  xx=arr(x);return lib.lans_analytical(self.storage,ptr(xx))
 def step(self,residual,delay,available=True):
  out=np.empty(20)
  rc=lib.lans_step(self.storage,residual,delay,int(available),ptr(out))
  if rc:raise ValueError(f'C step contract {rc}')
  return out
 def queue(self):
  out=np.empty(101);n=lib.lans_queue(self.storage,ptr(out));return out[:n]
 def policy(self,seed,obs):
  xx=np.ascontiguousarray(obs,dtype=np.float32);out=C.c_float()
  rc=lib.lans_policy(seed-42,xx.ctypes.data_as(F),C.byref(out))
  if rc:raise ValueError(f'C policy contract {rc}')
  return float(out.value)
 def install(self):
  from controllers.analytical_branch import AnalyticalCommand
  c=self.c;original_reset=c.reset
  def reset():
   original_reset();self.reset()
  def prepare(x,predictor):
   s=self.prepare(x,predictor)
   c.filtered=s[:4].copy();c.estimates=s[4:7].copy();c.last_position=predictor.position;c.current_predictor=predictor
  def compute(x,kappa):
   v=self.analytical(x);return AnalyticalCommand(v,0.,v)
  def step(x_k,ppo_residual,delay_ms=0.,gain_context=1.,kappa_k=0.,predictor=None):
   prepare(x_k,predictor)
   v=self.step(ppo_residual,delay_ms,c.remote.available)
   c.last_u=v[0];c.arrived_residual=v[2];c.accepted_residual=v[3]
   c.remote.last_age_steps=int(v[13]);c.remote.buffer.clear();c.remote.buffer.extend(self.queue())
   c.inner.recovery_latched=bool(v[12])
   info=dict(u_k=v[0],u_lqr=v[1],u_ff=0.,u_analytical=v[1],residual_raw=ppo_residual,
    authority=1.,authority_mode='ABLATION',authority_rule='FIXED_AUTHORITY',
    u_c=float(np.clip(v[1]+v[3],-.5,.5)),u_q=float(np.clip(v[1]+v[3],-.5,.5)),
    V_pred=v[4],V_horizon=v[4],V_fallback=v[5],V_applied=v[6],
    fallback_used=bool(v[7]),fallback_failed=bool(v[7] and v[5]>10.2231),
    recovery_used=bool(v[8]),recovery_unresolved=bool(v[9]),residual_rejected=bool(v[10]),
    envelope_risk=bool(v[11]),recovery_latched=bool(v[12]),remote_age_steps=int(v[13]),
    queue_len=int(v[14]),predicted_state=v[16:20].copy(),command_age_steps=0,
    delay_ms=delay_ms,remote_delay_ms=delay_ms,actuator_delay_ms=0.,gain_context=c.estimates[2],
    remote_available=c.remote.available,remote_residual_arrived=v[2],remote_residual_accepted=v[3],
    estimated_lateral_bias=c.estimates[0],estimated_yaw_bias=c.estimates[1],estimated_gain=c.estimates[2],
    prediction_mode='kinematic',u_lqr_queued=v[1])
   return v[0],info
  c.reset=reset;c.prepare=prepare;c.inner.analytical.compute=compute;c.step=step
