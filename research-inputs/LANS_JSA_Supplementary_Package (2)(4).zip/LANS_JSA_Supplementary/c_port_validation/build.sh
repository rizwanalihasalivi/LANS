#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
gcc -std=c11 -O2 -fno-fast-math -ffp-contract=off -Wall -Wextra -Werror -shared -fPIC src/lans.c src/policy.c -lm -o liblans.so
