from validate import *
def run(seed,profile,path,eval_seed,backend):
 e=BenchEnv(profile=profile,path=path,heldout=True);p=Port(e)
 if backend=='C':p.install()
 obs,_=e.reset(seed=eval_seed);squared=[float(e.state[0])**2];peak=abs(float(e.state[0]))
 trace=[];falls=recoveries=0
 for t in range(1000):
  a=np.array([p.policy(seed,obs)],dtype=np.float32) if backend=='C' else action(seed,obs)
  obs,_,term,trunc,info=e.step(a)
  error=float(e.state[0]);squared.append(error*error);peak=max(peak,abs(error))
  falls+=info['fallback_used'];recoveries+=info['recovery_used']
  trace.append((float(e.state[0]),float(e.state[2]),float(info['u_k'])))
  if term or trunc:break
 e.close()
 return dict(seed=seed,profile=profile,path=path,eval_seed=eval_seed,backend=backend,steps=len(trace),survived=not term,
             rmse_m=float(np.sqrt(np.mean(squared))),max_abs_error_m=peak,fallback_count=falls,recovery_count=recoveries),np.array(trace)
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--quick',action='store_true');a=ap.parse_args()
 rows=[];paired=[]
 for path in (['dlc'] if a.quick else ['dlc','sine_noise_test','chirp_noise_test']):
  for profile in (['combined'] if a.quick else list(PROFILES)):
   py,pt=run(a.seed,profile,path,3200,'Python')
   cr,ct=run(a.seed,profile,path,3200,'C')
   rows.extend([py,cr]);n=min(len(pt),len(ct))
   row=dict(seed=a.seed,path=path,profile=profile,eval_seed=3200,
    same_survival=py['survived']==cr['survived'],same_length=len(pt)==len(ct),
    abs_rmse_difference_m=abs(py['rmse_m']-cr['rmse_m']),
    max_abs_trajectory_difference_m=float(np.max(abs(pt[:n,0]-ct[:n,0]))),
    max_abs_command_difference_rad=float(np.max(abs(pt[:n,2]-ct[:n,2]))),
    fallback_count_difference=cr['fallback_count']-py['fallback_count'],
    recovery_count_difference=cr['recovery_count']-py['recovery_count'])
   paired.append(row);print(json.dumps(row),flush=True)
   for name,data in [('closed_loop',rows),('paired',paired)]:
    with (ROOT/f'results/{name}_{a.seed}.csv').open('w',newline='') as f:
     w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
