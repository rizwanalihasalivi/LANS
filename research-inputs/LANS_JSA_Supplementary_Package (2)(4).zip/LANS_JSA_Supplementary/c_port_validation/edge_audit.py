from validate import *
from bridge import lib,ptr,arr,C
from models.kinematic_prediction import KinematicPrediction
rng=np.random.default_rng(7119)
e=BenchEnv(profile='nominal',path='dlc',heldout=True);e.reset(seed=3200)
c=e.framework_controller;p=Port(e)
rows=[]
for case in range(2000):
 c.reset();p.reset()
 position=float(rng.uniform(0,249))
 x=arr([rng.uniform(-5,5),0.,rng.uniform(-.7,.7),0.])
 c.pose_stamp=c.now_tick=0;c.executed_inputs=[]
 c.known_command_sequence=[float(rng.uniform(-.5,.5)) for _ in range(int(rng.choice([0,1,10,22])))]
 pred=KinematicPrediction(position,e.vx,e.dt,e.L,.5,e._get_reference_y,e._get_reference_heading,e._get_reference_curvature)
 c.prepare(x,pred);p.prepare(x,pred)
 residual=float(rng.uniform(-.02,.02));delay=float(rng.choice([0,5,15,20,80,995,1000]))
 u,info=c.step(x,residual,delay,1.,pred.curvature(position),pred)
 v=p.step(residual,delay)
 flags=[info['fallback_used'],info['recovery_used'],info['recovery_unresolved'],info['residual_rejected'],info['envelope_risk'],info['recovery_latched']]
 rows.append(dict(case=case,position=position,error_y=x[0],error_psi=x[2],commands=len(c.known_command_sequence),
  recovery=info['recovery_used'],fallback=info['fallback_used'],optimizer_evals=int(v[15]),
  abs_command_difference=abs(u-v[0]),abs_value_difference=abs(info['V_applied']-v[6]),
  flag_mismatches=sum(bool(a)!=bool(b) for a,b in zip(flags,v[7:13]))))
with (ROOT/'results/recovery_cases.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=dict(cases=len(rows),recovery_cases=sum(r['recovery'] for r in rows),
 max_abs_command_difference=max(r['abs_command_difference'] for r in rows),
 max_abs_value_difference=max(r['abs_value_difference'] for r in rows),
 flag_mismatches=sum(r['flag_mismatches'] for r in rows),max_optimizer_evals=max(r['optimizer_evals'] for r in rows))
print('RECOVERY',json.dumps(summary),flush=True)
checks=[]
for label,residual,delay in [('nan_residual',float('nan'),0),('infinite_residual',float('inf'),0),
 ('negative_delay',0,-1),('delay_over_contract',0,1000.1),('nan_delay',0,float('nan'))]:
 before=bytes(p.storage);out=np.zeros(20);rc=lib.lans_step(p.storage,residual,delay,1,ptr(out))
 checks.append(dict(check=label,return_code=rc,unchanged=before==bytes(p.storage),passed=rc<0 and before==bytes(p.storage)))
for label,stamp,now,hn,nc in [('pose_age_over_contract',0,15,15,0),('too_many_commands',0,0,0,23),
 ('too_many_history',0,0,17,0),('negative_timestamp',-1,0,0,0)]:
 before=bytes(p.storage);x=np.zeros(4);hist=np.zeros(17);cmd=np.zeros(23)
 rc=lib.lans_prepare(p.storage,1.,ptr(x),stamp,now,ptr(hist),0,hn,ptr(cmd),nc,0)
 checks.append(dict(check=label,return_code=rc,unchanged=before==bytes(p.storage),passed=rc<0 and before==bytes(p.storage)))
badobs=np.zeros(37,dtype=np.float32);badobs[0]=np.nan;out=C.c_float()
rc=lib.lans_policy(0,badobs.ctypes.data_as(C.POINTER(C.c_float)),C.byref(out))
checks.append(dict(check='nan_policy_observation',return_code=rc,unchanged=True,passed=rc<0))
with (ROOT/'results/contracts.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(checks[0]));w.writeheader();w.writerows(checks)
summary['contract_tests']=len(checks);summary['contract_passed']=sum(r['passed'] for r in checks)
(ROOT/'results/edge_summary.json').write_text(json.dumps(summary,indent=2))
print('CONTRACTS',json.dumps(checks),flush=True)
