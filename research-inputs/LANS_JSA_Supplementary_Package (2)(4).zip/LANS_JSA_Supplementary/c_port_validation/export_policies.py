from pathlib import Path
import pickle
import numpy as np
from stable_baselines3 import PPO
ROOT=Path(__file__).resolve().parent
refs=ROOT/'frozen/reference/robustness_models'
sections=['/* Frozen deterministic PPO actors. Exported without retraining. */']
groups={k:[] for k in ['MEAN','VAR','W1','B1','W2','B2','W3','B3']}
for seed in [42,43,44]:
 model=PPO.load(refs/f'ppo_seed{seed}.zip',device='cpu')
 norm=pickle.load(open(refs/f'ppo_seed{seed}_norm.pkl','rb'))
 assert norm.clip_obs==10 and norm.epsilon==1e-8
 sd=model.policy.state_dict()
 vals={'MEAN':norm.obs_rms.mean,'VAR':norm.obs_rms.var}
 for dest,key in [('W1','mlp_extractor.policy_net.0.weight'),('B1','mlp_extractor.policy_net.0.bias'),('W2','mlp_extractor.policy_net.2.weight'),('B2','mlp_extractor.policy_net.2.bias'),('W3','action_net.weight'),('B3','action_net.bias')]:
  vals[dest]=sd[key].cpu().numpy()
 for k,v in vals.items():groups[k].append(np.asarray(v).ravel())
for name,rows in groups.items():
 typ='double' if name in ['MEAN','VAR'] else 'float'
 data=['{'+','.join(format(float(v),'.17g') if typ=='double' else float(v).hex()+'f' for v in row)+'}' for row in rows]
 sections.append('static const '+typ+' '+name+'[3]['+str(len(rows[0]))+']={'+',\n'.join(data)+'};')
(ROOT/'src/policies.h').write_text('\n'.join(sections))
