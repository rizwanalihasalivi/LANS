#!/usr/bin/env bash
# Compile/link audit only. A successful object build is not a WCET certificate.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
TOOLCHAIN="${LANS_WCET_TOOLCHAIN:?Set LANS_WCET_TOOLCHAIN to the restored wcet_toolchain directory}"
source "$TOOLCHAIN/activate.sh"
clang -target patmos-unknown-unknown-elf -std=c11 -O2 -nostdinc -Ipatmos/include -c src/lans.c -o patmos/controller.bc
llc -march=patmos -O2 -disable-lsr -mpatmos-disable-vliw -filetype=obj patmos/controller.bc -o patmos/controller.o > patmos/object_compile.log 2>&1
clang -target patmos-unknown-unknown-elf -std=c11 -O2 -nostdinc -Ipatmos/include -c src/policy.c -o patmos/policy.bc
llc -march=patmos -O2 -disable-lsr -mpatmos-disable-vliw -mforce-block-labels -mserialize-roots=lans_policy -mserialize=patmos/policy.pml -filetype=obj patmos/policy.bc -o patmos/policy.o
llc -march=patmos -O2 -disable-lsr -mpatmos-disable-vliw -mforce-block-labels -mserialize-roots=lans_step -mserialize=patmos/controller.pml -filetype=obj patmos/controller.bc -o patmos/controller_with_pml.o > patmos/compile.log 2>&1
EXPORT_STATUS=$?
llvm-objdump -t patmos/controller.o patmos/policy.o > patmos/symbols.txt
"$TOOLCHAIN/gold-build/gold/ld-new" -e lans_step patmos/controller.o patmos/policy.o -o patmos/lans.elf > patmos/link.log 2>&1
LINK_STATUS=$?
printf 'Controller PML exit status: %s; link exit status: %s\n' "$EXPORT_STATUS" "$LINK_STATUS"
test "$EXPORT_STATUS" -eq 0 && test "$LINK_STATUS" -eq 0
