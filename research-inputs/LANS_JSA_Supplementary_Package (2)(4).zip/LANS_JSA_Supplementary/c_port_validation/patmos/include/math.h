/* ABI declarations for compilation-only audit. No math implementation supplied. */
double sin(double); double cos(double); double tan(double);
double asin(double); double atan(double); double atan2(double,double);
double exp(double); double expm1(double); double pow(double,double);
double sqrt(double); double fabs(double); double fmax(double,double);
double trunc(double); double nearbyint(double); float tanhf(float);
#define isfinite(x) __builtin_isfinite(x)
#define isnan(x) __builtin_isnan(x)
#define INFINITY (__builtin_inff())
