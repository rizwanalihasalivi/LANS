#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PORT_PYTHON="${PORT_PYTHON:-python3}"
bash build.sh
for seed in 42 43 44; do
 "$PORT_PYTHON" validate.py --seed "$seed"
 "$PORT_PYTHON" closed_loop.py --seed "$seed"
done
"$PORT_PYTHON" edge_audit.py
gcc -std=c11 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math -ffp-contract=off src/sanitize_test.c -lm -o sanitize_test
ASAN_OPTIONS=detect_leaks=0 ./sanitize_test
"$PORT_PYTHON" summarize.py
