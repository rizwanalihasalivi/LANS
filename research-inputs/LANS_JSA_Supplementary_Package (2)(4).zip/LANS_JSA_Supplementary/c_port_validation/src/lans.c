/* Bounded host-C port of the frozen selected LANS decision path.
 * Research software: no hardware WCET or invariant-set certificate.
 * All state is caller-owned; no heap allocation in control functions.
 */
#include <math.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "params.h"
#define NREF 1001
#define NHIST 16
#define NCMD 22
#define NQUEUE 101
#define MAXTICK 10000000
#define DT .01
#define VX 25.
#define WB 2.6
typedef struct {int due,generated; double value;} Packet;
typedef struct Lans {
 double ref[NREF],z[5],P[25],history[4],variance[2],filtered[4],estimates[3];
 double position,last_position,last_actual,commands[NCMD];
 int initialized,nhistory,has_position,last_stamp,ncmd,latched;
 Packet pending[NQUEUE];int count,tick,last_generated,rejected;
 double last_output,arrived,accepted;
 int age;
} Lans;
size_t lans_size(void){return sizeof(Lans);}
static double clip(double x,double lo,double hi){return x<lo?lo:(x>hi?hi:x);}
static int finite_array(const double *a,int n){for(int i=0;i<n;i++)if(!isfinite(a[i]))return 0;return 1;}
int lans_init(Lans *c,const double *reference,int n){
 if(!c||!reference||n!=NREF||!finite_array(reference,n))return -1;
 memset(c,0,sizeof(*c));memcpy(c->ref,reference,sizeof(c->ref));
 double diag[5]={.0004,.0004,.25,.04,.0625};
 for(int i=0;i<5;i++)c->P[i*5+i]=diag[i];
 c->variance[0]=c->variance[1]=.0004;c->estimates[2]=1.;
 c->last_stamp=c->last_generated=-1;c->age=-1;return 0;
}
static int ix(double p,int lo,int hi){
 double q=trunc(p/(VX*DT));return q<lo?lo:(q>hi?hi:(int)q);
}
static double refy(const Lans*c,double p){return c->ref[ix(p,0,NREF-1)];}
static double heading(const Lans*c,double p){int i=ix(p,0,NREF-2);return atan2(c->ref[i+1]-c->ref[i],VX*DT);}
static double curvature(const Lans*c,double p){
 int i=ix(p,1,NREF-2);double d1=(c->ref[i+1]-c->ref[i-1])/(2*VX*DT);
 double d2=(c->ref[i+1]-2*c->ref[i]+c->ref[i-1])/((VX*DT)*(VX*DT));
 return d2/pow(1+d1*d1,1.5);
}
static int ekf(Lans*c,double y,double psi,double u,int measurement_float32){
 double measurement[2]={y,psi};
 if(c->nhistory==2)for(int i=0;i<2;i++){
  double d=measurement[i]-2*c->history[2+i]+c->history[i];
  double term=.1*d*d/6.;
  if(measurement_float32){float df=(float)((float)measurement[i]-(float)(2.f*(float)c->history[2+i]));df=(float)(df+(float)c->history[i]);term=(float)((float)((float)(.1f*df)*df)/6.f);}
  c->variance[i]=clip(.9*c->variance[i]+term,.0004,.0225);
 }
 if(c->nhistory==0){c->history[0]=y;c->history[1]=psi;c->nhistory=1;}
 else if(c->nhistory==1){c->history[2]=y;c->history[3]=psi;c->nhistory=2;}
 else {c->history[0]=c->history[2];c->history[1]=c->history[3];c->history[2]=y;c->history[3]=psi;}
 if(!c->initialized){c->z[0]=y;c->z[1]=psi;c->z[4]=1;c->initialized=1;return 0;}
 double z[5],F[25]={0},T[25]={0},prior[25]={0},G[10],I[25],U[25]={0},P[25]={0};
 memcpy(z,c->z,sizeof(z));double rate=VX*tan(u)/WB;
 for(int i=0;i<5;i++)F[i*5+i]=1.;
 F[1]=VX*cos(z[1])*DT;F[2]=DT;F[8]=DT;F[9]=rate*DT;
 z[0]+=(VX*sin(z[1])+z[2])*DT;z[1]+=(z[4]*rate+z[3])*DT;
 for(int i=0;i<5;i++)for(int j=0;j<5;j++)for(int k=0;k<5;k++)T[5*i+j]+=F[5*i+k]*c->P[5*k+j];
 for(int i=0;i<5;i++)for(int j=0;j<5;j++)for(int k=0;k<5;k++)prior[5*i+j]+=T[5*i+k]*F[5*j+k];
 double q[5]={1e-7,1e-7,.0016,.0004,1e-7};for(int i=0;i<5;i++)prior[6*i]+=q[i];
 double a=prior[0]+c->variance[0],b=prior[1],cc=prior[5],d=prior[6]+c->variance[1],det=a*d-b*cc;
 if(!isfinite(det)||det<=0)return -2;
 for(int i=0;i<5;i++){
  G[2*i]=(d*prior[i]-b*prior[5+i])/det;
  G[2*i+1]=(-cc*prior[i]+a*prior[5+i])/det;
 }
 double innovation[2]={y-z[0],psi-z[1]};
 for(int i=0;i<5;i++){
  z[i]+=G[2*i]*innovation[0]+G[2*i+1]*innovation[1];
  for(int j=0;j<5;j++)I[5*i+j]=(i==j?1.:0.)-(j<2?G[2*i+j]:0.);
 }
 for(int i=0;i<5;i++)for(int j=0;j<5;j++)for(int k=0;k<5;k++)U[5*i+j]+=I[5*i+k]*prior[5*k+j];
 for(int i=0;i<5;i++)for(int j=0;j<5;j++){
  for(int k=0;k<5;k++)P[5*i+j]+=U[5*i+k]*I[5*j+k];
  P[5*i+j]+=G[2*i]*c->variance[0]*G[2*j]+G[2*i+1]*c->variance[1]*G[2*j+1];
 }
 z[2]=clip(z[2],-1.5,1.5);z[3]=clip(z[3],-.6,.6);z[4]=clip(z[4],.5,1.5);
 if(!finite_array(z,5)||!finite_array(P,25))return -2;
 memcpy(c->z,z,sizeof(z));memcpy(c->P,P,sizeof(P));return 0;
}
/* History is a timestamped window, not an episode-growing array.
 * Consecutive new pose packets, pose age <=14 ticks, commands <=22.
 */
int lans_prepare(Lans*c,double position,const double*x,int stamp,int now,
 const double*hist,int hstart,int hn,const double*commands,int nc,int input_float32){
 if(!c||!x||!hist||!commands||!isfinite(position)||fabs(position)>1e7||
 !finite_array(x,4)||stamp<0||now<stamp||now>MAXTICK||now-stamp>14||
 hn<0||hn>NHIST||hstart<0||hstart>now||hn>now||hstart!=now-hn||nc<0||nc>NCMD||
 !finite_array(hist,hn)||!finite_array(commands,nc))return -1;
 if((stamp>0&&stamp-1<hstart)||(stamp<now&&stamp<hstart))return -1;
 if(c->has_position&&c->last_position==position)return 0;
 if(c->last_stamp>=0&&stamp>c->last_stamp&&stamp!=c->last_stamp+1)return -3;
 if(c->last_stamp>=0&&stamp<c->last_stamp)return -3;
 c->position=position;c->ncmd=nc;memcpy(c->commands,commands,nc*sizeof(double));
 c->last_actual=hn?hist[hn-1]:0.;
 if(c->last_stamp<0||stamp>c->last_stamp){
  double prev=stamp>0?hist[stamp-1-hstart]:0.;
  double my=refy(c,position)+x[0],mp=heading(c,position)+x[2];
  if(input_float32){my=(float)((float)refy(c,position)+(float)x[0]);mp=(float)((float)heading(c,position)+(float)x[2]);}
  int status=ekf(c,my,mp,prev,input_float32);if(status)return status;
  c->last_stamp=stamp;
 }
 double z[5];memcpy(z,c->z,sizeof(z));
 for(int j=0;j<14;j++){int tick=stamp+j;if(tick>=now)break;double u=hist[tick-hstart];
  z[0]+=(VX*sin(z[1])+z[2])*DT;z[1]+=(z[4]*VX*tan(u)/WB+z[3])*DT;
 }
 memcpy(c->estimates,z+2,3*sizeof(double));
 double ep=z[1]-heading(c,position);
 c->filtered[0]=z[0]-refy(c,position);c->filtered[1]=VX*sin(ep);c->filtered[2]=ep;
 c->filtered[3]=z[4]*VX*tan(c->last_actual)/WB-VX*curvature(c,position);
 c->last_position=position;c->has_position=1;return 0;
}
int lans_state(const Lans*c,double*out){
 if(!c||!out)return -1;
 memcpy(out,c->filtered,4*sizeof(double));memcpy(out+4,c->estimates,3*sizeof(double));
 memcpy(out+7,c->z,5*sizeof(double));memcpy(out+12,c->P,25*sizeof(double));
 memcpy(out+37,c->variance,2*sizeof(double));return 0;
}
static void predict(const Lans*c,const double*x,const double*commands,int n,double*out){
 double px=c->position,py=refy(c,px)+x[0],psi=heading(c,px)+x[2];
 for(int i=0;i<NCMD;i++){if(i>=n)break;double u=clip(commands[i],-.5,.5);
  px+=VX*cos(psi)*DT;py+=(VX*sin(psi)+c->estimates[0])*DT;
  double nominal=c->estimates[2]*VX*tan(u)/WB;
  psi+=(nominal+c->estimates[1])*DT;
  double ep=psi-heading(c,px);
  out[0]=py-refy(c,px);out[1]=VX*sin(ep);out[2]=ep;out[3]=nominal-VX*curvature(c,px);
 }
}
static double analytical(const Lans*c,const double*x){
 double actual=c->last_actual,commands[NCMD],future[4],position=c->position;
 const double*f=x;
 for(int i=0;i<NCMD;i++){if(i>=c->ncmd)break;
  double movement=clip(-expm1(-DT/.08)*(c->commands[i]-actual),-.7*DT,.7*DT);
  actual=clip(actual+movement,-.5,.5);commands[i]=actual;
 }
 if(c->ncmd){predict(c,x,commands,c->ncmd,future);f=future;position+=VX*DT*c->ncmd;}
 double ep=f[2]+asin(clip(c->estimates[0]/VX,-.5,.5));
 double feedback=-KGAIN[0]*f[0]-KGAIN[1]*ep;
 double desired=clip(atan((feedback+WB*curvature(c,position)-WB/VX*c->estimates[1])/c->estimates[2]),-.5,.5);
 return clip(desired+.5*(desired-actual),-.5,.5);
}
double lans_analytical(const Lans*c,const double*x){return analytical(c,x);}
static double quadratic(const double*x,const double*M,int n){
 double a[4]={0};for(int j=0;j<n;j++)for(int i=0;i<n;i++)a[j]+=x[i]*M[n*i+j];
 double r=0;for(int j=0;j<n;j++)r+=a[j]*x[j];return r;
}
static double value(const Lans*c,double u){
 double z[4];predict(c,c->filtered,&u,1,z);double v=quadratic(z,PMAT,4);return isfinite(v)?v:INFINITY;
}
static double gate_cost(const Lans*c,double u){
 double z[4];predict(c,c->filtered,&u,1,z);
 double e[2]={z[0],z[2]+asin(clip(c->estimates[0]/VX,-.5,.5))};
 return quadratic(e,SMAT,2)+10*u*u;
}
static int mailbox(Lans*c,double residual,double delay,int available){
 if(!isfinite(residual)||!isfinite(delay)||delay<0||delay>1000||c->tick>=MAXTICK)return -1;
 if(available){
  if(c->count>=NQUEUE)return -4;
  Packet p={c->tick+(int)nearbyint(delay/10.),c->tick,residual};
  int j=c->count;for(int t=0;t<NQUEUE;t++){
   if(j==0||c->pending[j-1].due<=p.due)break;
   c->pending[j]=c->pending[j-1];j--;
  }c->pending[j]=p;c->count++;
 }
 for(int t=0;t<NQUEUE;t++){
  if(!c->count||c->pending[0].due>c->tick)break;
  Packet p=c->pending[0];c->count--;
  for(int j=0;j<NQUEUE-1;j++){if(j>=c->count)break;c->pending[j]=c->pending[j+1];}
  if(available&&p.generated>c->last_generated){c->last_generated=p.generated;c->last_output=p.value;}else c->rejected++;
 }
 c->age=c->last_generated<0?-1:c->tick-c->last_generated;
 c->arrived=c->last_generated>=0&&c->age*DT*1000<=200?c->last_output*exp(-c->age*DT*1000/100.):0.;
 c->tick++;return 0;
}
int lans_queue(const Lans*c,double*out){for(int i=0;i<c->count;i++)out[i]=c->pending[i].value;return c->count;}
/* Bounded Brent minimization corresponding to scipy.optimize's bounded method.
 * See THIRD_PARTY_LICENSES.txt for the SciPy BSD license. */
static double minimize(const Lans*c,int*success,int*nfev){
 const double se=sqrt(2.2e-16),gold=.5*(3.-sqrt(5.));
 double a=-.5,b=.5,fulc=a+gold*(b-a),nfc=fulc,xf=fulc,rat=0,e=0,x=xf;
 double fx=value(c,x),ffulc=fx,fnfc=fx,fu=INFINITY,xm=.5*(a+b),tol1=se*fabs(xf)+1e-7/3.,tol2=2*tol1;
 int num=1,flag=0;
 for(int iter=0;iter<499;iter++){
  if(!(fabs(xf-xm)>(tol2-.5*(b-a))))break;
  int golden=1;
  if(fabs(e)>tol1){
   golden=0;double r=(xf-nfc)*(fx-ffulc),q=(xf-fulc)*(fx-fnfc),p=(xf-fulc)*q-(xf-nfc)*r;
   q=2*(q-r);if(q>0)p=-p;q=fabs(q);r=e;e=rat;
   if(fabs(p)<fabs(.5*q*r)&&p>q*(a-xf)&&p<q*(b-xf)){
    rat=p/q;x=xf+rat;if(x-a<tol2||b-x<tol2)rat=tol1*(xm-xf<0?-1:1);
   }else golden=1;
  }
  if(golden){e=xf>=xm?a-xf:b-xf;rat=gold*e;}
  x=xf+(rat<0?-1:1)*fmax(fabs(rat),tol1);fu=value(c,x);num++;
  if(fu<=fx){if(x>=xf)a=xf;else b=xf;fulc=nfc;ffulc=fnfc;nfc=xf;fnfc=fx;xf=x;fx=fu;}
  else {if(x<xf)a=x;else b=x;
   if(fu<=fnfc||nfc==xf){fulc=nfc;ffulc=fnfc;nfc=x;fnfc=fu;}
   else if(fu<=ffulc||fulc==xf||fulc==nfc){fulc=x;ffulc=fu;}
  }
  xm=.5*(a+b);tol1=se*fabs(xf)+1e-7/3.;tol2=2*tol1;
  if(num>=500){flag=1;break;}
 }
 if(isnan(xf)||isnan(fx)||isnan(fu))flag=2;
 *success=flag==0;*nfev=num;return xf;
}
/* out: u,base,arrived,accepted,Vcandidate,Vfallback,Vapplied,
 * fallback,recovery,unresolved,rejected,envelope,latched,age,queue,nfev,predicted[4] */
int lans_step(Lans*c,double residual,double delay,int available,double*out){
 if(!c||!out||!c->has_position||!finite_array(c->filtered,4))return -1;
 int rc=mailbox(c,residual,delay,available);if(rc)return rc;
 double base=analytical(c,c->filtered),candidate=clip(base+c->arrived,-.5,.5);
 int rejected=c->arrived!=0&&gate_cost(c,candidate)>=gate_cost(c,base);
 c->accepted=rejected?0.:c->arrived;
 double command=clip(base+c->accepted,-.5,.5),states[4];
 predict(c,c->filtered,&command,1,states);
 int risk=fabs(states[0])>.30||fabs(states[2])>.06;
 if(risk)c->latched=1;
 else if(fabs(c->filtered[0])<.10&&fabs(c->filtered[2])<.02)c->latched=0;
 double vc=value(c,command),vb=value(c,base);
 int fallback=vc>10.2231||c->latched,recovery=0,nfev=0;
 if(fallback){
  command=base;
  if(vb>10.2231){
   recovery=1;int success;double opt=minimize(c,&success,&nfev);
   double cand[5]={base,-.5,.5,0.,opt};double best=value(c,base);
   for(int i=1;i<5;i++){if(i==4&&!success)break;double v=value(c,cand[i]);if(v<best){best=v;command=cand[i];}}
  }
 }
 double va=value(c,command);predict(c,c->filtered,&command,1,states);
 double vals[16]={command,base,c->arrived,c->accepted,vc,vb,va,fallback,recovery,!isfinite(va)||va>10.2231,rejected,risk,c->latched,c->age,c->count,nfev};
 memcpy(out,vals,sizeof(vals));memcpy(out+16,states,sizeof(states));return 0;
}
