#ifndef LANS_PORT_H
#define LANS_PORT_H
#include <stddef.h>
typedef struct Lans Lans;
/* Caller provides suitably aligned storage of lans_size() bytes.
 * init requires 1001 finite reference samples at dx=0.25 m.
 * See README.md for input, floating-point and scope contracts. */
size_t lans_size(void);
int lans_init(Lans*,const double*,int);
int lans_prepare(Lans*,double,const double*,int,int,const double*,int,int,const double*,int,int);
int lans_state(const Lans*,double*); /* output length 39 */
double lans_analytical(const Lans*,const double*); /* input length 4 */
int lans_step(Lans*,double,double,int,double*); /* output length 20 */
int lans_queue(const Lans*,double*); /* capacity 101 */
int lans_policy(int,const float*,float*); /* policy index 0..2; input length 37 */
#endif
