#include <math.h>
#include "policies.h"
/* normalized deterministic action; no sampling/value-network evaluation */
int lans_policy(int policy,const float *obs,float *action){
 if(policy<0||policy>2||!obs||!action)return -1;
 float x[37],h1[64],h2[64];
 for(int i=0;i<37;i++){
  if(!isfinite(obs[i]))return -1;
  double a=((double)obs[i]-MEAN[policy][i])/sqrt(VAR[policy][i]+1e-8);
  x[i]=(float)(a < -10 ? -10 : a>10?10:a);
 }
 for(int i=0;i<64;i++){
  float a=0;for(int j=0;j<37;j++)a+=W1[policy][i*37+j]*x[j];
  h1[i]=tanhf(a+B1[policy][i]);
 }
 for(int i=0;i<64;i++){
  float a=0;for(int j=0;j<64;j++)a+=W2[policy][i*64+j]*h1[j];
  h2[i]=tanhf(a+B2[policy][i]);
 }
 float a=0;for(int j=0;j<64;j++)a+=W3[policy][j]*h2[j];
 a+=B3[policy][0];*action=a < -1 ? -1 : a>1?1:a;
 return isfinite(*action)?0:-2;
}
