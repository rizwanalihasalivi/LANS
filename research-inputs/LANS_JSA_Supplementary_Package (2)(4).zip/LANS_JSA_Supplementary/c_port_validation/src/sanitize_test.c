/* Native address/undefined-behavior checks of queue limits and input contracts. */
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include "lans.c"
int main(void){
 Lans c; double reference[NREF]={0},x[4]={0},h[NHIST]={0},commands[NCMD]={0},out[20];
 assert(lans_init(&c,reference,NREF)==0);
 assert(lans_prepare(&c,0,x,0,0,h,0,0,commands,0,0)==0);
 for(int i=0;i<20000;i++){
  double delay=i<1000?1000:(double)((i*37)%1001);
  assert(lans_step(&c,.01,delay,1,out)==0);
  assert(c.count<=100);assert(isfinite(out[0]));
 }
 assert(lans_prepare(&c,1,x,0,0,h,INT_MAX,16,commands,0,0)<0);
 assert(lans_step(&c,NAN,0,1,out)<0);
 puts("PASS: 20000 queue/control steps, maximum-delay boundary and overflow guard.");
 return 0;
}
