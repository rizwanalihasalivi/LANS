from pathlib import Path
import csv,json,hashlib,re,ctypes,platform,subprocess
R=Path(__file__).resolve().parent
def read(pattern):
 rows=[]
 for p in sorted((R/'results').glob(pattern)):
  if p.stem.rsplit('_',1)[-1] not in ['42','43','44']:continue
  rows.extend(csv.DictReader(p.open()))
 return rows
def merged(name,rows):
 with (R/'results'/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
shadow=read('shadow_*.csv');paired=read('paired_*.csv');episodes=read('closed_loop_*.csv')
assert len(shadow)==len(paired)==63 and len(episodes)==126
for name,rows in [('shadow_all.csv',shadow),('paired_all.csv',paired),('closed_loop_all.csv',episodes)]:merged(name,rows)
edge=json.loads((R/'results/edge_summary.json').read_text())
missing=sorted(set(re.findall("undefined reference to '([^']+)'",(R/'patmos/link.log').read_text())))
lib=ctypes.CDLL(str(R/'liblans.so'));lib.lans_size.restype=ctypes.c_size_t
summary={
 'scope':'Host-C numerical validation of selected controller and deterministic actors; Python observation assembly, simulator and hardware I/O are outside the C port.',
 'same_input':{'cases':63,'steps':sum(int(x['steps']) for x in shadow),
 'decision_flag_mismatches':sum(int(x['boolean_mismatches']) for x in shadow),
 'max_steering_difference_rad':max(float(x['max_abs_command']) for x in shadow),
 'max_policy_action_difference':max(float(x['max_abs_policy']) for x in shadow),
 'max_observer_state_difference':max(float(x['max_abs_filtered']) for x in shadow),
 'max_pending_queue':max(int(x['max_queue']) for x in shadow)},
 'closed_loop':{'pairs':63,'episodes':126,'steps':sum(int(x['steps']) for x in episodes),
 'survival_agreements':sum(x['same_survival']=='True' for x in paired),
 'length_agreements':sum(x['same_length']=='True' for x in paired),
 'python_survivals':sum(x['backend']=='Python' and x['survived']=='True' for x in episodes),
 'c_survivals':sum(x['backend']=='C' and x['survived']=='True' for x in episodes),
 'max_abs_rmse_difference_m':max(float(x['abs_rmse_difference_m']) for x in paired),
 'max_trajectory_difference_m':max(float(x['max_abs_trajectory_difference_m']) for x in paired),
 'max_steering_difference_rad':max(float(x['max_abs_command_difference_rad']) for x in paired),
 'max_fallback_count_difference':max(abs(int(x['fallback_count_difference'])) for x in paired),
 'max_recovery_count_difference':max(abs(int(x['recovery_count_difference'])) for x in paired)},
 'recovery_and_contracts':edge,
 'sanitizers':{'steps':20000,'result':(R/'results/sanitizers.txt').read_text().strip()},
 'storage':{'controller_state_bytes_host':lib.lans_size(),'neural_parameters_per_policy':6657},
 'target':{'controller_object_generated':(R/'patmos/controller.o').exists(),'policy_object_generated':(R/'patmos/policy.o').exists(),
 'linked_lans_executable':False,'controller_pml_export':'compiler assertion','undefined_symbols':missing,'wcet_certificate':False,'physical_latency_measured':False},
 'environment':{'platform':platform.platform(),'compiler':subprocess.check_output(['gcc','--version'],text=True).splitlines()[0]}
}
assert summary['same_input']['decision_flag_mismatches']==0
assert summary['closed_loop']['survival_agreements']==63
assert edge['flag_mismatches']==0 and edge['contract_passed']==edge['contract_tests']
(R/'results/summary.json').write_text(json.dumps(summary,indent=2))
hashes={}
for folder in ['src','frozen','patmos']:
 for p in (R/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:hashes[str(p.relative_to(R))]=hashlib.sha256(p.read_bytes()).hexdigest()
hashes['liblans.so']=hashlib.sha256((R/'liblans.so').read_bytes()).hexdigest()
(R/'results/artifact_hashes.json').write_text(json.dumps(hashes,indent=2))
print(json.dumps(summary,indent=2))
