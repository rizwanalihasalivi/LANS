from pathlib import Path
import os,sys,json,csv,pickle,time
import numpy as np
import torch
ROOT=Path(__file__).resolve().parent
REF=ROOT/'frozen/reference'
os.chdir(REF);sys.path.insert(0,str(REF));sys.path.insert(0,str(ROOT))
from scripts.paper_env import BenchEnv
from scripts.stress_env import PROFILES
from stable_baselines3 import PPO
from bridge import Port
torch.set_num_threads(1);torch.set_num_interop_threads(1)
MODELS={}
for seed in [42,43,44]:
 model=PPO.load(REF/f'robustness_models/ppo_seed{seed}.zip',device='cpu')
 norm=pickle.load(open(REF/f'robustness_models/ppo_seed{seed}_norm.pkl','rb'))
 norm.training=False;norm.norm_reward=False
 MODELS[seed]=(model,norm)
def action(seed,obs):
 model,norm=MODELS[seed];return model.predict(norm.normalize_obs(obs[None,:]),deterministic=True)[0][0]
def shadow(seed=42,profile='nominal',path='dlc',eval_seed=3200,steps=1000):
 e=BenchEnv(profile=profile,path=path,heldout=True);p=Port(e);c=e.framework_controller
 old=c.prepare;orig_step=c.step
 errors=dict(filtered=0.,estimates=0.,covariance=0.,command=0.,value=0.,policy=0.,predicted=0.,queue=0.)
 counts=dict(steps=0,fallback=0,recovery=0,boolean_mismatches=0,max_queue=0,max_optimizer_evals=0)
 def prepare(x,predictor):
  old(x,predictor);s=p.prepare(x,predictor)
  errors['filtered']=max(errors['filtered'],float(np.max(abs(s[:4]-c.filtered))))
  errors['estimates']=max(errors['estimates'],float(np.max(abs(s[4:7]-c.estimates))))
  errors['covariance']=max(errors['covariance'],float(np.max(abs(s[12:37]-c.filter.P.ravel()))))
 def step(*args,**kw):
  u,info=orig_step(*args,**kw)
  v=p.step(kw['ppo_residual'],kw['delay_ms'],c.remote.available)
  errors['command']=max(errors['command'],abs(u-v[0]))
  errors['value']=max(errors['value'],abs(info['V_applied']-v[6]))
  errors['predicted']=max(errors['predicted'],float(np.max(abs(info['predicted_state']-v[16:20]))))
  flags=[info['fallback_used'],info['recovery_used'],info['recovery_unresolved'],info['residual_rejected'],info['envelope_risk'],info['recovery_latched']]
  counts['boolean_mismatches']+=sum(int(bool(a)!=bool(b)) for a,b in zip(flags,v[7:13]))
  q=p.queue();qp=np.array(c.remote.buffer)
  if len(q)!=len(qp):counts['boolean_mismatches']+=1
  elif len(q):errors['queue']=max(errors['queue'],float(np.max(abs(q-qp))))
  counts['steps']+=1;counts['fallback']+=info['fallback_used'];counts['recovery']+=info['recovery_used']
  counts['max_queue']=max(counts['max_queue'],int(v[14]));counts['max_optimizer_evals']=max(counts['max_optimizer_evals'],int(v[15]))
  return u,info
 c.prepare=prepare;c.step=step
 obs,_=e.reset(seed=eval_seed)
 for t in range(steps):
  a=action(seed,obs);pa=p.policy(seed,obs);errors['policy']=max(errors['policy'],abs(float(a[0])-pa))
  obs,_,term,trunc,info=e.step(a)
  if term or trunc:break
 e.close()
 return dict(seed=seed,profile=profile,path=path,eval_seed=eval_seed,**counts,**{'max_abs_'+k:v for k,v in errors.items()})
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');ap.add_argument('--seed',type=int);a=ap.parse_args()
 rows=[]
 for seed in ([a.seed] if a.seed else ([42] if a.quick else [42,43,44])):
  for path in (['dlc'] if a.quick else ['dlc','sine_noise_test','chirp_noise_test']):
   for profile in (['nominal','combined','full_command_delay'] if a.quick else list(PROFILES)):
    row=shadow(seed,profile,path,steps=50 if a.quick else 1000)
    rows.append(row);print(json.dumps(row),flush=True)
    with (ROOT/('results/shadow_'+str(a.seed)+'.csv' if a.seed else 'results/shadow.csv')).open('w',newline='') as f:
     w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
