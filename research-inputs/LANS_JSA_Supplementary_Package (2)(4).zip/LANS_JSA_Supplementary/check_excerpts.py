from pathlib import Path
import ast,heapq,hashlib,json,csv,types
from collections import deque
import numpy as np
R=Path(__file__).resolve().parent
src=R/'audited_code/controllers/split_controller.py'
tree=ast.parse(src.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ResidualMailbox')
ns={'np':np,'heapq':heapq,'deque':deque};exec(compile(ast.Module(body=[cls],type_ignores=[]),str(src),'exec'),ns);Original=ns['ResidualMailbox']
ex={'np':np,'heapq':heapq};exec((R/'code_excerpts/mailbox.py').read_text(),ex)
a=Original();b=Original();b.push=types.MethodType(ex['push'],b)
rng=np.random.default_rng(20261006)
for k in range(3000):
 avail=not(200<=k%600<500);a.available=b.available=avail
 u=float(rng.uniform(-.01,.01));delay=float(rng.choice([0,10,80,200,210,500,1000]))
 assert a.push(u,delay)==b.push(u,delay)
 for attr in ['pending','last_generated','last_output','last_age_steps','rejected','tick']:assert getattr(a,attr)==getattr(b,attr)
 assert list(a.buffer)==list(b.buffer)
# Compare original actuator arithmetic against the published extract under equal released commands.
ac={'np':np};exec((R/'code_excerpts/actuator.py').read_text(),ac)
class Channel:
 def __init__(self):self.calls=[]
 def push(self,u,delay):self.calls.append((u,delay));return u
from types import SimpleNamespace
for tau in [0.,.04,.08,.12]:
 s=SimpleNamespace(settings={'tau':tau,'rate':.7,'command_ms':200.},dt=.01,actual_delta=0.,executed_history=[],actuator_channel=Channel())
 expected=0.
 for command in rng.uniform(-1,1,1000):
  fraction=1. if tau==0 else -np.expm1(-s.dt/tau)
  movement=np.clip(fraction*(command-expected),-.7*s.dt,.7*s.dt)
  expected=float(np.clip(expected+movement,-.5,.5))
  ac['actuator_update'](s,command);assert s.actual_delta==expected
 assert all(delay==200. for _,delay in s.actuator_channel.calls)
manifest=[]
for p in [src,R/'audited_code/scripts/stress_env.py',*list((R/'code_excerpts').glob('*.py'))]:manifest.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'CODE_EXCERPT_VERIFICATION.json').write_text(json.dumps({'mailbox_comparisons':3000,'actuator_comparisons':4000,'result':'pass','scope':'Equivalence of reformatted extracts, not a whole-system safety test. Actuator extraction excludes subsequent gain-step and plant propagation.','sources':manifest},indent=2))
refs=json.loads((R/'references.json').read_text());p=(R/'paper.txt').read_text()
import re
cites={int(x) for x in re.findall(r'\[(\d+)\]',p)}
assert cites==set(range(1,len(refs)+1)),cites
assert len(list(csv.DictReader((R/'REFERENCE_AUDIT.csv').open())))==32
print('PASS: 3000 mailbox cases, 4000 actuator cases, 31 cited references, 32 audit entries')
