def actuator_update(self, command):
    cfg, h = self.settings, self.dt
    target = self.actuator_channel.push(
        command, cfg['command_ms'])
    tau, rate = cfg['tau'], cfg['rate']
    beta = 1. if tau == 0 else -np.expm1(-h/tau)
    delta = self.actual_delta
    move = np.clip(beta*(target-delta),
                   -rate*h, rate*h)
    self.actual_delta = float(
        np.clip(delta+move, -.5, .5))
    self.executed_history.append(self.actual_delta)
