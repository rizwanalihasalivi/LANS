def push(self, command, delay_ms):
    if (not np.isfinite(command) or
        not np.isfinite(delay_ms) or delay_ms < 0):
        raise ValueError('Invalid residual or delay')
    k = self.tick
    if self.available:
        due = k + round(delay_ms / (1000*self.dt))
        heapq.heappush(self.pending,
                      (due, k, float(command)))
    while self.pending and self.pending[0][0] <= k:
        _, stamp, value = heapq.heappop(self.pending)
        newer = (self.last_generated is None or
                 stamp > self.last_generated)
        if self.available and newer:
            self.last_generated = stamp
            self.last_output = value
        else:
            self.rejected += 1
    self.last_age_steps = (-1 if
        self.last_generated is None else
        k - self.last_generated)
    age = 1000*self.dt*self.last_age_steps
    valid = (self.last_generated is not None and
             age <= self.ttl_ms)
    out = (self.last_output*np.exp(-age/100.)
           if valid else 0.)
    self.buffer.clear()
    self.buffer.extend(p[2] for p in
                       sorted(self.pending))
    self.tick += 1
    return float(out)
