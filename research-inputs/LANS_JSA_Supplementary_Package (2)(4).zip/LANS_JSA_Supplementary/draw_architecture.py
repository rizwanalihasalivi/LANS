from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyArrowPatch
import fitz
r=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':11})
fig,ax=plt.subplots(figsize=(15,6.4));ax.set_xlim(0,15.6);ax.set_ylim(-.9,6);ax.axis('off')
def box(x,y,w,h,t):
 ax.add_patch(Rectangle((x,y),w,h,fill=False,lw=1.3));ax.text(x+w/2,y+h/2,t,ha='center',va='center')
def arrow(points,label=None,xy=None):
 for a,b in zip(points[:-2],points[1:-1]):ax.plot([a[0],b[0]],[a[1],b[1]],color='black',lw=1)
 ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle='-|>',mutation_scale=10,color='black',lw=1))
 if label:ax.text(*xy,label,fontsize=9,ha='center')
box(.5,2.7,2.5,1.3,'Timestamped pose\nEKF + tracking errors')
box(4.1,4.75,3,.95,'LQR-based analytical\narrival feedback')
box(4.1,2.75,2.3,1.05,'Observation\nbuilder (37)')
box(7.05,2.75,1.25,1.05,'PPO')
box(9,2.65,2.6,1.25,'Remote mailbox\nNewest timestamp\nAge gain + expiry')
box(4.1,1.1,2.3,.7,'Clock / packet\ntimestamps')
box(12.35,2.1,2.6,3.6,'Fusion layer\n\nCost gate\n+\nRuntime recovery')
box(9,-.35,3.2,1.05,'Physical command queue\nActuator lag / rate / saturation')
box(4.1,-.35,3.25,1.05,'Kinematic vehicle plant\nGain + disturbances')
box(.5,-.35,2.5,1.05,'Noisy pose\nSensor transport')
ax.text(1.75,5.55,'Reference path',ha='center');arrow([(1.75,5.35),(1.75,4)])
arrow([(3,3.25),(3.6,3.25),(3.6,5.23),(4.1,5.23)])
arrow([(3,3.25),(4.1,3.25)],r'$\hat x_k$',(3.55,3.39))
arrow([(7.1,5.23),(12.35,5.23)],r'$\tilde b_k$',(9.6,5.39))
arrow([(6.4,3.25),(7.05,3.25)],r'$o_k$',(6.72,3.39))
arrow([(8.3,3.25),(9,3.25)],r'$r_k$',(8.65,3.39))
arrow([(11.6,3.25),(12.35,3.25)],r'$\bar r_k$',(11.98,3.39))
arrow([(6.4,1.45),(10.3,1.45),(10.3,2.65)],'Generation age; expiry 200 ms',(8.65,1.6))
arrow([(14.95,3.1),(15.25,3.1),(15.25,.17),(12.2,.17)],r'$u_k$',(14.15,.32))
arrow([(9,.17),(7.35,.17)],r'$\delta_{k+1}$',(8.18,.32))
arrow([(4.1,.17),(3,.17)],r'$Y,\psi$',(3.55,.32))
arrow([(1.75,.7),(1.75,2.7)],'Stamped pose',(1,1.5))
ax.text(9.6,.9,'Every selected command, including fallback, uses this actuator path.',ha='center',fontsize=9)
ax.text(.5,-.7,'Known longitudinal position and applied-steering history feed the observer and arrival predictor.',fontsize=9)
fig.tight_layout(pad=.2)
for ext in ['pdf','svg']:fig.savefig(r/'figures'/('fig01_architecture.'+ext),bbox_inches='tight',pad_inches=.03)
with fitz.open(r/'figures/fig01_architecture.pdf') as p:p[0].get_pixmap(matrix=fitz.Matrix(3,3)).save(r/'figures/fig01_architecture.png')
