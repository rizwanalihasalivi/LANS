from pathlib import Path
import csv,json,hashlib
from datetime import datetime,timezone,timedelta
import numpy as np
import pandas as pd
root=Path(__file__).resolve().parent
with (root/'raw/energy_session.csv').open(encoding='cp1252') as f:
 rows=list(csv.reader(f))
h=rows[0]; pi=h.index('CPU Package Power [W]'); valid=[]; rejected=[]
for line,r in enumerate(rows[1:],2):
 try:
  stamp=datetime.strptime(r[0]+' '+r[1],'%d.%m.%Y %H:%M:%S.%f').replace(tzinfo=timezone(timedelta(hours=8)))
  p=float(r[pi]); assert np.isfinite(p) and p>=0
  valid.append((int(stamp.timestamp()*1000)*1000000,p))
 except (ValueError,IndexError,AssertionError): rejected.append(line)
ns=np.array([v[0] for v in valid],dtype=np.int64); origin=int(ns[0]); t=(ns-origin)/1e9; power=np.array([v[1] for v in valid]); assert np.all(np.diff(t)>0)
log=pd.read_csv(root/'raw/run_log.csv'); assert len(log)==36 and log.status.eq('complete').all()
assert not log.duplicated(['run_id','phase']).any()
def integrate(a,b):
 assert t[0]<=a<b<=t[-1], 'Uncovered interval'
 mask=(t>a)&(t<b); xx=np.r_[a,t[mask],b]; yy=np.interp(xx,t,power)
 energy=float(np.sum(np.diff(xx)*(yy[:-1]+yy[1:])/2))
 left=max(0,np.searchsorted(t,a,side='right')-1);right=min(len(t)-1,np.searchsorted(t,b))
 return energy,energy/(b-a),int(mask.sum()),float(np.diff(t[left:right+1]).max())
out=[]
for r in log.to_dict('records'):
 a=(int(r['start_unix_ns'])-origin)/1e9;b=(int(r['end_unix_ns'])-origin)/1e9
 e,w,n,g=integrate(a,b)
 r.update(wall_duration_s=b-a,cpu_package_energy_j=e,cpu_package_mean_w=w,interior_samples=n,max_bracketing_gap_s=g,wall_minus_monotonic_s=b-a-r['duration_s'])
 out.append(r)
ph=pd.DataFrame(out);ph.to_csv(root/'phase_energy.csv',index=False)
work=[]
for run,d in ph.groupby('run_id',sort=False):
 assert set(d.phase)=={'idle_before','warmup','workload','idle_after'}
 row=d[d.phase=='workload'].iloc[0].to_dict()
 before=float(d[d.phase=='idle_before'].cpu_package_mean_w.iloc[0]);after=float(d[d.phase=='idle_after'].cpu_package_mean_w.iloc[0]);base=(before+after)/2
 row.update(idle_before_w=before,idle_after_w=after,nearby_idle_mean_w=base,baseline_adjusted_energy_j=row['cpu_package_energy_j']-base*row['wall_duration_s'],cpu_package_mj_per_step=1000*row['cpu_package_energy_j']/row['steps'],achieved_steps_per_s=row['steps']/row['duration_s'],scheduling_miss_fraction=row['missed_deadlines']/row['steps'])
 work.append(row)
w=pd.DataFrame(work);w.to_csv(root/'workload_energy.csv',index=False)
metrics=['cpu_package_mean_w','cpu_package_energy_j','baseline_adjusted_energy_j','cpu_package_mj_per_step','nearby_idle_mean_w','achieved_steps_per_s','scheduling_miss_fraction']
s=w.groupby('method')[metrics].agg(['mean','std','min','max']);s.columns=['_'.join(c) for c in s.columns];s.insert(0,'repeats',w.groupby('method').size());s.to_csv(root/'energy_summary.csv')
pd.DataFrame({'timestamp_unix_ns':ns,'cpu_package_power_w':power}).to_csv(root/'power_samples_clean.csv',index=False)
qc={'valid_power_samples':len(t),'excluded_nondata_line_numbers':rejected,'median_sampling_s':float(np.median(np.diff(t))),'maximum_sampling_gap_s':float(np.diff(t).max()),'gaps_over_3_seconds':int((np.diff(t)>3).sum()),'phases':len(ph),'workloads':len(w),'all_intervals_covered':True,'maximum_abs_wall_minus_monotonic_s':float(ph.wall_minus_monotonic_s.abs().max()),'timezone_assumption':'HWiNFO local clock interpreted as UTC+08:00, matching runner ISO timestamps; no independent clock synchronization verification','source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'raw').iterdir()}}
(root/'quality_checks.json').write_text(json.dumps(qc,indent=2))
print(json.dumps(qc,indent=2));print(s[['cpu_package_mean_w_mean','cpu_package_mean_w_std','cpu_package_energy_j_mean','baseline_adjusted_energy_j_mean']].to_string());print(w[['run_id','idle_before_w','idle_after_w','max_bracketing_gap_s','episodes','scheduling_miss_fraction']].to_string(index=False))
