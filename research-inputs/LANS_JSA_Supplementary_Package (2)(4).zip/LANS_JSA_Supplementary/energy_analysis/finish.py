from pathlib import Path
import pandas as pd,numpy as np,json
r=Path(__file__).resolve().parent
w=pd.read_csv(r/'workload_energy.csv');p=pd.read_csv(r/'power_samples_clean.csv');ph=pd.read_csv(r/'phase_energy.csv')
gaps=[]
for i in range(1,len(p)):
 a=int(p.timestamp_unix_ns.iloc[i-1]);b=int(p.timestamp_unix_ns.iloc[i]);dt=(b-a)/1e9
 if dt>3:
  overlap=ph[(ph.start_unix_ns<b)&(ph.end_unix_ns>a)]
  gaps.append(dict(start_unix_ns=a,end_unix_ns=b,gap_s=dt,overlapping_phases=';'.join(overlap.run_id+':'+overlap.phase)))
pd.DataFrame(gaps).to_csv(r/'sampling_gaps.csv',index=False)
# Alternate endpoint holds quantify interpolation sensitivity, not a confidence bound.
sens=[]
ns=p.timestamp_unix_ns.to_numpy(dtype=np.int64);pw=p.cpu_package_power_w.to_numpy();origin=int(ns[0]);t=(ns-origin)/1e9
for x in w.to_dict('records'):
 a=(int(x['start_unix_ns'])-origin)/1e9;b=(int(x['end_unix_ns'])-origin)/1e9
 lengths=np.maximum(0,np.minimum(t[1:],b)-np.maximum(t[:-1],a))
 sens.append(dict(run_id=x['run_id'],linear_j=x['cpu_package_energy_j'],left_hold_j=float(lengths@pw[:-1]),right_hold_j=float(lengths@pw[1:])))
pd.DataFrame(sens).to_csv(r/'integration_sensitivity.csv',index=False)
s=pd.read_csv(r/'energy_summary.csv')
lines=['# Windows CPU-package energy measurement report','',
'Nine workload runs completed: three methods × three repeats, approximately 90 s each, with 30 s idle before, 15 s warm-up and 30 s idle after. All 36 phases are covered by the telemetry recording. This is a single-session pilot, not a definitive energy-efficiency benchmark.','',
'## Results (mean ± sample standard deviation across 3 runs)','',
'| Method | Package power (W) | Package energy per run (J) | Nearby-idle adjusted energy (J) |',
'|---|---:|---:|---:|']
labels={'full':'LANS','zero':'LANS with residual disabled (not LQR alone)','mpc':'MPC'}
for x in s.to_dict('records'):
 lines.append(f"| {labels[x['method']]} | {x['cpu_package_mean_w_mean']:.3f} ± {x['cpu_package_mean_w_std']:.3f} | {x['cpu_package_energy_j_mean']:.2f} ± {x['cpu_package_energy_j_std']:.2f} | {x['baseline_adjusted_energy_j_mean']:.2f} ± {x['baseline_adjusted_energy_j_std']:.2f} |")
lines+=['','## Interpretation and limitations','',
'- LANS has higher mean measured CPU-package power than MPC in this session. No energy-saving claim is supported.',
'- 754 valid samples; median interval 2.000 s; six gaps exceed 3 s, maximum 14.002 s. See sampling_gaps.csv. Missing intervals were linearly interpolated, not measured. This can miss transient power peaks.',
'- Idle power varies substantially between phases (approximately 4.05–10.32 W for the bracketing phases). Nearby-idle subtraction is only an estimate and can be negative; negative values have not been clipped. Background processes, thermal changes and scheduling may confound differences; their cause is not established.',
'- CPU Package Power is hardware-reported package telemetry, not an external calibrated wall-power measurement. It excludes other laptop components and does not measure vehicle energy.',
'- Scope includes the observer, controller, simulated plant, reward/observation construction, episode resets, pacing and background CPU activity. It is not inference-only energy.',
'- Full and zero runs each reset 19 episodes; MPC resets 8–9. Workloads therefore do not replay identical state sequences. This file does not contain tracking trajectories or termination reasons; these counts cannot establish a survival comparison.',
'- The runner reports about 36–37% scheduling deadline misses despite roughly 100 steps/s. These count pacing lateness/catch-up and are not isolated controller inference times or a hard-real-time guarantee.',
'- Only one model seed (42), one evaluation seed (3400), DLC combined profile and one Windows laptop session were measured. The three repeats are not three independently trained policies.',
'- HWiNFO local timestamps are assumed to share the runner clock at UTC+08:00. Full interval coverage and wall/monotonic agreement within 2.3 ms support alignment, but no independent sensor clock calibration exists.',
'', '## Reproduction','',
'Run `python analyze.py` then `python finish.py` with Python, numpy and pandas. Raw files are preserved in raw/. SHA-256 hashes are in quality_checks.json. Integrate sampled power using piecewise-linear interpolation and trapezoids at exact Unix-nanosecond run boundaries. Divide Joules by wall duration for weighted Watts. Idle baseline is the arithmetic mean of the time-weighted before/after idle Watts. Net energy subtracts this baseline times workload wall duration. Summary standard deviations use ddof=1. integration_sensitivity.csv also uses left/right endpoint holds; their spread is not an uncertainty bound.',
'', '## Suggested paper wording','',
'On the Windows laptop, CPU-package telemetry was recorded during a 100-Hz-paced controller-in-loop simulation workload. Across three 90-s repetitions per method, LANS, residual-disabled LANS and MPC consumed mean package powers of 8.345, 7.281 and 6.180 W, respectively. These exploratory measurements include simulation and background execution, exhibit variable idle power and telemetry gaps, and do not establish controller-only energy efficiency or whole-system energy consumption.',
'', '## Remaining evidence','',
'- Energy: exploratory CPU-package measurements now available; clean repeat measurements are needed for a strong comparative energy claim. Keep the laptop plugged in with unchanged power mode, close unrelated applications, avoid interacting during collection, and record continuously with the same settings for all methods. Check gaps and idle consistency before interpreting rankings.',
'- Physical sensor-to-actuator latency remains unavailable without synchronized physical sensor and actuator logs. Simulation timing cannot replace it.',
'- Formal safety for the complete delayed, saturated hybrid controller is not established. Existing reduced nominal analysis must retain its assumptions.',
'- Independently trained short-budget PPO pilots exist but failed; a competent standalone PPO baseline and manuscript/reviewer audit remain unresolved. These energy measurements do not resolve them.']
(r/'REPORT.md').write_text('\n'.join(lines)+'\n')
print(s[['method','cpu_package_energy_j_std','baseline_adjusted_energy_j_std']].to_string(index=False));print(pd.DataFrame(gaps).to_string(index=False))
