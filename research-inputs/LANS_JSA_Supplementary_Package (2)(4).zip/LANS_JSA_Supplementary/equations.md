$$\begin{aligned}X_{k+1}&=X_k+hv\cos\psi_k,\\Y_{k+1}&=Y_k+h(v\sin\psi_k+d_k^y).\end{aligned}$$

$$\psi_{k+1}=\psi_k+h\left(g_kv\tan\delta_{k+1}/L+d_k^\psi\right).$$

$$\delta_{k+1}=\mathrm{sat}_{0.5}\!\left[\delta_k+\mathrm{clip}(\beta(q_k-\delta_k),-rh,rh)\right],$$

$$\begin{aligned}w_k&=(1-\alpha)\nu_{k-1}+\alpha(m_k-2m_{k-1}+m_{k-2})^2/6,\\\nu_k&=\operatorname{clip}(w_k,0.0004,0.0225).\end{aligned}$$

$$\begin{aligned}f&=-0.25(K_1e_y+K_2\chi),\\\chi&=e_\psi+\arcsin(\operatorname{clip}(\hat b_y/v,-0.5,0.5)).\end{aligned}$$

$$b=\mathrm{sat}_{0.5}\!\left\{\arctan\!\left[(f+L\kappa-L\hat b_\psi/v)/\hat g\right]\right\}.$$

$$\tilde b=\mathrm{sat}_{0.5}\!\left[b+0.5(b-\hat\delta_{\mathrm{arrival}})\right].$$

$$\bar r_k=\begin{cases}r_j\exp(-a/0.1),&0\leq a\leq0.2\;\mathrm{s},\\0,&\mathrm{otherwise}.\end{cases}$$

$$J(u)=\xi(u)^\mathsf{T}S\xi(u)+10u^2.$$

$$\begin{gathered}R_k=-100e_y^2-20e_\psi^2-0.02a_k^2\\-0.05(a_k-a_{k-1})^2-0.05F_k-500T_k\\-25(M_k^2-M_{k-1}^2).\end{gathered}$$

$$R_{\mathrm{delay}}=-0.02\left(\frac{d_{\mathrm{remote}}}{200\;\mathrm{ms}}\right)|e_y|.$$

$$\operatorname{RMSE}=\sqrt{\frac{\sum_{i=0}^{n}e_i^2}{n+1}}.$$

$$E_{\mathrm{peak}}=\max_{0\leq i\leq n}|e_i|.$$

$$\mathrm{RMSE}_{\mathrm{pen}}=\sqrt{\frac{\sum_{i=0}^{n}e_i^2+(1000-n)c^2}{1001}}.$$

$$z_{k+1}=Fz_k+Gd_k.$$

$$\begin{aligned}\Delta V&\leq-\tfrac12\|z\|^2+\beta\bar d^2,\\\beta&=2\|F^\mathsf{T}PG\|^2+G^\mathsf{T}PG.\end{aligned}$$

$$V_k\leq(1-\alpha)^kV_0+\frac{\beta\bar d^2}{\alpha}\left[1-(1-\alpha)^k\right].$$

$$\begin{aligned}\ell_k&=\operatorname{round}\!\left(\frac{d_k^c}{1000h}\right),\\t_k^c&=\max(k+\ell_k,t_{\mathrm{last}}+1).\end{aligned}$$

$$\begin{aligned}\eta_j^-&=f_e(\eta_{j-1}^+,\delta_j),\\\Sigma_j^-&=A_e\Sigma_{j-1}^+A_e^\mathsf{T}+Q_e.\end{aligned}$$

$$L_j=\Sigma_j^-H^\mathsf{T}(H\Sigma_j^-H^\mathsf{T}+R_j)^{-1}.$$

$$\eta_j^+=\Pi[\eta_j^-+L_j(m_j-H\eta_j^-)].$$

$$\begin{gathered}\Sigma_j^+=(I-L_jH)\Sigma_j^-(I-L_jH)^\mathsf{T}\\+L_jR_jL_j^\mathsf{T}.\end{gathered}$$

$$\begin{aligned}r^a&=\begin{cases}\bar r,&J(u^+)<J(\tilde b),\\0,&\mathrm{otherwise},\end{cases}\\u^c&=\operatorname{sat}_{0.5}(\tilde b+r^a).\end{aligned}$$

$$u^r=\underset{u\in\mathcal U_{\mathrm{test}}}{\arg\min}\ D(u).$$

$$\begin{gathered}\Delta V=-\|z_k\|^2+2d_kG^\mathsf{T}PFz_k\\+d_k^2G^\mathsf{T}PG.\end{gathered}$$

$$C_{\max}^{\mathrm{obs}}=\max_{1\leq i\leq N}c_i,\quad N_D=\sum_{i=1}^{N}\mathbf1\{c_i>D\}.$$

$$M_D=D-C_{\max}^{\mathrm{obs}},\quad \tilde c_i=c_i+f_i.$$

$$C^{\mathrm{WCET}}=\sup_{(x,s)\in\mathcal A}C(x,s).$$