# Submission notes for the authors

The manuscript is written in English, retains Rizwan Ali and Jie Tian and the Nanjing Forestry University affiliation from the supplied revised draft, and follows the reference article's two-column body, numbered headings, ruled tables and algorithm presentation. Publisher logos, an assigned DOI, volume/article number and acceptance dates are deliberately absent because this is an unpublished manuscript. It is a reference-style author manuscript, not an Elsevier production proof.

## Venue and eligibility
The supplied special-issue call identifies Timing-Verifiable Intelligent Real-Time Systems, deadline 31 October 2026, and submission type VSI:RTCSA2026. The official search listing corroborated the title and deadline. Direct access to the live ScienceDirect guide and call returned HTTP 403 during this check, so complete current submission-format requirements could not be verified. The call discusses recommended RTCSA 2026 papers; it does not establish from the supplied wording whether unrelated submissions are eligible. Confirm eligibility with the guest editors before submission if this paper was not an RTCSA recommendation. No email has been sent and no submission has been made.

Official call: https://www.sciencedirect.com/special-issue/336357/timing-verifiable-intelligent-real-time-systems
Guide: https://www.sciencedirect.com/journal/journal-of-systems-architecture/publish/guide-for-authors

## Author-only information still required
Confirm author order, affiliation spelling, corresponding author and email, funding, competing interests, individual CRediT contributions, and the code/data availability arrangement. These facts have not been invented. Approve and adjust the generative-AI disclosure to reflect actual use and the journal's current requirements. If submission requires anonymization, remove identifying author/header/metadata information and provide a separate title page. Reference-style two-column formatting is provided as requested; use the journal's required editable submission layout if it differs.

## Scientific limits
The complete delayed controller has no formal safety or timing certificate. The nominal theorem is conditional. Physical sensor-to-actuator measurements are unavailable. The standalone PPO pilots failed and are not a competent tuned baseline. Energy measurements have gaps and variable idle power; only exploratory CPU-package workload estimates are justified. The article does not support universal #1, 49× speedup or an energy-saving claim.

The special issue emphasizes timing-verifiable systems. This paper provides an architecture and empirical timing-robustness case study; it does not introduce a new timing-verification method. Fit and acceptance cannot be guaranteed. A stronger contribution would require new evidence, not stronger wording.

## Results and reproduction
Main manuscript: 20 tables and 8 figures, including component ablation, reward retraining, original and standalone PPO diagnostics, contribution pilot, path variation, pooled validation, noise-observer comparisons, both CPU timing hosts, actuator response, energy and conditional theory.

TABLE_INVENTORY.csv lists the accompanying numerical tables. historical_results preserves development-stage protocols and CSVs whose architectures differ; they are not treated as current validation. tables/legacy_12_energy_availability.csv and response availability status files predate the Windows log: the new package-energy pilot supersedes their missing-energy status only within its declared scope. Physical vehicle latency and whole-system energy remain missing. Old failure or timing results are not rewritten.

prepare.py and build.py regenerate figures and Word from the project paths recorded in them. Their original project-root data dependencies are explicit; the archive includes derived data and audited code but is not a standalone training installation with all policies. energy_analysis/analyze.py and finish.py reproduce energy tables using the included raw logs. Figure images and vector PDFs are included. No new training was performed during manuscript preparation.

## Latest revision
See FINAL_REVIEW.md and WCET_ANALYSIS.md. Appendix C and Tables 19–20 add a raw-log timing audit; they do not certify WCET. Twenty-eight equation labels are documented in EQUATION_AUDIT.csv. Three thousand five hundred equation checks and seven thousand code-excerpt checks pass. All reported timing numbers are host-specific.
