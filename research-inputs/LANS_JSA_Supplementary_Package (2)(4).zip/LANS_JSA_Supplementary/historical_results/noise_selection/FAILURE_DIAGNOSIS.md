# Failure diagnosis after frozen validation

This is post-validation diagnosis, not another tuning stage.

Updated LANS rescued the DLC/combined cell with evaluation seed2300 for all three policies. It still failed three other physical DLC/combined cells (seeds2302,2303,2304), with all three policy seeds failing each cell. The PPO-off version failed those same three cells. This means the measured survival gain comes from the observer/local analytical branch in this experiment, not an established PPO survival benefit.

Seed2302 failed at9.81–9.82s, long after the5s gain step. Seeds2303/2304 failed at4.79–4.88s, shortly after the3–4.5s noise burst and inside the2–6s remote outage. The gain step had not occurred in the latter cases. These timings identify stress combinations for further investigation; they do not isolate a unique causal mechanism.

The selected MPC failed only the seed2300 sine/full-command-delay cell, at0.88s. Original MPC failed four cells; selected MPC failed one. It would be misleading to show only the weaker original MPC after giving LANS a new tuning stage.

Next justified development hypothesis: uncertainty-aware local prediction and constrained recovery that account jointly for delayed pose, disturbance/gain estimation error, actuator dynamics and queued commands. Compare such an architecture with the same prediction/actuator treatment in MPC on a fresh development/test split. Merely training the present remote PPO longer is not a demonstrated remedy for failures while remote corrections are expired. No guarantee is made that the next hypothesis will beat MPC.

The adaptive-noise candidate is an experimental improvement over original LANS on these cells, not an approved real-vehicle safety fix. Do not replace publication claims with universal #1 or formal safety statements.
