# LANS noise-observer experiment — frozen validation

Strictly higher observed survival than the independently selected MPC: **False**.
No worse on survival, observed peak and ordinary mean RMSE simultaneously: **False**.
These are finite empirical comparisons, not universal rankings or safety guarantees.

## Results on the same new test cells

| method | episodes | survived | survival_percent | worst_observed_m | mean_rmse_m | failure_penalized_rmse_m |
| --- | --- | --- | --- | --- | --- | --- |
| new_lans | 315 | 306 | 97.142857 | 2.582217 | 0.168896 | 0.193514 |
| new_zero | 105 | 102 | 97.142857 | 2.555714 | 0.170353 | 0.194973 |
| original_lans | 315 | 303 | 96.190476 | 2.580472 | 0.169255 | 0.208781 |
| original_mpc | 105 | 101 | 96.190476 | 2.544550 | 0.130753 | 0.185781 |
| selected_mpc | 105 | 104 | 99.047619 | 2.500377 | 0.155527 | 0.168871 |

`original_lans` and `new_lans` each include all three previously trained policies; other methods run once per physical test cell. `new_zero` disables only the PPO residual. `selected_mpc` gets the same ten noise-filter choices as LANS. The frozen development choices were {'lans': 'adaptive_slow', 'mpc': 'fixed16'}.

## Paired changes

| comparison | paired_cells | survival_difference_pp | mean_rmse_difference_m | penalized_rmse_difference_m |
| --- | --- | --- | --- | --- |
| new_lans minus original_lans | 105 | 0.952381 | -0.000359 | -0.015267 |
| new_lans minus new_zero | 105 | 0.000000 | -0.001457 | -0.001459 |
| new_lans minus original_mpc | 105 | 0.952381 | 0.038143 | 0.007733 |
| new_lans minus selected_mpc | 105 | -1.904762 | 0.013369 | 0.024643 |

For each physical cell, the three PPO policies are averaged before pairing against a baseline. Positive survival difference favors the first method; negative RMSE difference favors it. There are 105 physical cells, not 315 independent test scenarios for LANS. Five evaluation seeds and three old training seeds do not establish statistical superiority across arbitrary conditions. Historical 95.24% versus 96.83% came from a different test set; compare old and new methods within this table instead.

## Training seeds

| method | train_seed | episodes | survived | survival_percent | worst_observed_m | mean_rmse_m | failure_penalized_rmse_m |
| --- | --- | --- | --- | --- | --- | --- | --- |
| new_lans | 42 | 105 | 102 | 97.142857 | 2.524802 | 0.168725 | 0.193253 |
| new_lans | 43 | 105 | 102 | 97.142857 | 2.561327 | 0.169536 | 0.194179 |
| new_lans | 44 | 105 | 102 | 97.142857 | 2.582217 | 0.168427 | 0.193110 |
| original_lans | 42 | 105 | 101 | 96.190476 | 2.578351 | 0.169174 | 0.208681 |
| original_lans | 43 | 105 | 101 | 96.190476 | 2.580472 | 0.169880 | 0.209406 |
| original_lans | 44 | 105 | 101 | 96.190476 | 2.578271 | 0.168709 | 0.208255 |

## Stress profiles

| method | profile | episodes | survived | survival_percent | worst_observed_m | mean_rmse_m | failure_penalized_rmse_m |
| --- | --- | --- | --- | --- | --- | --- | --- |
| new_lans | actuator | 45 | 45 | 100.000000 | 0.447697 | 0.117321 | 0.117321 |
| new_lans | combined | 45 | 36 | 80.000000 | 2.582217 | 0.327070 | 0.499396 |
| new_lans | full_command_delay | 45 | 45 | 100.000000 | 0.970702 | 0.326227 | 0.326227 |
| new_lans | gain_step | 45 | 45 | 100.000000 | 0.393609 | 0.134835 | 0.134835 |
| new_lans | noise_burst | 45 | 45 | 100.000000 | 0.361366 | 0.116814 | 0.116814 |
| new_lans | nominal | 45 | 45 | 100.000000 | 0.393980 | 0.035234 | 0.035234 |
| new_lans | sensor | 45 | 45 | 100.000000 | 0.427124 | 0.124772 | 0.124772 |
| new_zero | actuator | 15 | 15 | 100.000000 | 0.447697 | 0.117321 | 0.117321 |
| new_zero | combined | 15 | 12 | 80.000000 | 2.555714 | 0.328153 | 0.500490 |
| new_zero | full_command_delay | 15 | 15 | 100.000000 | 0.970560 | 0.327383 | 0.327383 |
| new_zero | gain_step | 15 | 15 | 100.000000 | 0.392972 | 0.137465 | 0.137465 |
| new_zero | noise_burst | 15 | 15 | 100.000000 | 0.368086 | 0.119924 | 0.119924 |
| new_zero | nominal | 15 | 15 | 100.000000 | 0.393980 | 0.034823 | 0.034823 |
| new_zero | sensor | 15 | 15 | 100.000000 | 0.428208 | 0.127406 | 0.127406 |
| original_lans | actuator | 45 | 45 | 100.000000 | 0.449654 | 0.117208 | 0.117208 |
| original_lans | combined | 45 | 33 | 73.333333 | 2.580472 | 0.338058 | 0.614741 |
| original_lans | full_command_delay | 45 | 45 | 100.000000 | 0.967785 | 0.321308 | 0.321308 |
| original_lans | gain_step | 45 | 45 | 100.000000 | 0.397422 | 0.134769 | 0.134769 |
| original_lans | noise_burst | 45 | 45 | 100.000000 | 0.385509 | 0.114763 | 0.114763 |
| original_lans | nominal | 45 | 45 | 100.000000 | 0.393980 | 0.035234 | 0.035234 |
| original_lans | sensor | 45 | 45 | 100.000000 | 0.418128 | 0.123444 | 0.123444 |
| original_mpc | actuator | 15 | 15 | 100.000000 | 0.301488 | 0.069783 | 0.069783 |
| original_mpc | combined | 15 | 13 | 86.666667 | 2.534353 | 0.211163 | 0.410897 |
| original_mpc | full_command_delay | 15 | 13 | 86.666667 | 2.544550 | 0.352582 | 0.538041 |
| original_mpc | gain_step | 15 | 15 | 100.000000 | 0.289508 | 0.082896 | 0.082896 |
| original_mpc | noise_burst | 15 | 15 | 100.000000 | 0.289774 | 0.080701 | 0.080701 |
| original_mpc | nominal | 15 | 15 | 100.000000 | 0.231203 | 0.029430 | 0.029430 |
| original_mpc | sensor | 15 | 15 | 100.000000 | 0.257725 | 0.088718 | 0.088718 |
| selected_mpc | actuator | 15 | 15 | 100.000000 | 0.299059 | 0.089635 | 0.089635 |
| selected_mpc | combined | 15 | 15 | 100.000000 | 0.796575 | 0.233334 | 0.233334 |
| selected_mpc | full_command_delay | 15 | 14 | 93.333333 | 2.500377 | 0.386728 | 0.480141 |
| selected_mpc | gain_step | 15 | 15 | 100.000000 | 0.275502 | 0.122156 | 0.122156 |
| selected_mpc | noise_burst | 15 | 15 | 100.000000 | 0.306504 | 0.103585 | 0.103585 |
| selected_mpc | nominal | 15 | 15 | 100.000000 | 0.231203 | 0.029430 | 0.029430 |
| selected_mpc | sensor | 15 | 15 | 100.000000 | 0.301838 | 0.123819 | 0.123819 |

## What changed and what was tested

A timestamp-aware EKF can now estimate pose measurement variance from causal second differences, clip innovations, or limit the rate of change of disturbance/gain estimates. Ten candidates were tested independently for each controller on the same 28 development cells: 560 development episodes. Selection uses fewest failures, then lowest observed peak error, then lowest mean RMSE. All candidates and failures are retained. The original filter was eligible.

The variance estimator uses EWMA(second_difference**2/6), bounded between 0.0004 and 0.0225 per pose component. Actual signal curvature can inflate this estimate; it is a heuristic. Rate constraints are engineering priors on lateral disturbance, yaw disturbance and steering gain, not access to hidden simulator parameters. They can miss abrupt real changes. Projected EKF covariance is not a calibrated uncertainty certificate. Repeated delayed pose packets are not assimilated again.

No new PPO training occurred in this experiment. Three frozen 37-feature policies, previously trained for 51,200 steps each, and their original normalization were reused. Observer changes cause observation-distribution shift; transfer was tested, not assumed. Controller gains, residual limit (0.01 rad), reward, termination threshold and physical stress definitions stayed unchanged. PPO expires when the latest remote packet is older than 200 ms, so local analytical control carries prolonged outages.

Final validation was frozen before execution: five seeds 2300–2304, three trajectories, seven stress profiles, nine executions per cell = 945 episodes. New sine is 2*sin(2*pi*0.18*t); chirp is 1.3*sin(2*pi*(0.05*t+0.016*t*t)). DLC is also retained. Validation was not used to change parameters or select policy seeds. Source/model/config hashes are recorded before validation.

## Physical fairness and interpretation

Every method sees the same seeded disturbances, sensor noise, delayed pose, actuator lag/rate limits, steering saturation and whole-command delay. Fallback commands use the same actuator path and cannot bypass it. The arrival predictor uses a fixed nominal actuator time constant/rate, not the hidden actual parameters. Fresh measured steering and longitudinal position are assumed available to all methods. The MPC is the provided finite-horizon linear MPC, not every possible MPC design.

Survival means completing 10 seconds without |lateral error| > 2.5 m. It does not mean collision avoidance or lane compliance. The separate tighter diagnostic envelope is |lateral error| <= 0.3 m and |heading error| <= 0.06 rad. Worst observed error includes initial state and samples until termination; it is not a mathematical worst-case bound. A small difference in peak error near the failure cutoff is weak evidence about robustness.

Ordinary RMSE uses available samples and may favor short failed runs. Failure-penalized RMSE fills the remainder of the 10-second horizon with max(2.5 m, last absolute error). This is an explicit artificial penalty, not a simulated continuation. Raw traces, initial errors, all failures and per-profile/per-seed tables are included so the ranking can be audited.

The model remains a constant-speed kinematic simulation without tire slip, friction limits, obstacles or emergency braking. No Lyapunov/invariant-set guarantee for the delayed saturated nonlinear system has been proven. Novelty, hardware timing, energy claims and the full revised manuscript have not been revalidated by this experiment. It does not clear all reviewer comments.
