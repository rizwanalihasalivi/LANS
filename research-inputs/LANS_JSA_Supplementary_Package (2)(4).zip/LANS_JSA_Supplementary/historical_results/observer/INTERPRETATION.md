## Practical interpretation

The overall numerical first place is a **practical tie with the adaptive controller
without PPO** (about0.0204mm difference in episode-mean RMSE). Two neural seeds improve
that baseline and one degrades it. PPO wins only20/60 cells after seed averaging.
The observer/adaptive compensation, rather than established neural benefit, explains
the substantial improvement over previous LANS and integral LQR.

Nominal mean RMSE is0.016140m for new LANS versus0.015522m for integral LQR:
LANS does not win every operating condition. Under gain mismatch/noise/disturbance,
the corresponding means are0.068023m and0.102081m. No method terminates early,
but heading/lateral tracking-envelope exceedances remain. Zero quadratic-score
exceedances must not be reported as zero safety violations or proof of invariance.
Raw fallback totals differ in exposure: normalize by total steps before comparison.

Software-cycle timing in this recorded run: median675.5us for observer+PPO,412.2us for
adaptive-only,316.8us for integral LQR and569.3us for previous LANS. This includes
simulator/observer work and is not pure inference or physical end-to-end latency.
New LANS is slower than previous LANS here; there is no speedup claim. Timing uses
seed42 only, three passes and2,700 retained samples per method. Full samples/p95 are
included; reruns on other hosts will differ.

## Next research decision

Keep this frozen release as the causal-observer result. Further long PPO training
is not justified by these tiny, inconsistent incremental gains. Before another
neural optimization cycle, define a new development set with independently specified
vehicle dynamics (tire/actuator dynamics, varied speed and localization latency),
matched adaptive analytical and MPC baselines, and a new untouched final set.
Use the same information and delay/fallback assumptions for all controllers.
Train the residual to handle demonstrable remaining model error; accept the neural
branch only if its gain repeats across seeds without unacceptable nominal regression
or higher envelope-violation rate. Do not tune those changes on the final data here.
The paper should currently emphasize observer-based compensation and report the PPO
ablation honestly; the experiments do not establish neural necessity or novelty.
