# LANS observer architecture: frozen test report

Measured first by equal-cell mean RMSE: **observer**. This is a ranking only within the four tested methods and this simulator.

## Overall results

| method | episodes | mean_rmse_m | worst_error_m | early_terminations | fallback_steps | unresolved_steps | V_exceeded_steps | envelope_exceeded_steps | steps |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| observer | 180 | 0.042082 | 0.278827 | 0 | 7814 | 0 | 0 | 183 | 180000 |
| adaptive_zero | 60 | 0.042102 | 0.279331 | 0 | 2574 | 0 | 0 | 61 | 60000 |
| integral_lqr | 60 | 0.058802 | 0.289816 | 0 | 10196 | 0 | 0 | 60 | 60000 |
| previous | 180 | 0.060919 | 0.292945 | 0 | 31193 | 0 | 0 | 190 | 180000 |

## Attribution

Observer + PPO mean RMSE: 0.042082 m. Previous optimized LANS: 0.060919 m. Relative reduction: 30.92%.
Matched adaptive observer with PPO disabled: 0.042102 m. Neural relative reduction against that baseline: 0.05%. Negative reduction means degradation.
Neural mean paired RMSE difference by training seed (negative is better): {42: -0.00012820978847113518, 43: -0.00012418776145664846, 44: 0.00019119323388593865}.
After averaging the three neural seeds, PPO wins 20 of 60 matched scenario cells. These cells and within-episode samples are not independent training replicates. Three training seeds are insufficient for a strong population-level superiority claim.

## Protocol and limits

Three training seeds each ran 51,200 steps, requested budget 50,000. No checkpoint or controller parameter was selected on these final results. Development selection used DLC seeds20/21 and three observer process-noise candidates; filtering-only and zero-residual ablations are retained in development.csv.

Final set: seeds500/501/502; difficulty0/1; fixed0/80/200ms on DLC, sine2.4m at0.19Hz and chirp1.6*sin(2*pi*(0.06*t+0.012*t^2)); DLC additionally uses [0,200,20,130,50]ms every40ticks. This gives60 scenario cells, each with integral LQR, adaptive zero residual, and three models each for previous/new LANS:480 episodes. All methods receive the same per-cell plant gain and measurement random stream.

Difficulty0 is noiseless/undisturbed. Difficulty1 adds gain uncertainty, lateral/yaw sinusoidal disturbance and Gaussian measurement noise. The observer receives noisy lateral position/heading, known longitudinal reference position and its previous applied steering, not hidden gain or disturbance. Longitudinal localization and constant speed remain idealized.

The observer estimates lateral/yaw biases and steering gain causally. Biases are held constant during queue prediction. This is an approximation to sinusoidal/time-varying disturbances. Gain/bias separation is not guaranteed to be identifiable, and projected estimates/covariance are not a robustness certificate.

The simulated plant uses nonlinear kinematic Euler propagation. This is not a dynamic tire model or hardware vehicle. No MPC or standalone PPO comparator is included in this architecture test. A first place here cannot be advertised as superiority over MPC, all controllers, or all driving conditions.

Fallback retains the fresh local-actuator path assumption, unchanged thresholds and explicit unresolved recovery flag. Old quadratic P/V_MAX is a diagnostic, not a valid proven invariant for the augmented delayed nonlinear system. No formal safety/stability guarantee follows from low errors or zero terminations.

The neural observation contains31 features with its own normalization; previous optimized LANS uses28. Never mix normalization/model pairs. PPO has a bounded0.01rad residual, 64x64 network, zero initial mean, learned Gaussian exploration, tracking reward, no external-latency reward.

Every episode and step is retained. Summary tables report all conditions; report generation does not filter failures or pick a winning seed. Path/delay/difficulty and paired tables are separate CSVs. Timing, if present, measures software simulation loop cost and is excluded from tracking rank.

## Reviewer status

Real FIFO delay, causal prediction, matched comparisons, reward/architecture details, multiple seeds, fair reporting and explicit recovery failures are implemented. Neuro-symbolic novelty, formal delay/saturation proof, physical fallback feasibility, MPC comparison, hardware timing/energy and broad generalization remain unestablished. Do not retain the old49-fold speedup or unconditional200ms stability claim.

## Practical interpretation

The overall numerical first place is a **practical tie with the adaptive controller
without PPO** (about0.0204mm difference in episode-mean RMSE). Two neural seeds improve
that baseline and one degrades it. PPO wins only20/60 cells after seed averaging.
The observer/adaptive compensation, rather than established neural benefit, explains
the substantial improvement over previous LANS and integral LQR.

Nominal mean RMSE is0.016140m for new LANS versus0.015522m for integral LQR:
LANS does not win every operating condition. Under gain mismatch/noise/disturbance,
the corresponding means are0.068023m and0.102081m. No method terminates early,
but heading/lateral tracking-envelope exceedances remain. Zero quadratic-score
exceedances must not be reported as zero safety violations or proof of invariance.
Raw fallback totals differ in exposure: normalize by total steps before comparison.

Software-cycle timing in this recorded run: median675.5us for observer+PPO,412.2us for
adaptive-only,316.8us for integral LQR and569.3us for previous LANS. This includes
simulator/observer work and is not pure inference or physical end-to-end latency.
New LANS is slower than previous LANS here; there is no speedup claim. Timing uses
seed42 only, three passes and2,700 retained samples per method. Full samples/p95 are
included; reruns on other hosts will differ.

## Next research decision

Keep this frozen release as the causal-observer result. Further long PPO training
is not justified by these tiny, inconsistent incremental gains. Before another
neural optimization cycle, define a new development set with independently specified
vehicle dynamics (tire/actuator dynamics, varied speed and localization latency),
matched adaptive analytical and MPC baselines, and a new untouched final set.
Use the same information and delay/fallback assumptions for all controllers.
Train the residual to handle demonstrable remaining model error; accept the neural
branch only if its gain repeats across seeds without unacceptable nominal regression
or higher envelope-violation rate. Do not tune those changes on the final data here.
The paper should currently emphasize observer-based compensation and report the PPO
ablation honestly; the experiments do not establish neural necessity or novelty.
