# LANS high-latency architecture experiment

Lowest aggregate remote-test mean RMSE: **split_zero**. This numerical ordering is confined to this frozen simulator comparison. Inspect neural-versus-zero differences before claiming a neural benefit.

## Remote-delay results

| method | episodes | mean_rmse_m | worst_error_m | mean_steering_rate_rms | terminated | envelope_percent | residual_accepted_percent |
| --- | --- | --- | --- | --- | --- | --- | --- |
| split_zero | 102 | 0.017003 | 0.107073 | 1.023338 | 0 | 0.073529 | 0.000000 |
| split_ppo | 306 | 0.017023 | 0.107073 | 1.021601 | 0 | 0.073529 | 26.901961 |
| local_mpc | 102 | 0.018176 | 0.102171 | 1.011069 | 0 | 0.068627 | 0.000000 |
| local_integral | 102 | 0.039399 | 0.183427 | 4.948756 | 0 | 0.053922 | 0.000000 |

LANS reduction versus tuned integral LQR: 56.793%; versus local MPC: 6.343%; versus identical analytical controller without PPO: -0.118%. Negative values mean LANS is worse.
Paired neural RMSE difference by training seed (negative better): {42: -4.1191422333612614e-05, 43: 6.549460626292256e-05, 44: 3.590903817675588e-05}. Neural wins after seed averaging: 23/102 cells. Three training seeds do not establish statistical or universal superiority.

## Delay breakdown

| method | schedule | requested_delay_ms | mean_rmse_m | max_error_m | terminated |
| --- | --- | --- | --- | --- | --- |
| local_integral | fixed | 0 | 0.039423 | 0.183427 | 0 |
| local_integral | fixed | 80 | 0.039423 | 0.183427 | 0 |
| local_integral | fixed | 200 | 0.039423 | 0.183427 | 0 |
| local_integral | fixed | 500 | 0.039423 | 0.183427 | 0 |
| local_integral | fixed | 1000 | 0.039423 | 0.183427 | 0 |
| local_integral | jitter | 0 | 0.039221 | 0.173769 | 0 |
| local_integral | outage | 80 | 0.039221 | 0.173769 | 0 |
| local_mpc | fixed | 0 | 0.018064 | 0.102171 | 0 |
| local_mpc | fixed | 80 | 0.018064 | 0.102171 | 0 |
| local_mpc | fixed | 200 | 0.018064 | 0.102171 | 0 |
| local_mpc | fixed | 500 | 0.018064 | 0.102171 | 0 |
| local_mpc | fixed | 1000 | 0.018064 | 0.102171 | 0 |
| local_mpc | jitter | 0 | 0.019018 | 0.089272 | 0 |
| local_mpc | outage | 80 | 0.019018 | 0.089272 | 0 |
| split_ppo | fixed | 0 | 0.017000 | 0.107073 | 0 |
| split_ppo | fixed | 80 | 0.016969 | 0.107073 | 0 |
| split_ppo | fixed | 200 | 0.016966 | 0.107073 | 0 |
| split_ppo | fixed | 500 | 0.016962 | 0.107073 | 0 |
| split_ppo | fixed | 1000 | 0.016962 | 0.107073 | 0 |
| split_ppo | jitter | 0 | 0.017438 | 0.098316 | 0 |
| split_ppo | outage | 80 | 0.017381 | 0.096163 | 0 |
| split_zero | fixed | 0 | 0.016962 | 0.107073 | 0 |
| split_zero | fixed | 80 | 0.016962 | 0.107073 | 0 |
| split_zero | fixed | 200 | 0.016962 | 0.107073 | 0 |
| split_zero | fixed | 500 | 0.016962 | 0.107073 | 0 |
| split_zero | fixed | 1000 | 0.016962 | 0.107073 | 0 |
| split_zero | jitter | 0 | 0.017314 | 0.095672 | 0 |
| split_zero | outage | 80 | 0.017314 | 0.095672 | 0 |

## True common actuator-delay diagnostic

| method | requested_delay_ms | episodes | completed | terminated | min_steps | max_error_m | max_heading_rad |
| --- | --- | --- | --- | --- | --- | --- | --- |
| delayed_adaptive | 0 | 3 | 3 | 0 | 1000 | 0.095672 | 0.040500 |
| delayed_adaptive | 80 | 3 | 3 | 0 | 1000 | 0.189067 | 0.052431 |
| delayed_adaptive | 200 | 3 | 3 | 0 | 1000 | 0.409969 | 0.101619 |
| delayed_adaptive | 500 | 3 | 3 | 0 | 1000 | 1.242284 | 0.255994 |
| delayed_adaptive | 1000 | 3 | 0 | 3 | 94 | 2.527328 | 0.176757 |
| delayed_integral | 0 | 3 | 3 | 0 | 1000 | 0.173769 | 0.051596 |
| delayed_integral | 80 | 3 | 3 | 0 | 1000 | 0.355306 | 0.068136 |
| delayed_integral | 200 | 3 | 3 | 0 | 1000 | 0.732969 | 0.087920 |
| delayed_integral | 500 | 3 | 3 | 0 | 1000 | 1.935777 | 0.204578 |
| delayed_integral | 1000 | 3 | 0 | 3 | 94 | 2.527328 | 0.176757 |

This separate diagnostic delays the complete steering command with an ordered FIFO. Fresh fallback is disabled for BOTH methods. It starts with an empty queue holding zero steering, with measurement feedback still fresh. Early termination occurs at |lateral error|>2.5m. Low truncated-episode RMSE must not be treated as success. These experiments are not a steady-state stability-margin test; startup, path, gain and disturbances all influence outcomes.

## What high-latency tolerance means here

Remote PPO/network packets are delayed. Local pose sensing, adaptive analytical feedback and actuator application remain fresh in all remote-suite methods. Packets have generation timestamps, newer received commands supersede old ones, commands older than200ms are ignored, and younger residuals are attenuated by exp(-age_ms/100). The zero-residual analytical controller therefore determines behavior under very high delay/outage. A1000ms remote-delay result is NOT evidence for1000ms actuator/sensor/end-to-end delay tolerance. No largest physically safe delay has been established.

The outage lasts from2s to6s: outgoing packets are dropped, packets scheduled to arrive during the outage are dropped, and the last received residual ages out. Existing commands may persist only until their200ms expiry. Local controller health and fresh measurements are assumed. Sensor failure, local overload and actuator lag are not modeled in this suite.

## Architecture and fairness

Selected development architecture: five-state causal pose/bias/gain EKF, stronger local analytical feedback, and a small asynchronous learned correction. A one-step estimated quadratic cost comparison rejects a correction if it does not improve the predicted objective. The local diagnostic supervisor/recovery remains; none of these checks proves an invariant set. The comparison score uses predicted state and steering cost, not true future plant error.

Development seeds60/61, DLC and2.2m0.13Hz sine, nominal/disturbed conditions. Four observer/gain combinations were compared; integral LQR gains were separately selected from1/1.5/2. A local horizon12, box-constrained linear MPC uses the same observer and fresh local path, with Q multiplier1/4 selected on the same development cells. All candidate results are retained. The MPC was added before opening any remote final outcomes, and did not cause retuning of LANS.

PPO was trained from scratch for seeds42/43/44,51,200steps each (50k requested), on delays0–200ms. No model was selected using final outcomes. All models have34 observations and their own normalization. Fixed500/1000ms, jitter and outage tests are outside that training delay range, but robustness there mainly comes from rejecting stale neural input.

Final seeds900/901/902; DLC,2m0.23Hz sine,1.4*sin(2*pi*(0.07*t+0.018*t^2)) chirp; nominal and disturbed conditions. Five fixed remote delays0/80/200/500/1000ms; DLC also tests jitter and outage.102 scenario cells, six executions per cell (three PPO seeds and three deterministic comparators)=612 episodes. Separate common-delay diagnostic has30 episodes. All methods share each cell's plant/measurement random stream.

Gain and disturbance estimates are imperfect; observer projections do not constitute confidence bounds. MPC uses a linear approximation to the same nonlinear kinematic plant, steering +/-0.5rad, horizon12, Q=selected_scale*diag(1,4),R=10, nominal DARE terminal matrix. Its box QP is solved unconstrained when feasible or with L-BFGS-B otherwise. This is a documented baseline, not a claim to cover every MPC design.

## Research limits

No dynamic tire/actuator model, realistic sensor latency, variable-speed emergency maneuver, hardware test or formal delayed-system proof is included. Steering-rate metrics are reported, but no physical rate constraint is imposed. Tracking-envelope exceedances remain distinct from quadratic diagnostic violations; no observed failures would not prove safety. Ranking accuracy, smoothness, runtime and delay robustness simultaneously requires explicit trade-offs; a universal #1 claim is unsupported.

Full code, checkpoints, normalization, configuration, raw episode/step traces, development scores and tests accompany this report. The supplied models can be evaluated without further training. Preserve this frozen test set; a further architecture change requires new development/validation cases.
## Interpretation of this recorded experiment

At fixed1000ms remote delay, split LANS and the identical adaptive-only variant tie because every neural packet is expired. Their mean RMSE is0.016962m, compared with0.018064m for local MPC and0.039423m for local integral LQR. This is a limited mean-tracking result, not a universal latency record.
Across the full remote suite, the adaptive-only variant has slightly lower mean RMSE than LANS+PPO. MPC has lower worst-case lateral error and slightly lower average steering-rate RMS. Integral LQR has the best nominal mean RMSE. Therefore the neural version is not #1 in every metric; no baseline has been removed to manufacture that ranking.
All612 remote episodes finish without early termination. The4-second outage is survived through local control and packet expiry. Across the30 common-actuator-delay episodes, six terminate early: all three seeds for each of the two controllers at1000ms. At500ms both complete but peak lateral errors exceed1m. Neither episode completion nor expiry establishes safety.
No further architecture changes or long training are justified as a guaranteed route to #1 from this result. Next research should target the actual remaining failure: full-path delay, actuator dynamics and delayed sensing, with an independently specified vehicle model and fresh validation set. A local emergency action or speed reduction must be physically available and tested before using it to claim high-delay safety. PPO should remain optional unless a repeated-seed ablation establishes a meaningful benefit.

## Recorded software timing

| method | samples | median_policy_us | median_local_sim_cycle_us | median_total_us | p95_total_us |
| --- | --- | --- | --- | --- | --- |
| local_integral | 2700 | 0.411000 | 197.161500 | 197.657000 | 303.609500 |
| local_mpc | 2700 | 0.521000 | 497.436000 | 497.937000 | 669.807100 |
| split_ppo | 2700 | 181.017500 | 410.788000 | 595.937000 | 779.300150 |
| split_zero | 2700 | 0.481000 | 340.393500 | 340.864000 | 481.910550 |
Three passes,2700retained samples/method, modelseed42, DLC difficulty1,1000ms remote delay, seed1701. First100ticks excluded. Policy column includes normalization/inference; local-cycle column includes channel/controller/supervisor plus simulator and observation/observer construction. Total is serial software-cycle time. No physical network wait is measured. Each method follows its own trajectory. These are not pure inference times or physical end-to-end latencies; medians of separate columns need not sum to the median of their sum.