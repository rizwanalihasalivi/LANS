# LANS optimization: final results

**Outcome: the optimization did not establish LANS as #1.** Integral-LQR leads this final comparison. Optimized LANS is effectively tied with zero residual: its mean paired ratio is about 0.9997 (SD across training means about 0.0080), while its absolute mean RMSE is slightly higher. This tiny difference is not credible evidence of superiority. Mean RMSE is about 13.1% lower than the previous LANS version.

Selected configuration: **context_gate**. Selection used development seeds 10/11 only. Final evaluation seeds 300/301/302 were not used to select this configuration. All three trained policies are retained, without best-seed selection.

Final comparison: 480 episodes, 480,000 simulated steps.

| Method | Mean paired RMSE ratio to zero residual | Mean RMSE m | Early failures | Max error m | Fallback % |
|---|---:|---:|---:|---:|---:|
| integral_lqr | 0.9793 | 0.06421 | 0/60 | 0.2888 | 16.6 |
| optimized | 0.9997 | 0.06599 | 0/180 | 0.3018 | 16.7 |
| zero_residual | 1.0000 | 0.06598 | 0/60 | 0.2838 | 16.8 |
| previous | 1.7174 | 0.07591 | 0/180 | 0.2972 | 18.1 |

Ratio below 1 means lower error than the matched zero-residual controller, averaged with equal weight per predefined scenario. Mean RMSE and mean ratio rank differently when scenario scales differ. Do not choose whichever metric makes a preferred method win.
SD across training-seed means and individual paired results are in the CSVs. Three training seeds and three evaluation seeds per cell are a small pilot, not broad statistical certification.

## Nominal and disturbed performance

| Difficulty | Method | Mean episode RMSE m |
|---:|---|---:|
| 0 | integral_lqr | 0.02490 |
| 0 | optimized | 0.02517 |
| 0 | previous | 0.04619 |
| 0 | zero_residual | 0.02519 |
| 1 | integral_lqr | 0.10351 |
| 1 | optimized | 0.10681 |
| 1 | previous | 0.10564 |
| 1 | zero_residual | 0.10676 |

## Safety diagnostics

| Method | Unresolved predicted quadratic exceedances | Actual sampled quadratic exceedances | Actual heuristic-envelope exceedances |
|---|---:|---:|---:|
| integral_lqr | 0 | 0 | 25 |
| optimized | 0 | 0 | 57 |
| zero_residual | 0 | 0 | 17 |
| previous | 0 | 0 | 40 |

An envelope exceedance is |ey|>0.30m or |heading error|>0.06rad in sampled plant state. This is an engineering diagnostic, not a collision event. Quadratic thresholds and episode completion are not safety proofs.

## Changes and interpretation

- Normalized bounded residuals reduce exploration scale; initial policy mean is zero. Policy uses two 64-unit layers and a diagonal Gaussian with initial log_std=-1.5.
- Mixed training includes nominal, half and full perturbation. Three memory features use measured errors only. The new model has 28 observation features and needs its own normalization.
- Development compared small/medium residual scales and two rewards. A fourth, explicitly documented development amendment tested a manually defined measured-error gate. This is not a learned gate or evidence of algorithmic novelty.
- Original analytical gain, plant, prediction model, diagnostic threshold and fallback mechanism were retained. Baselines use the same supervisor; the leaky-integral LQR competitor adds a documented integral state rather than an intentionally weakened comparator.
- Previous LANS policies use their original 25 features, physical steering scale and authority rules. All methods face the same paired disturbances and path cases.

## Limitations

This experiment cannot make LANS universally #1. Ranking applies only to the stated competitors and scenarios. No MPC, independently trained pure PPO, hardware or energy ranking is established. No global invariant-set or delayed nonlinear stability certificate is supplied.
The fallback bypass still assumes an actuator-side low-latency path. Novelty and formal safety require separate research. The final set is now used evidence and must not be reused as untouched test data after future tuning.
All development candidates, failed comparisons if any, raw final traces, model parameters and test output are retained. See protocol.json and README_OPTIMIZATION.md for exact reproduction and scope.

## Matched software timing

| Method | Samples | Mean microseconds | P99 microseconds |
|---|---:|---:|---:|
| integral_lqr | 1000 | 293.97 | 412.84 |
| optimized | 1000 | 519.05 | 777.98 |
| previous | 1000 | 521.20 | 838.90 |
| zero_residual | 1000 | 269.22 | 406.42 |

Same input/state/queue bank and single Torch CPU thread. Includes policy normalization/inference where applicable and controller execution; excludes observation construction, simulation propagation and sensing/actuation. Not a worst-case or end-to-end deadline guarantee.
