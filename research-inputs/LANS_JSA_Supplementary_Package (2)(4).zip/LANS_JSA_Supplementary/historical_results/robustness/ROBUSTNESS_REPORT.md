# LANS robustness experiment: measured outcomes

Lexicographic first: **mpc** (survival, then worst observed error, then failure-penalized average). This ordering is not proof of dominance in every metric.
LANS no-worse-on-all-three comparison (survival, observed worst, ordinary average RMSE): [('mpc', False), ('adaptive_zero', False), ('integral', True), ('previous_adaptive', True)].

## All frozen test outcomes

| method | episodes | survived | survival_percent | worst_observed_m | mean_episode_rmse_m | failure_penalized_rmse_m | mean_actual_steering_rate |
| --- | --- | --- | --- | --- | --- | --- | --- |
| mpc | 63 | 61 | 96.825397 | 2.610460 | 0.148645 | 0.196231 | 0.303888 |
| adaptive_zero | 63 | 60 | 95.238095 | 2.589149 | 0.198977 | 0.264141 | 0.224603 |
| lans | 189 | 180 | 95.238095 | 2.593383 | 0.197924 | 0.262710 | 0.224553 |
| integral | 63 | 37 | 58.730159 | 2.603429 | 0.461386 | 1.061840 | 0.384228 |
| previous_adaptive | 63 | 11 | 17.460317 | 2.685770 | 0.711525 | 2.036585 | 0.673946 |

## Training-seed variability

| train_seed | episodes | survival_percent | worst_observed_m | mean_episode_rmse_m | failure_penalized_rmse_m |
| --- | --- | --- | --- | --- | --- |
| 42 | 63 | 95.238095 | 2.539171 | 0.197833 | 0.262212 |
| 43 | 63 | 95.238095 | 2.547340 | 0.198229 | 0.262709 |
| 44 | 63 | 95.238095 | 2.593383 | 0.197709 | 0.263210 |

## Stress profiles

| method | profile | episodes | survival_percent | worst_observed_m | mean_episode_rmse_m | failure_penalized_rmse_m |
| --- | --- | --- | --- | --- | --- | --- |
| adaptive_zero | actuator | 9 | 100.000000 | 0.720903 | 0.144398 | 0.144398 |
| adaptive_zero | combined | 9 | 66.666667 | 2.589149 | 0.421837 | 0.877980 |
| adaptive_zero | full_command_delay | 9 | 100.000000 | 0.942717 | 0.349623 | 0.349623 |
| adaptive_zero | gain_step | 9 | 100.000000 | 0.476375 | 0.160723 | 0.160723 |
| adaptive_zero | noise_burst | 9 | 100.000000 | 0.496299 | 0.134287 | 0.134287 |
| adaptive_zero | nominal | 9 | 100.000000 | 0.396000 | 0.037625 | 0.037625 |
| adaptive_zero | sensor | 9 | 100.000000 | 0.467946 | 0.144347 | 0.144347 |
| integral | actuator | 9 | 88.888889 | 2.555408 | 0.234912 | 0.404127 |
| integral | combined | 9 | 0.000000 | 2.591120 | 0.943711 | 2.385443 |
| integral | full_command_delay | 9 | 0.000000 | 2.603429 | 0.918247 | 2.409582 |
| integral | gain_step | 9 | 88.888889 | 2.528282 | 0.313133 | 0.486531 |
| integral | noise_burst | 9 | 88.888889 | 2.546302 | 0.263567 | 0.425766 |
| integral | nominal | 9 | 100.000000 | 0.263692 | 0.021072 | 0.021072 |
| integral | sensor | 9 | 44.444444 | 2.590489 | 0.535058 | 1.300360 |
| lans | actuator | 27 | 100.000000 | 0.720903 | 0.144398 | 0.144398 |
| lans | combined | 27 | 66.666667 | 2.593383 | 0.420558 | 0.874065 |
| lans | full_command_delay | 27 | 100.000000 | 0.942521 | 0.348866 | 0.348866 |
| lans | gain_step | 27 | 100.000000 | 0.476375 | 0.159185 | 0.159185 |
| lans | noise_burst | 27 | 100.000000 | 0.493594 | 0.132213 | 0.132213 |
| lans | nominal | 27 | 100.000000 | 0.396000 | 0.037793 | 0.037793 |
| lans | sensor | 27 | 100.000000 | 0.467946 | 0.142452 | 0.142452 |
| mpc | actuator | 9 | 100.000000 | 0.345960 | 0.084735 | 0.084735 |
| mpc | combined | 9 | 88.888889 | 2.610460 | 0.249943 | 0.411678 |
| mpc | full_command_delay | 9 | 88.888889 | 2.593668 | 0.362729 | 0.534095 |
| mpc | gain_step | 9 | 100.000000 | 0.453717 | 0.114084 | 0.114084 |
| mpc | noise_burst | 9 | 100.000000 | 0.304379 | 0.095622 | 0.095622 |
| mpc | nominal | 9 | 100.000000 | 0.235331 | 0.028520 | 0.028520 |
| mpc | sensor | 9 | 100.000000 | 0.324683 | 0.104881 | 0.104881 |
| previous_adaptive | actuator | 9 | 22.222222 | 2.635834 | 0.587738 | 1.884171 |
| previous_adaptive | combined | 9 | 0.000000 | 2.596355 | 0.966279 | 2.455676 |
| previous_adaptive | full_command_delay | 9 | 0.000000 | 2.685770 | 0.836535 | 2.497275 |
| previous_adaptive | gain_step | 9 | 0.000000 | 2.620488 | 0.824528 | 2.453363 |
| previous_adaptive | noise_burst | 9 | 0.000000 | 2.604736 | 0.842462 | 2.464526 |
| previous_adaptive | nominal | 9 | 100.000000 | 0.153992 | 0.010320 | 0.010320 |
| previous_adaptive | sensor | 9 | 0.000000 | 2.638206 | 0.912811 | 2.490767 |

## Interpretation of the three targets

Survival means completion of the10-second episode without |lateral error| exceeding2.5m. It does not mean collision avoidance, road-boundary compliance, or formal safety. The tighter diagnostic envelope is |lateral error|<=0.3m and |heading error|<=0.06rad; exceedances are retained separately.

Worst observed error includes the initial condition and every simulated state until termination. It is not a mathematical worst-case bound. After termination the future trajectory is unknown. Mean episode RMSE on early failures covers fewer samples and can be misleading. The additional failure-penalized metric fills remaining samples to10s with max(2.5m,last absolute error); this is an explicitly artificial penalty, not simulated motion. Do not rank a short failed episode as accurate tracking.

The same physical/noise seed is paired across methods. PPO has three training seeds; deterministic baselines have one execution per cell. Reported LANS worst error is the maximum over all three trained policies. These samples are not hundreds of independent training replications; no strong population-level superiority inference follows from three seeds.

## Changes and attribution

The new observer processes each delayed pose at its timestamp, updating with the measured steering that actually occurred before that measurement. It then propagates using recorded executed steering to the current time. Repeated initial pose packets are not assimilated repeatedly. This assumes ordered consecutive sensor packets, fresh measured steering and known current longitudinal position. It does not implement arbitrary out-of-order or missing sensor-packet smoothing.

Selected LANS and MPC may additionally forecast to command arrival using their own queued commands and a fixed nominal actuator model: time constant0.08s and rate0.7rad/s. Actual stress-profile parameters are not supplied to that predictor. A measured-steering feedback correction can reduce lag. Damping>=1 was screened out because it is not robust to an instantaneous actuator; this screening is not a closed-loop stability proof. The same timestamp correction and arrival-forecast mechanism are available to the selected MPC comparator.

The old local adaptive baseline does not have the new timestamp/arrival correction. Integral LQR and MPC were selected on the same development cases as LANS. Development retained30 configurations:16 LANS,9 MPC,4 integral-LQR and1 previous baseline, each on28 cells. Search budgets are unequal and finite, so this does not establish superiority over optimally tuned versions of all controller families.

Neural training uses the selected analytical controller with a bounded0.01rad residual. All three37-feature policies were trained from scratch for51,200steps each. Training reward adds a25x penalty on increases in squared episode peak error and an extra400 penalty at failure, in addition to the existing tracking/action/fallback reward. Only peak measured error, not true peak error, enters the observation. Actual simulator errors are used for training rewards/evaluation, never as hidden policy inputs.

The zero-residual ablation uses identical prediction, observer, gains, actuator and sensor conditions. A gain from these changes cannot be credited to PPO unless that ablation supports it. At remote packet ages beyond200ms, PPO is ignored; robustness there is analytical/local-control behavior.

## Fair physical stress model

All methods share first-order steering response, rate limit, steering saturation, physical command delay, delayed pose packets, disturbances and plant-gain changes. Fallback commands pass through the same physical actuator path; they cannot bypass its transport delay. Measured actual steering is assumed available without additional latency/noise for all methods. Local/remote split does not remove sensor or actuator delay from this suite.

Profiles: nominal; actuator lag/rate limit;80ms pose delay; gain drop after5s; extra sensor noise from3–4.5s; combined actuator/sensor/noise/gain/remote jitter and4-second remote outage; and200ms whole-command transport delay. Development settings are in scripts/stress_env.py. These are synthetic stressors, not validated specifications of a particular vehicle.

Untouched tests use seeds1300/1301/1302 on DLC,1.8m0.21Hz sine and1.2*sin(2*pi*(0.08*t+0.014*t^2)) chirp. Actuator time constants/rate limits and sensor/command delays are perturbed with an independent seeded RNG; noise bursts increase to0.075 and post-step gain multiplier decreases to0.6. All63 cells are run on the four deterministic comparators plus three PPO seeds:441 episodes. No settings are changed after opening final results.

## Limits and publication claims

Vehicle speed stays25m/s; there is no tire/slip/friction model, obstacle/collision geometry, emergency braking, hardware timing guarantee or verified safe set. Gaussian sensor noise is unbounded. Observer gain/bias projections and the old quadratic diagnostic do not certify the delayed nonlinear saturated system. Arbitrary adversarial conditions, all delays and all controller families are outside the experiment.

If no method dominates survival, observed worst error and average error simultaneously, report the trade-off. Do not remove the zero-residual or MPC baseline, lower disturbance levels, stop the vehicle, discard failures or select the best test seed to manufacture #1. This package records an optimization experiment, not a universal ranking or a safety guarantee.
## Main remaining failure in this frozen test

LANS completes180/189 episodes (60/63 for every training seed). All nine failures occur on DLC in the combined-stress profile, at3.90–4.55s, during the3–4.5s noise-burst interval or immediately afterward. This is also inside the2–6s remote outage, when neural corrections have expired. The subsequent gain step at5s has not yet occurred, so it cannot explain these particular failures.
The estimator uses fixed measurement variance0.0004 while the heldout noise-burst standard deviation is0.075 (variance0.005625). This noise-model mismatch, combined with delayed pose and actuator lag/rate limits, is a plausible contributor; these runs do not isolate its causal effect. An innovation-aware measurement-noise model or robust observer is a justified next development hypothesis, not a proven fix.
MPC completes61/63 episodes and has lower ordinary and failure-penalized average error. LANS has slightly smaller observed peak error, but both methods terminate failed episodes around the2.5m threshold. That small peak difference is not evidence of a smaller mathematical worst case. Neural-versus-zero survival is identical; the neural average gain is small and the maximum over neural seeds is slightly worse.
The requested simultaneous #1 result has NOT been established. The final dataset remains frozen. Any observer/noise-model or controller-ensemble follow-up must use a new development/validation split; do not present post-hoc retuning on these cases as independent validation.