from pathlib import Path
import pandas as pd,numpy as np,json,shutil,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
R=Path(__file__).resolve().parent; W=R.parent; T=R/'tables';F=R/'figures'
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
def save(n):
 plt.savefig(F/(n+'.png'),dpi=300,bbox_inches='tight');plt.savefig(F/(n+'.pdf'),bbox_inches='tight');plt.close()
for p in (W/'paper_bench/lans_bench/paper_tables').glob('*.csv'):shutil.copy(p,T/('legacy_'+p.name))
for folder,prefix in [('energy_results','energy_'),('ppo_pilot/lans_pilot/contribution_results','pilot_'),('remaining_work/lans_completion/completion_results','standalone_'),('all_paper_results/additional_tests/results','response_')]:
 for p in (W/folder).glob('*.csv'):shutil.copy(p,T/(prefix+p.name))
for n in ['episodes.csv','prior_validation_episodes.csv','protocol.json','frozen_manifest.json','controller_selection.json','selection.json','runtime_versions.json']:
 p=W/'paper_bench/lans_bench/bench_results'/n
 if p.exists():shutil.copy(p,R/'sources'/n)
for n in ['timing_samples.csv','timing_environment.json']:shutil.copy(W/'upload'/n,R/'sources'/('windows_'+n))
d=pd.read_csv(R/'sources/windows_timing_samples.csv');rows=[]
for method,g in d.groupby('method'):
 x=g.decision_ms
 rows.append(dict(method=method,n=len(x),mean_ms=x.mean(),sd_ms=x.std(),p95_ms=x.quantile(.95),p99_ms=x.quantile(.99),max_ms=x.max()))
pd.DataFrame(rows).to_csv(T/'windows_timing_summary.csv',index=False)
ep=pd.read_csv(R/'sources/episodes.csv');main=pd.read_csv(T/'legacy_01_controller_ablation.csv')
labels={'full':'LANS','zero':'Residual off','mpc':'MPC','lqr_feedback':'LQR','lqr_feedforward':'LQR + FF','no_fallback':'No fallback','no_arrival_prediction':'No arrival prediction','no_latency_gain':'No age gain','no_cost_gate':'No cost gate'}
# architecture, no invented fast fallback path
fig,ax=plt.subplots(figsize=(7.3,4.5));ax.set(xlim=(-.6,10),ylim=(0,7));ax.axis('off')
boxes={'s':(0.2,5.6,2.3,.9,'Timestamped pose\nApplied steering'),'o':(3.2,5.6,2.8,.9,'Causal observer\n+ arrival prediction'),'a':(7,5.6,2.7,.9,'Local analytical\nsteering'),'p':(.2,3.1,2.3,.9,'PPO residual\nremote channel'),'m':(3.2,3.1,2.8,.9,'Newest packet + age\nattenuation / expiry'),'g':(7,3.1,2.7,.9,'Cost gate +\nruntime recovery'),'q':(7,.5,2.7,.9,'Command transport\nActuator lag / rate\nSteering saturation'),'v':(3.2,.5,2.8,.9,'Kinematic plant\n+ disturbances')}
for key,(x,y,w,h,txt) in boxes.items():
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.06',fc='#f0f4f7',ec='#314b63',lw=1));ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=9)
def ar(a,b):ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',color='#314b63',lw=1.1))
ar((2.5,6.05),(3.2,6.05));ar((6,6.05),(7,6.05));ar((2.5,3.55),(3.2,3.55));ar((6,3.55),(7,3.55));ar((8.35,5.6),(8.35,4));ar((8.35,3.1),(8.35,1.4));ar((7,.95),(6,.95));ar((4.6,5.6),(1.35,4));ax.plot([3.2,-.3,-.3],[.95,.95,6.05],color='#314b63',lw=1.1);ar((-.3,6.05),(.2,6.05));ax.text(4.7,2.3,'Every selected command, including recovery,\npasses through the same physical actuator path.',ha='center',fontsize=9)
save('fig01_architecture')
# tracking stress by profile
order=['nominal','actuator','sensor','gain_step','noise_burst','combined','full_command_delay'];p=pd.read_csv(T/'legacy_02_stress_profiles.csv')
fig,axs=plt.subplots(2,1,figsize=(6.8,5),sharex=True)
for m in ['full','zero','mpc']:
 z=p[p.method==m].set_index('profile').loc[order];axs[0].plot(range(7),z.rmse_mean_m,'o-',label=labels[m]);axs[1].plot(range(7),z.survival_percent,'o-')
axs[0].set_ylabel('Mean RMSE (m)');axs[0].legend(ncol=3,fontsize=8);axs[1].set_ylabel('Survival (%)');axs[1].set_xticks(range(7),['Nominal','Actuator','Sensor','Gain step','Noise','Combined','Command'],rotation=25);axs[1].set_ylim(0,105);fig.tight_layout();save('fig02_profiles')
fig,axs=plt.subplots(1,2,figsize=(7,3.3));sel=['full','zero','mpc','no_latency_gain','no_cost_gate','no_fallback','no_arrival_prediction'];z=main.set_index('method').loc[sel]
for ax,col,title in zip(axs,['rmse_mean_m','penalized_rmse_mean_m'],['Observed RMSE (m)','Failure-penalized RMSE (m)']):
 ax.barh(range(len(sel)),z[col],color=['#215a82']+['#8899a6']*6);ax.set_yticks(range(len(sel)),[labels[x] for x in sel]);ax.invert_yaxis();ax.set_xlabel(title)
fig.tight_layout();save('fig03_ablation')
# matched timing tails
fig,ax=plt.subplots(figsize=(6,3.4))
for m in ['full','zero','mpc','lqr_feedback','ppo_reuse']:
 x=np.sort(d[d.method==m].decision_ms.to_numpy());ax.plot(x,1-np.arange(1,len(x)+1)/len(x),label=labels.get(m,'Reused residual policy'))
ax.set_yscale('log');ax.set_ylim(1e-4,1);ax.set_xlabel('Prepared-state decision time (ms)');ax.set_ylabel('Empirical exceedance fraction');ax.legend(fontsize=7);fig.tight_layout();save('fig04_timing')
# energy raw series
pow=pd.read_csv(W/'energy_results/power_samples_clean.csv');runs=pd.read_csv(W/'energy_results/workload_energy.csv');base=pow.timestamp_unix_ns.iloc[0]
fig,axs=plt.subplots(2,1,figsize=(7,4.6),gridspec_kw={'height_ratios':[1.5,1]});axs[0].plot((pow.timestamp_unix_ns-base)/6e10,pow.cpu_package_power_w,lw=.7,color='#444444')
colors={'full':'#215a82','zero':'#cc873b','mpc':'#49927c'}
for r in runs.to_dict('records'):axs[0].axvspan((r['start_unix_ns']-base)/6e10,(r['end_unix_ns']-base)/6e10,color=colors[r['method']],alpha=.15)
axs[0].set(xlabel='Session time (min)',ylabel='CPU-package power (W)')
for i,m in enumerate(['full','zero','mpc']):
 x=runs[runs.method==m].cpu_package_mean_w;axs[1].scatter(np.full(3,i),x,color=colors[m]);axs[1].errorbar(i,x.mean(),yerr=x.std(),fmt='_',color='black',capsize=4)
axs[1].set_xticks(range(3),['LANS','Residual off','MPC']);axs[1].set_ylabel('Run mean power (W)');fig.tight_layout();save('fig05_energy')
# reward seed differences
z=pd.read_csv(T/'legacy_06_reward_seed_effect.csv');fig,ax=plt.subplots(figsize=(3.5,2.1));ax.bar(z.train_seed.astype(str),z.rmse_difference_m*1000,color='#215a82');ax.axhline(0,color='black',lw=.6);ax.set(xlabel='Training seed',ylabel='RMSE difference (mm)');fig.tight_layout();save('fig06_reward')
# raw trajectory fixed seed and stress chosen a priori
case=ep[(ep.eval_seed==3200)&(ep.path=='dlc')&(ep.profile=='combined')&(((ep.method=='full')&(ep.train_seed==42))|ep.method.isin(['mpc','zero']))]
ids=set(case.case_id);chunks=[]
for pth in (W/'paper_bench/lans_bench/bench_results').glob('*_traces.csv.gz'):
 for chunk in pd.read_csv(pth,chunksize=100000):
  z=chunk[chunk.case_id.isin(ids)]
  if len(z):chunks.append(z)
z=pd.concat(chunks);z.to_csv(T/'example_trace.csv',index=False)
fig,axs=plt.subplots(2,1,figsize=(6.5,4),sharex=True)
for r in case.to_dict('records'):
 q=z[z.case_id==r['case_id']].sort_values('tick');axs[0].plot((q.tick+1)*.01,q.error_m,label=labels[r['method']]);axs[1].plot((q.tick+1)*.01,q.actual_rad)
axs[0].legend(ncol=3,fontsize=8);axs[0].set_ylabel('Lateral error (m)');axs[1].set(xlabel='Simulation time (s)',ylabel='Applied steering (rad)');fig.tight_layout();save('fig07_trace')
# actuator simulation
resp=pd.read_csv(T/'response_01_response_cases.csv');z=resp[resp.method=='full'];fig,ax=plt.subplots(figsize=(6,3))
for step,g in z.groupby('step'):
 a=g.groupby('profile').response_95_percent_ms.mean().reindex(order);ax.plot(range(7),a,'o-',label=str(step))
ax.set_xticks(range(7),['Nominal','Actuator','Sensor','Gain step','Noise','Combined','Command'],rotation=25);ax.set_ylabel('Simulated 95% response (ms)');ax.legend(fontsize=7);fig.tight_layout();save('fig08_response')
# paired physical-cell bootstrap descriptive fixed suite
full=ep[ep.method=='full'].groupby(['eval_seed','path','profile']).rmse_m.mean();zero=ep[ep.method=='zero'].set_index(['eval_seed','path','profile']).rmse_m;delta=(full-zero).to_numpy();rng=np.random.default_rng(20261005);boot=np.mean(rng.choice(delta,(10000,len(delta))),axis=1)
pd.DataFrame([{'comparison':'LANS mean over 3 policies minus zero residual','physical_cells':len(delta),'mean_difference_m':delta.mean(),'bootstrap_percentile_2_5_m':np.quantile(boot,.025),'bootstrap_percentile_97_5_m':np.quantile(boot,.975),'scope':'Exploratory physical-cell resampling conditional on fixed policies/profiles; cells are not independent training runs'}]).to_csv(T/'paired_cell_bootstrap.csv',index=False)
# finite-sample tabulations only
paths=pd.read_csv(T/'legacy_04_trajectories.csv');paths[paths.method.isin(['full','zero','mpc'])].to_csv(T/'selected_paths.csv',index=False)
print('Figures',len(list(F.glob('*.png'))));print(pd.read_csv(T/'paired_cell_bootstrap.csv').to_string(index=False))
print(resp.groupby('profile').response_95_percent_ms.agg(['mean','max']).to_string())
