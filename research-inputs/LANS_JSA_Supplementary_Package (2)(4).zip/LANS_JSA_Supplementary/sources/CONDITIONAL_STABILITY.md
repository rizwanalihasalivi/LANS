# Conditional stability result — not a full LANS safety proof

## Precisely defined model
Let x=[e_y,e_psi]^T, v=25 m/s, dt=0.01 s and L=2.6 m. For a straight reference, the linearized error dynamics are x_(k+1)=A x_k+B u_k, with A=[[1,v dt],[0,1]] and B=[0,v dt/L]^T. Let K be the discrete LQR gain from Q=diag(1,4), R=10. The selected analytical gain is 0.25 K and the steering-feedback coefficient is 0.5.

Assume perfect state knowledge, unit plant gain, no disturbance/bias, zero sensor and actuator command delay, instantaneous actuator response, no steering-rate limit, straight reference, and a fixed analytical mode (no switching/fallback). The modeled command is u_k=-1.5(0.25K)x_k-0.5u_(k-1)+d_k. d_k denotes a bounded additive correction at this command stage, not an assumed property of all internal PPO signals.

For z_k=[x_k^T,u_(k-1)]^T, define C=[-1.5(0.25K),-0.5], G=[B^T,1]^T and F=diag(A,0)+G C. Then z_(k+1)=F z_k+G d_k.

## Nominal theorem and proof
If F is Schur, the discrete Lyapunov equation F^T P F-P=-I has a unique P>0. Set V(z)=z^T P z. For d=0, V(z_(k+1))-V(z_k)=-||z_k||^2, hence the origin of THIS reduced model is exponentially stable. More explicitly V_(k+1) <= (1-1/lambda_max(P))V_k.

The included script constructs this F, calculates P, checks its positive eigenvalues and the Lyapunov-equation residual, and records the spectral radius. These are floating-point numerical checks of an analytical theorem, not a machine-checked or interval-arithmetic certificate for the software implementation.

## Bounded residual: practical stability, not convergence to zero
For |d_k|<=d_bar, expand:
Delta V=-||z||^2+2 z^T F^T P G d+d^2 G^T P G.
Using 2ab<=a^2/2+2b^2 gives
Delta V <= -0.5||z||^2+beta d_bar^2,
where beta=2||F^T P G||^2+G^T P G.
Thus V_(k+1)<=(1-alpha)V_k+beta d_bar^2, alpha=1/(2 lambda_max(P)). Iteration yields
V_k <= (1-alpha)^k V_0 + (beta d_bar^2/alpha)[1-(1-alpha)^k].
A nonzero bounded residual supports an ultimate bound; it does NOT imply convergence to zero.

## Conditional invariant ellipsoid for the reduced model
On E_rho={z:z^T P z<=rho}, |Cz|<=sqrt(rho C P^-1 C^T). If this plus d_bar is <=0.5 rad, command saturation is inactive. For any selector q, |qz|<=sqrt(rho q P^-1 q^T). We use 0.30 m and 0.06 rad only as illustrative engineering envelope bounds, not physical road/collision constraints.

Choose rho no greater than the saturation and state-envelope bounds in nominal_bounds.csv. If beta*d_bar^2/alpha<=rho, then E_rho is invariant for this reduced uncertain-input model by the V inequality and induction. If this sufficient condition fails, this calculation establishes no invariant ellipsoid at that rho; it does not prove instability.

## What remains unproved
The deployed system has an estimated state, nonlinear trigonometric dynamics, biased/time-varying plant gain, reference curvature, delayed packets, actuator lag/rate/saturation, finite queues and supervisor switching. Those invalidate the reduced-model assumptions. In particular the full supervisor may switch even inside an illustrative bound; no reachability relation to its inherited 4-state V_MAX threshold has been established here.

A full claim would require a state including observer error, actuator and queues; explicit admissible delay/noise/disturbance/curvature bounds; a common or mode-dependent Lyapunov/Lyapunov–Krasovskii argument; safe-set invariance under all modes; and a feasible recovery action under identical physical delays. None follows from this nominal theorem or from finite simulation survival. The inherited diagnostic P_LQR/V_MAX is not replaced by the 3-state P and is not retrospectively certified.

Paper wording: “We provide a conditional stability analysis for a reduced nominal linear mode and evaluate the complete controller empirically. No formal safety guarantee is claimed for the nonlinear delayed switching implementation.”
