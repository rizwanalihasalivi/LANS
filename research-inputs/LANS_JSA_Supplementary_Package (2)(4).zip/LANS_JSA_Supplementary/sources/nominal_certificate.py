"""Reproducible conditional certificate for an explicitly reduced linear mode."""
from pathlib import Path
import json,csv
import numpy as np
from scipy.linalg import solve_discrete_are,solve_discrete_lyapunov
R=Path('completion_results/theory');R.mkdir(parents=True,exist_ok=True)
v,dt,L=25.,.01,2.6
A=np.array([[1.,v*dt],[0.,1.]]);B=np.array([[0.],[v*dt/L]])
S=solve_discrete_are(A,B,np.diag([1.,4.]),np.array([[10.]]))
K=np.linalg.solve(np.array([[10.]])+B.T@S@B,B.T@S@A).ravel()
C=np.r_[-1.5*.25*K,-.5].reshape(1,3)
F=np.zeros((3,3));F[:2,:2]=A;G=np.r_[B.ravel(),1.].reshape(3,1);F+=G@C
P=solve_discrete_lyapunov(F.T,np.eye(3));res=F.T@P@F-P+np.eye(3)
assert np.max(abs(np.linalg.eigvals(F)))<1
assert np.linalg.eigvalsh(P).min()>0
assert abs(res).max()<1e-10
alpha=1/(2*np.linalg.eigvalsh(P).max());h=F.T@P@G;beta=2*float((h.T@h).item())+float((G.T@P@G).item())
Pinv=np.linalg.inv(P);cpc=float((C@Pinv@C.T).item())
# Engineering envelope for the reduced model only; these are not road boundaries.
selectors=[np.array([[1.,0.,0.]]),np.array([[0.,1.,0.]])]
bounds=[.30,.06]
rho_state=min(b*b/float((q@Pinv@q.T).item()) for q,b in zip(selectors,bounds))
rows=[]
for d in [0.,.001,.01,.03]:
 rho_sat=(.5-d)**2/cpc;rho=min(rho_sat,rho_state);ultimate=beta*d*d/alpha
 rows.append(dict(residual_bound_rad=d,rho_saturation=rho_sat,rho_state_envelope=rho_state,rho_candidate=rho,ultimate_V_bound=ultimate,sufficient_invariance_condition=bool(ultimate<=rho)))
data=dict(A=A.tolist(),B=B.tolist(),K=K.tolist(),C=C.tolist(),F=F.tolist(),G=G.tolist(),P=P.tolist(),eigenvalues_F=[[float(x.real),float(x.imag)] for x in np.linalg.eigvals(F)],spectral_radius=float(max(abs(np.linalg.eigvals(F)))),min_eigenvalue_P=float(np.linalg.eigvalsh(P).min()),lyapunov_residual_max=float(abs(res).max()),alpha=alpha,beta=beta,scope='Reduced linear straight-path perfect-state zero-delay no-actuator-lag fixed-analytical-mode model; NOT full LANS switching/observer certificate')
(R/'nominal_certificate.json').write_text(json.dumps(data,indent=2))
with (R/'nominal_bounds.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print(json.dumps(data,indent=2));print(rows)
