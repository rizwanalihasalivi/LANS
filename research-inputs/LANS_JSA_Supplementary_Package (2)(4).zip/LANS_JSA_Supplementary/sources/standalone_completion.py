"""Independent full-authority PPO; remote and physical channels preserved."""
import sys,json,csv,gzip,time,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv,VecNormalize
from stable_baselines3.common.logger import configure
from scripts.paper_env import BenchEnv
from scripts.stress_env import PROFILES
PLACEMENT='remote'
R=Path('completion_results/remote')
class StandaloneEnv(BenchEnv):
 def __init__(self,**kw):
  super().__init__(variant='ppo_reuse',**kw)
  self.residual_scale=.5
  if PLACEMENT=='local':
   c=self.framework_controller;original=c.step
   def local_step(x_k,ppo_residual,delay_ms=0.,gain_context=1.,kappa_k=0.,predictor=None):
    _,info=original(x_k,0.,delay_ms,gain_context,kappa_k,predictor)
    u=float(np.clip(ppo_residual,-.5,.5));c.last_u=u
    info.update(u_k=u,u_c=u,u_q=u,fallback_used=False,recovery_used=False,recovery_unresolved=False,remote_residual_accepted=0.)
    return u,info
   c.step=local_step
 def _mask(self,obs):
  obs=obs.copy();obs[12:15]=0.
  if PLACEMENT=='local':obs[11]=0.;obs[20:25]=0.;obs[31:34]=0.
  return obs
 def reset(self,**kw):
  o,i=super().reset(**kw);return self._mask(o),i
 def step(self,a):
  o,r,t,tr,i=super().step(a)
  return self._mask(o),r,t,tr,i

def main():
 R.mkdir(parents=True,exist_ok=True)
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 cfg=dict(learning_rate=3e-4,n_steps=2048,batch_size=256,n_epochs=10,gamma=.995,gae_lambda=.97,ent_coef=0.,clip_range=.2,target_kl=.03,policy_kwargs=dict(net_arch=[64,64],log_std_init=-1.5))
 protocol=dict(placement=PLACEMENT,seeds=[42,43,44],requested_steps=50000,actual_steps=51200,action='normalized [-1,1] maps to full steering [-.5,.5] rad; NOT residual policy reuse',observations='37 shared measured/estimated features; LQR/feedforward/fallback slots12:15 masked to zero',transport=('same remote delay/outage and 200ms expiry, no age attenuation' if PLACEMENT=='remote' else 'local policy, no remote delivery path; same physical actuator/sensor delay; computational execution time not injected'),training_budget='matched 50k pilot budget, not a fully tuned PPO performance ceiling',test_seeds=[3200,3201],paths=['dlc','sine_noise_test','chirp_noise_test'],config=cfg)
 (R/'standalone_protocol.json').write_text(json.dumps(protocol,indent=2))
 for seed in protocol['seeds']:
  base=R/f'standalone_seed{seed}'
  if base.with_suffix('.zip').exists():raise RuntimeError('Refuse model overwrite')
  v=VecNormalize(DummyVecEnv([lambda:StandaloneEnv(path='train',random_profiles=True,risk_reward=True,reward_mode='tracking')]),norm_obs=True,norm_reward=True,clip_obs=10,clip_reward=10,gamma=.995)
  m=PPO('MlpPolicy',v,seed=seed,device='cpu',verbose=0,**cfg)
  with torch.no_grad():m.policy.action_net.weight.zero_();m.policy.action_net.bias.zero_()
  m.set_logger(configure(str(R/f'train_seed{seed}'),['csv']))
  start=time.time();m.learn(total_timesteps=50000);m.save(base);v.save(str(base)+'_norm.pkl');v.training=False;v.norm_reward=False
  print('TRAINED',seed,m.num_timesteps,round(time.time()-start),flush=True)
  with (R/f'episodes_seed{seed}.csv').open('w',newline='') as f,gzip.open(R/f'traces_seed{seed}.csv.gz','wt',newline='') as tf:
   w=None;tw=csv.writer(tf);tw.writerow(['train_seed','eval_seed','path','profile','tick','error_m','command_rad','actual_rad','remote_age_steps'])
   for es in protocol['test_seeds']:
    for path in protocol['paths']:
     for profile in PROFILES:
      e=StandaloneEnv(path=path,profile=profile,heldout=True);o,_=e.reset(seed=es);errors=[float(e.state[0])];ih=float(e.state[2])
      for tick in range(1000):
       a=m.predict(v.normalize_obs(o[None,:]),deterministic=True)[0][0]
       o,_,t,tr,i=e.step(a);errors.append(float(i['error']))
       tw.writerow([seed,es,path,profile,tick,i['error'],i['u_k'],e.actual_delta,e.framework_controller.remote.last_age_steps])
       if t or tr:break
      n=len(errors)-1;sq=sum(x*x for x in errors)
      row=dict(method='standalone_ppo_'+PLACEMENT,train_seed=seed,eval_seed=es,path=path,profile=profile,steps=n,survived=not t,rmse_m=np.sqrt(sq/(n+1)),max_error_m=max(abs(x) for x in errors),failure_penalized_rmse_m=np.sqrt((sq+(1000-n)*max(2.5,abs(errors[-1]))**2)/1001),initial_error_m=errors[0],initial_heading_rad=ih,command_delay_ms=e.settings['command_ms'],actuator_tau_s=e.settings['tau'],actuator_rate_rad_s=e.settings['rate'],sensor_delay_ms=e.settings['sensor_ms'])
      if w is None:w=csv.DictWriter(f,fieldnames=row);w.writeheader()
      w.writerow(row);f.flush();e.close()
    print('EVALUATED',seed,es,flush=True)
  v.close()
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--placement',choices=['local','remote'],required=True);args=parser.parse_args()
 PLACEMENT=args.placement;R=Path('completion_results')/PLACEMENT
 main()
