import numpy as np
import pytest
from integrations.unified_lans.physics import Command,Route,Config,advance,baseline
from integrations.unified_lans.traffic import Packet
from integrations.unified_lans.controller import Proposal
from tools.unified_campaign.study import Clock
from tools.unified_control_v4.control import Controller,ScheduledLQR


def test_unmodified_gain_matches_original_at_exact_scheduled_speed():
    z=np.array([0.,.2,.01,12.,.02,.01]);route=Route('sine')
    assert ScheduledLQR(1.)(z,route)==pytest.approx(baseline(z,route),abs=1e-12)


def test_prediction_rejects_corridor_violation_even_without_traffic():
    pipe=Controller(Route(),penalty=16.,clock=Clock())
    z=np.array([0.,2.,0.,12.,0.,0.])
    value,margin=pipe.cost(z,Command(),0.,0.,(),.5)
    assert np.isfinite(value) and margin<0


def test_model_identification_uses_measurements_and_actual_commands():
    pipe=Controller(Route(),penalty=16.,adaptive=True,clock=Clock())
    z=np.array([0.,.1,0.,12.,0.,0.]);true_stiffness=.8
    for i in range(30):
        now=i*.05;pipe.inbox.ingest(Packet('ego',i,now,tuple(z)),now);pipe.update_model()
        # An externally specified applied command excites the identifiable dynamics.
        u=Command(.02*np.sin(i*.2),0.);pipe.pending.append((now,u));z=pipe.apply(now,z,true_stiffness)
    assert abs(pipe.stiffness_estimate-true_stiffness)<.05


def test_ego_blackout_keeps_source_age_and_disables_ppo_while_braking():
    clock=Clock();pipe=Controller(Route('sine'),penalty=16.,adaptive=True,clock=clock)
    z=np.array([0.,.2,0.,12.,0.,0.])
    for i in range(55):
        now=i*.05;clock.now=now
        if i<4:pipe.inbox.ingest(Packet('ego',i,now,tuple(z)),now)
        decision=pipe.decide(now);z=pipe.apply(now,z,.8)
        if now>.4:
            assert decision['source'] in ('backup_lqr','hold_brake')
            assert decision['issued_accel']==-6. and pipe.features(now) is None
            assert decision['ego_age']==pytest.approx(now-.15)
    assert z[3]==0.


def test_no_history_is_not_fabricated_into_a_measurement():
    clock=Clock(.5);pipe=Controller(Route(),clock=clock)
    z=(0.,0.,0.,12.,0.,0.)
    pipe.inbox.ingest(Packet('ego',0,0.,z),0.)
    assert pipe.reconstruct(.5) is None
    d=pipe.decide(.5);assert d['source']=='hold_brake' and d['issued_accel']==-6.
