from functools import lru_cache
import math
import numpy as np
from scipy.linalg import solve_continuous_are
from models.bicycle_model import VEHICLE_PARAMS,get_error_state_model
from integrations.unified_lans.physics import Command,advance,constrain,errors
from integrations.unified_lans.controller import Pipeline
from integrations.unified_lans.traffic import Supervisor,extrapolate


@lru_cache(maxsize=1024)
def gain(speed,penalty):
    a,b=get_error_state_model(speed,VEHICLE_PARAMS)
    p=solve_continuous_are(a,b,np.diag([1.,.1,1.,.1]),np.array([[penalty]]))
    return (b.T@p/penalty).ravel()


class ScheduledLQR:
    def __init__(self,penalty=1.):self.penalty=float(penalty)
    def __call__(self,state,route):
        v=max(2.,float(state[3]));scheduled=max(2.,round(v*2)/2)
        e,k=errors(state,route);p=VEHICLE_PARAMS;l=p['lf']+p['lr']
        vy=(p['lr']*v-p['m']*p['lf']*v**3/(l*p['Cr']))*k
        target=np.array([0.,0.,-vy/v,0.])
        feedforward=(l+p['m']/l*(p['lr']/p['Cf']-p['lf']/p['Cr'])*v*v)*k
        return float(np.clip(feedforward-gain(scheduled,self.penalty)@(e-target),-.5,.5))


class StopSupervisor(Supervisor):
    def __init__(self,cfg,scenario):super().__init__(cfg,scenario);self.force_stop=False
    def assess(self,*args,**kwargs):
        risk=super().assess(*args,**kwargs)
        if self.force_stop:risk.state='DANGER';self.state='DANGER'
        return risk


class Controller(Pipeline):
    """Same limits/TTLs; bounded dead reckoning is for braking, never PPO admission."""
    def __init__(self,*args,penalty=1.,adaptive=False,corridor=True,backup=True,**kwargs):
        self.stiffness_estimate=1.;self.adaptive=adaptive;self.corridor=corridor;self.backup=backup
        self.backup_limit_s=2.5;self._previous_measurement=None;self._num=0.;self._den=0.
        super().__init__(*args,baseline_fn=ScheduledLQR(penalty),predict_fn=self.predict,**kwargs)
        self.supervisor=StopSupervisor(self.cfg,self.supervisor.scenario)

    def predict(self,z,command,dt):
        return advance(z,command,dt,self.stiffness_estimate if self.adaptive else 1.)

    def update_model(self):
        current=self.inbox.latest.get('ego');old=self._previous_measurement
        if current is None or old is not None and current.sequence==old.sequence:return
        self._previous_measurement=current
        if not self.adaptive or old is None:return
        dt=current.observed_s-old.observed_s
        if abs(dt-self.cfg.dt)>1e-8:return
        commands=[c for start,end,c in self.history if abs(start-old.observed_s)<1e-8 and abs(end-current.observed_s)<1e-8]
        if len(commands)!=1:return
        a=np.array(old.state);b=np.array(current.state);mid=(a+b)/2;v,vy,r=mid[3:]
        if v<2.:return
        p=VEHICLE_PARAMS;u=commands[0].steering
        front=p['Cf']*(u-(vy+p['lf']*r)/v);rear=p['Cr']*(-(vy-p['lr']*r)/v)
        h=np.array([(front+rear)/p['m'],(p['lf']*front-p['lr']*rear)/p['Iz']])
        y=np.array([(b[4]-a[4])/dt+v*r,(b[5]-a[5])/dt])
        if float(h@h)<.01:return
        self._num=.98*self._num+float(h@y);self._den=.98*self._den+float(h@h)
        self.stiffness_estimate=float(np.clip(self._num/self._den,.7,1.3))

    def reconstruct(self,now):
        packet=self.inbox.latest.get('ego')
        if packet is None:return None
        age=now-packet.observed_s
        limit=self.backup_limit_s if self.backup else self.cfg.ego_ttl
        if age>limit+1e-9:return None
        z=np.array(packet.state);cursor=packet.observed_s
        for start,end,command in self.history:
            if end<=cursor+1e-10:continue
            if start>cursor+1e-8:return None
            until=min(end,now)
            if until>cursor:z=self.predict(z,command,until-cursor);cursor=until
            if cursor>=now-1e-9:break
        return z if cursor>=now-1e-8 else None

    def features(self,now,busy=False):
        p=self.inbox.latest.get('ego')
        if p is None or now-p.observed_s>self.cfg.ego_ttl+1e-9:return None
        return super().features(now,busy)

    def cost(self,z,first,residual,accel,vehicles,lifetime):
        previous=self.issued;total=0.;minimum=math.inf;cfg=self.cfg
        for i in range(math.ceil(cfg.horizon/cfg.dt)):
            # Only the first receding-horizon command is committed. Do not
            # pretend a freshly reselected correction is held for 500 ms.
            active=residual if i==0 and lifetime>0 else 0.
            command=first if i==0 else constrain(Command(self.baseline_fn(z,self.route)+active,accel),previous,cfg)
            z=self.predict(z,command,cfg.dt);e,_=errors(z,self.route)
            total+=cfg.dt*(8*e[0]**2+2*e[2]**2+.03*command.steering**2+.02*((command.steering-previous.steering)/cfg.dt)**2)
            if self.corridor:minimum=min(minimum,1.75-abs(float(e[0])))
            for _,other,uncertainty in vehicles:
                n=extrapolate(other,(i+1)*cfg.dt)
                minimum=min(minimum,float(np.linalg.norm(n[:2]-z[:2])-2*cfg.vehicle_radius-cfg.buffer-uncertainty-cfg.uncertainty_rate*(i+1)*cfg.dt))
            previous=command
        return float(total),minimum

    def decide(self,now,worker_failed=False):
        self.update_model();p=self.inbox.latest.get('ego')
        stale=p is None or now-p.observed_s>self.cfg.ego_ttl+1e-9
        self.supervisor.force_stop=stale
        result=super().decide(now,worker_failed=worker_failed or stale)
        if stale and result['source']!='hold_brake':
            result['source']='backup_lqr';result['reason']='bounded_dead_reckoning_brake'
        result.update(stiffness_estimate=self.stiffness_estimate,ego_backup=stale,
                      estimate_age=now-p.observed_s if p else None)
        return result

    def apply(self,now,state,stiffness=1.):
        history=self.history.copy();result=super().apply(now,state,stiffness)
        history.append(self.history[-1]);self.history=[x for x in history if x[1]>=now-self.backup_limit_s-self.cfg.ego_ttl]
        return result
