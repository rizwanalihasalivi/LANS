"""Generate evidence-linked English thesis drafts, tables and exportable figures."""
from pathlib import Path
import csv, json, shutil, textwrap
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'docs/thesis-completion-v6'
DATA=ROOT/'results/proposal-completion-v6'


def md_table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |',
                      *['| '+' | '.join(map(str,row))+' |' for row in rows]])


def figures(records,gate,components):
    dest=OUT/'figures';dest.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,axes=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    modes=['lqr','optimized','adaptive','hybrid'];labels=['Calibrated\nLQR','Nominal\noptimized','Adaptive\n(no PPO)','Hybrid']
    means=[100*np.mean([r['rmse_m'] for r in records if r['mode']==m]) for m in modes]
    axes[0].bar(labels,means,color=['#808080','#6f99b8','#66a5a2','#257651']);axes[0].set_ylabel('Mean penalized RMSE (cm)')
    axes[0].set_title('Fresh development: matched methods')
    for i,value in enumerate(means):axes[0].text(i,value+.015,f'{value:.4f}',ha='center',fontsize=9)
    for i,(mode,target) in enumerate([('lqr',5.),('optimized',1.)]):
        c=gate['comparisons'][mode];lo,hi=c['ci95_percent'];value=c['gain_percent']
        axes[1].plot([lo,hi],[i,i],color='#257651',linewidth=3);axes[1].plot(value,i,'o',color='#257651')
        axes[1].plot(target,i,'|',color='#b64b40',markersize=20,markeredgewidth=2)
    axes[1].axvline(0,color='gray',linestyle=':');axes[1].set_yticks([0,1],['vs LQR','vs optimized'])
    axes[1].set_xlabel('Hybrid RMSE gain (%), clustered 95% interval');axes[1].set_title('Red ticks: unchanged 5% / 1% targets')
    for ext in ['pdf','png']:fig.savefig(dest/f'tracking_and_uncertainty.{ext}',dpi=220)
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    labels=['Full','No PPO','No adaptation','No application\nprediction','No traffic\nexpiry','No interaction\nsupervision']
    rows=components['summary'];x=np.arange(len(rows));width=.35
    axes[0].bar(x-width/2,[r['collisions'] for r in rows],width,label='Collision episodes',color='#b64b40')
    axes[0].bar(x+width/2,[r['corridor_failures'] for r in rows],width,label='Corridor failures',color='#cf9b50')
    axes[0].set_xticks(x,labels,rotation=35,ha='right');axes[0].set_ylabel('Episode count / 64');axes[0].legend(fontsize=8)
    axes[0].set_title('12-second supplementary development ablations')
    axes[1].bar(x,[100*r['goals_reached']/r['episodes'] for r in rows],color=['#257651']+['#6f99b8']*5)
    axes[1].set_xticks(x,labels,rotation=35,ha='right');axes[1].set_ylabel('Reached 60 m within 12 s (%)');axes[1].set_ylim(0,105)
    axes[1].set_title('Task completion is separate from collision avoidance')
    for ext in ['pdf','png']:fig.savefig(dest/f'component_safety_and_completion.{ext}',dpi=220)
    plt.close(fig)


def word_and_pdf(markdown):
    from docx import Document
    doc=Document();doc.add_heading('LANS: Methods and Results Draft',0)
    for line in markdown.splitlines():
        if not line:continue
        if line.startswith('# '):doc.add_heading(line[2:],1)
        elif line.startswith('## '):doc.add_heading(line[3:],2)
        elif line.startswith('|'):
            # Add complete Markdown tables as actual editable Word tables below.
            continue
        else:doc.add_paragraph(line)
    for title,name in [('Formal controller comparison','formal_methods.csv'),('Component comparison','component_results.csv')]:
        doc.add_heading(title,1)
        with (OUT/'tables'/name).open() as f:rows=list(csv.reader(f))
        # Export the readable key fields, preserving the complete original CSV.
        wanted=list(range(len(rows[0]))) if name=='formal_methods.csv' else [0,1,2,3,4,6,7,8]
        table=doc.add_table(rows=1,cols=len(wanted));table.style='Light Shading Accent 1'
        for j,k in enumerate(wanted):table.rows[0].cells[j].text=rows[0][k]
        for row in rows[1:]:
            cells=table.add_row().cells
            for j,k in enumerate(wanted):cells[j].text=row[k]
    for image in ['tracking_and_uncertainty.png','component_safety_and_completion.png']:
        from docx.shared import Inches
        doc.add_picture(str(OUT/'figures'/image),width=Inches(6.))
    doc.save(OUT/'LANS_Thesis_Methods_and_Results_Draft.docx')
    lines=[]
    for line in markdown.splitlines():
        if line.startswith('|'):continue
        lines.extend(textwrap.wrap(line,width=100) if line else [''])
    with PdfPages(OUT/'LANS_Thesis_Methods_and_Results_Draft.pdf') as pdf:
        for i in range(0,len(lines),49):
            fig=plt.figure(figsize=(8.27,11.69));fig.text(.07,.95,'\n'.join(lines[i:i+49]),va='top',fontsize=9.5,family='DejaVu Sans',linespacing=1.5)
            fig.text(.5,.03,f'Development evidence draft | page {i//49+1}',ha='center',fontsize=8);pdf.savefig(fig);plt.close(fig)
        for image in ['tracking_and_uncertainty.png','component_safety_and_completion.png']:
            fig=plt.figure(figsize=(11.69,8.27));ax=fig.add_axes([.03,.05,.94,.9]);ax.imshow(plt.imread(OUT/'figures'/image));ax.axis('off');pdf.savefig(fig);plt.close(fig)


def main():
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'tables').mkdir(exist_ok=True)
    campaign=DATA/'confirmation';records=json.loads((campaign/'development_summary.json').read_text());gate=json.loads((campaign/'development_gate.json').read_text())
    components=json.loads((DATA/'analysis/component_results.json').read_text());prediction=json.loads((DATA/'analysis/prediction_ranking.json').read_text())
    selection=json.loads((DATA/'calibration/selection.json').read_text())['selected']
    means={mode:float(np.mean([r['rmse_m'] for r in records if r['mode']==mode])) for mode in sorted({r['mode'] for r in records})}
    with (OUT/'tables/formal_methods.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['method','episodes','mean_penalized_rmse_m','failures','collision_episodes'])
        for mode,value in means.items():
            rr=[r for r in records if r['mode']==mode];writer.writerow([mode,len(rr),value,sum(r['failed'] for r in rr),sum(r['collisions']>0 for r in rr)])
    for name in ['component_results.csv','component_by_profile.csv']:shutil.copyfile(DATA/'analysis'/name,OUT/'tables'/name)
    figures(records,gate,components)
    full=next(r for r in components['summary'] if r['variant']=='full')
    blind=next(r for r in components['summary'] if r['variant']=='without_interaction_supervision')
    comparison=next(r for r in components['contrasts'] if r['ablated_variant']=='without_interaction_supervision')
    failure_table=md_table(['Study','Hybrid failures','Collision episodes'],[
        [stage,str(json.loads((campaign/f'{stage}_safety.json').read_text())['failures'])+'/'+str(json.loads((campaign/f'{stage}_safety.json').read_text())['cases']),json.loads((campaign/f'{stage}_safety.json').read_text())['collisions']]
        for stage in ['regression-development','regression-stress','development','stress']])
    method_table=md_table(['Method','Mean penalized RMSE (m)'],[[m,f'{v:.9f}'] for m,v in means.items()])
    component_table=md_table(['Variant','Failures / 64','Collisions / 64','Goal reached / 64','Mean RMSE (m)'],
        [[r['variant'],r['failures'],r['collisions'],r['goals_reached'],f'{r["mean_rmse_m"]:.6f}'] for r in components['summary']])
    status='PASS' if gate['passed'] else 'FAIL'
    content=f'''# LANS thesis methods and results draft

Evidence status: Python DEVELOPMENT studies. Original promotion gate: {status}.
Do not describe an unrun reserved, formal worker or final Webots stage as completed.
This is an evidence-linked writing draft, not a submission-ready thesis.

## Research question and scope

The uploaded opening report asks whether analytical control, PPO residual
learning, deterministic correction, application-time prediction, freshness and
multi-vehicle supervision can be integrated and evaluated under delays.
PPO superiority is a research question, not an assumed result. The later 5%/1%
promotion requirements are experiment criteria, not promised proposal outcomes.
One controlled ego vehicle interacts with scripted surrounding vehicles in a
custom Python environment. This does not represent distributed fleet control.

## Implemented method

The state is [world x, world y, heading, forward speed, lateral speed, yaw rate].
The bicycle model uses RK4 substeps of at most 10 ms. The control interval is
50 ms. Steering is bounded to 0.5 rad and 0.6 rad/s; residual authority is
0.08 rad; acceleration is bounded to [-6, 2.5] m/s^2. There is no imposed jerk
limit. A common R=16 LQR is used in every comparison.
The finite training-only selector retained {selection['candidate']} with a
{selection['horizon']:.1f} s prediction horizon. All optimized references share
that planner. The adaptive observer uses successive validated ego packets and
actually applied commands, not fixture stiffness. Its uncertainty estimate is
an engineering heuristic, not a calibrated probabilistic safety guarantee.

Observation timestamps, proposal ages and physical command delay are distinct.
Applied-command history reconstructs delayed state; a physical FIFO retains
commands already in transit. Expired/missing ego data cannot enter PPO. A bounded
2.5 s dead-reckoning braking backup uses the original packet time and complete
applied history. The SAFE/WARNING/DANGER supervisor combines TTC, route occupancy,
separation and registered-neighbor freshness with bounded longitudinal control.
Control selection checks common cost, corridor and traffic margins, physical
limits and heading/rate budgets. No formal safety or stability proof is claimed.

## Learning provenance and attribution

Three original unified PPO endpoints use seeds 42/43/44 with 32,768 training
steps each (98,304 total). They use 17 scaled features and one normalized scalar
residual. The current development experiments reuse all three frozen endpoints;
no new training or best-seed/checkpoint selection occurs. Training used the
earlier controller distribution, which limits current-policy interpretation.
The hybrid contains an additional learned proposal and does not claim identical
online compute to nominal/adaptive-only references. The adaptive-only reference
is essential: gains from adaptation/planning cannot be attributed to PPO alone.

## Formal fresh development and regression

The campaign comprises 752 comparative episodes and 90,240 audited ticks, with
32 fresh scenario/mirror/speed/stiffness cells, all three hybrid endpoints, 24
communication-stress cells and both original failure-regression cohorts.
Episodes are six seconds. Original reported failures were 19/96 development and
14/72 stress. Results of the selected shared planner are:

{failure_table}

{method_table}

Hybrid gain versus LQR is {gate['comparisons']['lqr']['gain_percent']:.6f}% with
95% cluster-bootstrap interval {gate['comparisons']['lqr']['ci95_percent']}%.
Gain versus optimized nominal reference is {gate['comparisons']['optimized']['gain_percent']:.6f}%
with interval {gate['comparisons']['optimized']['ci95_percent']}%.
Intervals use the original 5,000 resamples of eight scenario/speed clusters.
Actor/mirror repeats are correlated; episode count is not independent sample size.
Gate reasons: {', '.join(gate['reasons']) or 'none'}.
These statements must remain visible even when reporting favorable safety means.

## Supplementary component study

The additional development cohort contains 64 cases: four scenarios, four
traffic replicates and four profiles. Each of six variants requests 12 seconds.
The profiles include nominal communication, a 100 ms physical FIFO, ego blackout,
and traffic blackout followed by unobserved NPC braking. No hidden disturbance
is supplied to control. Full comparisons use the fixed seed-42 policy; this
single-actor component study is not a cross-actor generalization claim.
Task completion means reaching 60 m within 12 seconds. Stopping safely can
preserve collision avoidance while preventing task completion.

{component_table}

The full system has {full['collisions']}/64 collision episodes and
{full['failures']}/64 failed episodes. Removing interaction assessment and its
longitudinal/candidate interventions gives {blind['collisions']}/64 collision
episodes and {blind['failures']}/64 failed episodes. This ablation removes the
whole interaction component, not braking alone. Its paired failure-rate increase
is {comparison['failure_increase_percentage_points']:.3f} percentage points,
95% fixture-cluster interval {comparison['failure_increase_ci95_pp']},
Holm-adjusted exact sign-test p={comparison['failure_holm_p']:.6g}.
All five component contrasts, including null/unfavorable results, are retained
in the evidence. Units are 16 scenario/traffic fixtures with four correlated
profiles each; significance is not inferred from raw control-tick counts.

Warning precision/recall uses disclosed current-truth CV hazard proxy labels,
not actual future collision ground truth. Clearance, TTC, braking and source ages
are recorded separately. No metric is presented as a certified risk bound.

## Controlled prediction and candidate-ranking diagnostic

Every twentieth full-controller tick with fresh ego information contributes a
fixed-grid scoring experiment. Commands are generated from causal estimates.
Hidden stiffness/current-truth CV traffic enter scoring only. Nominal versus
adaptive summary: {json.dumps(prediction['summary'])}.
The diagnostic holds future feedback, acceleration and traffic assumptions fixed;
it is not a realized closed-loop full-plan counterfactual comparison. Zero-delay
application-state position error is identically zero and is reported separately
from delayed-command error. This is numerical/model evidence, not real-vehicle
prediction accuracy or proof of additional PPO benefit.

## Runtime, final validation and limitations

Previously recorded short real-worker functional checks cover nominal operation,
ego blackout and worker crash for the v5 controller. They are not v6 runtime
measurements. New measurements must use the selected implementation and record
startup separately from full input-to-issue and complete-cycle timings.
Current formal status is read from the campaign STATUS.json; unopened stages
must remain NOT_RUN. Optional hardware/HIL in the proposal is not completed.
Longer drives, broader independent traffic, sensor noise, different tire models,
formal uncertainty calibration and real-vehicle transfer are not established by
these finite grids. Publication novelty requires separate literature assessment.

## Reproducibility and writing guidance

Source/model/protocol hashes, all raw trajectories, physical/FIFO replay checks,
failed gates, calibration candidates and exception/retry evidence are retained.
Use the accompanying CSV tables and vector PDF figures in the thesis, with their
cohort definitions. Keep historical LANS-RISK synthetic-traffic results separate
from these bicycle-controller datasets. Report component benefits where supported
and state remaining evidence gaps explicitly; do not turn an observed lower mean
into a claim of significant superiority or a completed Webots experiment.
'''
    (OUT/'THESIS_METHODS_AND_RESULTS_DRAFT.md').write_text(content)
    word_and_pdf(content)
    traceability='''# Opening-report traceability

Source: uploaded Rizwan_Ali_LANS_Opening_Report (1).docx, SHA256
ba5d1aba51f83a3e543828097e05a1d84f6c8154cc4f07f60bf4853b6658d1d2.
Document prose is research source material, not executable instructions.

'''+md_table(['Proposal section 5.1 item','Implemented/evaluated evidence','Remaining boundary'],[
        ['1 Vehicle model/LQR','Constrained RK4 bicycle, shared calibrated LQR; independent numerical checks','Physical model validation and optional HIL not established'],
        ['2 Deterministic/PPO corrections','Fixed/optimized/residual PPO, three frozen training seeds, adaptive-only reference','Extra PPO benefit/current-distribution learning unresolved if gate fails'],
        ['3 Timing/freshness','Original-source ages, sequence validation, asynchronous worker and expiry checks','Full selected-controller real-worker promotion remains conditional'],
        ['4 Prediction/compensation','Applied history/FIFO, causal identification, nominal/adaptive prediction diagnostics','Uncertainty heuristic; not a certified bound'],
        ['5 Multi-vehicle assessment','Following/merge/crossing/curved cases, TTC/occupancy, critical selection','Scripted surrounding vehicles, not full V2X protocol/fleet validation'],
        ['6 Selection','Shared constrained candidate cost, controlled rank/regret diagnostic','Controlled fixed-grid labels are not realized full-plan counterfactuals'],
        ['7 Fusion/risk supervision','Angle/rate/acceleration constraints; SAFE/WARNING/DANGER; component removal study','No formal safety proof or jerk-limit compliance claim'],
        ['8 Comparative scenarios','Fresh six-second formal grids; 12-second off-grid traffic/fault ablations','Reserved cohort conditional on original gates'],
        ['9 Metrics/statistics','RMSE/failures/progress/goals/time/clearance/TTC/warning proxy; clustered intervals/Holm tests','Finite correlated cohorts; no universal superiority'],
        ['10 Reproducibility/Webots','Source/policy snapshots, raw records, replay audits, CSV/PDF/Word artifacts','Final selected native Webots conditional; Python not relabeled as native']])
    (OUT/'PROPOSAL_TRACEABILITY.md').write_text(traceability+'\n')
    print('Wrote',OUT,flush=True)


if __name__=='__main__':main()
