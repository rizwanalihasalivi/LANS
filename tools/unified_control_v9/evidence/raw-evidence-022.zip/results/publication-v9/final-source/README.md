# LANS — latency-aware hybrid control research

LANS studies whether learned steering corrections can improve a strong LQR tracker while a supervisor rejects stale or unhelpful commands. Current evidence supports modest, condition-dependent gains from the frozen gated controller. It does not establish PPO dominance, general stability, real-vehicle safety, automotive deployment readiness or a universal inference rate.

The [controller review](docs/research/controller-review/README.md) identifies correctness defects in the historical root pipeline and separate limitations in the isolated research experiments. The [remediation record](docs/research/controller-remediation.md) documents corrected interfaces, quarantined comparisons, fresh diagnostics and remaining evidence limits. Historical comparative claims made by retired root scripts should not be cited as validated results.

The subsequent [ARIS audit remediation](docs/research/aris-remediation.md) retires unsupported result generators, fixes plotting, adds raw-data reporting and execution-aware evaluation, and records the remaining original-archive blocker.

The [full project audit and corrections](docs/research/full-project-audit/README.md) records 92 passing contract tests, corrected slow-query timestamps, verified raw metrics and remaining evidence limits behind the roughly 2% student gain.

The latest [mirrored confirmation and balanced-control study](integrations/webots/results/revision13-balanced/interpretation.md) completes 7,776 episodes with full survival. The prior nonlearned 9.122% lateral gain replicates at 9.131% on original positive-orientation roads; the expanded mirror grid gains 7.049%, with 36.543% higher actuator-rate RMS and 48.823% more steering movement. Three balanced objectives reduce movement but worsen tracking; none qualifies for reserved evaluation, native transfer or learning pilots. [Five uploaded primary papers](docs/research/primary-papers/README.md) are now reviewed with page-level evidence and important prior-method overlap; broader literature coverage and matched published-method benchmarks remain open.

The preceding [predictor/objective ablation](integrations/webots/results/revision12-ablation/interpretation.md) completes 1,080 paired development episodes. A lateral-only gate objective raises the frozen student's LQR-relative improvement to 4.528%, while same-gate fixed corrections achieve 6.864% and 9.122%. The largest gain is nonlearned, and representative traces show heading/steering trade-offs. No learned variant passes its frozen promotion criteria. [Literature positioning](docs/research/literature-positioning.md) distinguishes the measured contribution from unverified novelty claims.

## Current evidence and entry points

- **Latest validation continuation:** [v9 audited Python, runtime and native evidence](tools/unified_control_v9/README.md).
  All 3,440 calibration/evaluation episodes, 49,152 new training steps, 20 actual-worker
  checks and 16 native transfer episodes are retained. The strict-quality candidate
  is not promoted: final LQR-relative RMSE gain is only 0.0653%, and the old hybrid
  performs better. Training crossing failures and one native scheduled-cycle miss
  remain explicit. The requested 30% and full-framework validation remain unmet.
- **Latest integrated controller:** [v8 execution and verified raw evidence](tools/unified_control_v8/README.md).
  The shared conflict-timing bug is corrected, and causal early identification
  wins the fixed training comparison. Fresh whole-run gain is **5.186% over LQR**
  and **1.074% over optimized nominal control**, passing the original development
  gate. All 336 hybrid safety runs pass; 100 focused tests and 1,431 simulation
  episodes replay. The requested 30% target remains unmet; one of 1,080 actual
  worker ticks misses 50 ms. Final reserved/formal runtime/Webots remain unopened.
  Heading/rate trade-offs and all seven comparisons are retained in the evidence.
- **Prior causal controller study:** [v7 execution and raw evidence](tools/unified_control_v7/README.md).
  All 1,936 unique simulations and 18 functional checks verify. The old tracking
  winner gains 4.562% over LQR; the conic alternative has three progress failures
  despite zero observed timing misses. Both outcomes remain preserved.
- **Requested 30% target:** [raw offline headroom diagnostics](tools/thirty_percent/README.md).
  The target is not achieved. Privileged offline plans find 9.343% gain while
  retaining original quality limits; a tracking-focused 18.429% gain violates
  those limits. These are not online hybrid/PPO results or a global impossibility
  proof. The verified online controller and its earlier outcomes remain unchanged.
- **Prior integrated proposal experiments:** [v6 execution and raw evidence](tools/unified_control_v6/README.md).
  Fresh three-seed hybrid gain is **1.131% over optimized nominal control**, with
  a positive clustered 95% interval; gain over calibrated LQR is **4.827%**, below
  the unchanged 5% gate. The 12-second component cohort has **0/64 full-system
  failures**; removing traffic expiry gives 14 collision episodes, and removing
  interaction supervision gives 47. Original timing misses and all failed
  experiments remain recorded. Final promotion/Webots are incomplete. No thesis
  draft, figure or presentation table was generated in this phase.
- **Integrated corridor repair:** [v5 results and remaining gates](tools/unified_control_v5/RESULTS.md).
  The original development failures fall from **19/96 to 0/96**, and original
  communication-stress failures from **14/72 to 0/72**. Fresh hybrid runs also
  have zero observed collisions/corridor failures. Hybrid mean RMSE now beats
  the shared optimized reference, but the unchanged statistical promotion gate
  still fails; reserved and final Webots validation remain unrun.
- **Latest performance audit and resumable experiment:** [v12 findings, fixes and matched results](docs/research/ppo-audit-v12/README.md).
  The response-delay forecast now uses the same nominal RK4 integration as the
  supervisor. Full model/Adam/environment/queue/normalizer/RNG checkpoints are
  saved every 10,000 training steps; an actual 10,000-step replay matches the
  uninterrupted run exactly. The active-path audit includes 45 passing
  regression tests and an inventory of 2,688 Python sources/snapshots.
  Two predeclared training arms across three seeds add **300,000 new steps**.
  All **1,200 fresh matched episodes survive**; **1,648,200 transitions** and
  **563,760 neural queries** replay, with **216 exact 100 ms/LQR pairs**.
  On this SAME grid, continued PPO gains **0.008%** over LQR; the higher-exploration
  variant is **0.113% worse**. The frozen student gains **0.405%** and the causal
  nonlearned planner **1.013%**. Both PPO arms fail the **20%** target; no actor
  is promoted. Numerical correction alone gives only **0.00109%** tracking
  improvement with unchanged weights. Low admitted authority and model mismatch
  remain research limitations; further exploration alone did not resolve them.
  [Semantic review](docs/research/ppo-audit-v12/semantic-review.md) distinguishes
  confirmed defects from architectural limits. A typed-verifier bug was repaired
  without changing raw data, tolerances or selection criteria; its failure is retained.
  Resume with `python tools/controller_review/resume_ppo_audit12.py --publish`
  in the recorded research environment; `--verify-only` checks sealed evidence.
  The finite budget is exhausted, and a resume starts no additional training.
- **Prior actual PPO training:** [three corrected-environment continuation runs and full matched results](docs/research/reviewer-training-v11/README.md).
  The user explicitly requested training despite the prior failed heuristic
  headroom screen. Three final endpoints add **300,000 new environment steps**,
  retaining the previous actor/critic/optimizer/reward statistics. All 840 fresh
  development episodes survive; 1,153,740 transitions and 281,880 neural
  decisions independently replay, including 144 exact100ms/LQR fallback pairs.
  On this SAME grid, new PPO gains **0.098%** over LQR, old PPO **0.360%**,
  student **0.429%**, and the causal nonlearned planner **1.025%**. New PPO is
  **0.263% worse than old PPO** and **0.333% worse than the student**.
  **20% remains unmet; no new actor is promoted.** Reserved/current-actor
  timing/native/laptop/physical claims are not inferred from these software
  episodes. [Learning/authority diagnostics](docs/research/reviewer-training-v11/learning-diagnostics.json)
  separate measured behavior from causal speculation.
  [Editable Word and PDF reports](docs/research/reviewer-training-v11/LANS_New_PPO_Training_Reports.zip).
  Resume with `python tools/reviewer_v11/run11.py --publish`; completed or
  failed trials are preserved, and no additional training starts automatically.
- **Prior active PPO audit — 20% target:** [verified fixes and diagnostic results](docs/research/reviewer-audit-v10/README.md).
  Terminal bootstrap observations, packet/request identity and numerical-domain
  validation are corrected in a new version. A nominal RK4 predictor uses
  average actual actuator-rate cost and matches an independent integrator.
  All 36 core contracts pass; 360 fresh diagnostic episodes survive and
  494,460 transitions / 247,248 neural decisions replay. On this narrower
  nominal/tire/20ms grid, corrected PPO gains 0.379% over LQR, student 0.537%,
  and the causal nonlearned planner 1.488%; old-predictor PPO gains 0.174%.
  **20% is not achieved.** Frozen actors were not retrained for the new
  numerical supervisor; no learning effect from the terminal fix is claimed.
  Current-runtime smoke has 1/1,500 original deadline misses, with functional
  fallback and full replay; it does not inherit v9's zero-miss timing result.
  [Strict target checks and miss attribution](docs/research/reviewer-audit-v10-target20.json)
  retain missing baselines and block a full-superiority claim. Resume with
  `python tools/controller_review/run_ppo20_audit.py --publish` in the research
  environment. Previous criteria/results remain frozen; reserved data unopened.
- **Prior matched-training single pipeline:** [matched causal-state retraining, full replay and status](docs/research/reviewer-pipeline-v9/README.md).
  Six fixed pilots add 600,000 training steps; all 1,080 fresh development
  episodes survive and 1,483,380 transitions / 563,760 neural decisions replay.
  The new causal-history PPO gains 0.230% over LQR but is 0.034% worse than
  the compensated student, so scientific selection still fails. The
  predeclared diagnostic actor records **0/7,500 original 10ms deadline
  misses**, with functional fallback and full history/query/gate replay.
  This finite cloud result is not target-laptop or hard-real-time evidence;
  earlier failed campaigns remain preserved. An initial one-decision float32
  batch/single-row audit discrepancy is documented and corrected by exact
  single-observation replay, with no episode reruns or relaxed criteria.
  [Python 3.10 Windows/macOS kit](docs/research/reviewer-pipeline-v9/LANS_Causal_Python310_Kit.zip)
  and [Word/PDF evidence reports](docs/research/reviewer-pipeline-v9/LANS_Pipeline_Reports.zip).
  Run `python tools/controller_review/run_single_pipeline.py --publish` in
  the research environment. Exit 2 explicitly retains unmet scientific or
  external requirements; reserved/native, matched robust-vehicle reproduction,
  primary references and physical/target evidence are not silently passed.
- **Prior recovery/expiry study:** [full matched matrix and deadline guard](docs/research/reviewer-recovery-v8/README.md).
  Recovery now requires three distinct qualifying proposals across bounded gaps,
  with zero authority on stale ticks. Prediction uses only the current packet's
  eligible lifetime, then LQR continuation. All 840 episodes survive and
  1,153,740 transitions replay. Compensated PPO gains 0.295% over LQR and 0.024%
  over the matching student; full selection fails. Guard timing has 1/7,500
  original-deadline misses; the randomized unguarded arm has 2/7,500. A separate
  one-second worker-stall/recovery test passes all three seeds with 0/2,400
  misses. These finite windows are not WCET or vehicle certification.
  [Updated three-actor Python 3.10 kit](docs/research/reviewer-recovery-v8/LANS_Recovery_Python310_Kit.zip)
  and [Word/PDF evidence reports](docs/research/reviewer-recovery-v8/LANS_Recovery_Reports.zip)
  preserve failures. Resume with
  `python tools/controller_review/run_recovery_work.py --publish`.
- **New experimental component:** [explicit neural-response delay compensation](docs/research/reviewer-delay-compensation-v7/README.md).
  Supervisor-owned model forecasting supplies predicted physical PPO inputs
  over a causal estimate from completed-response history. The horizon is capped
  at 40ms; original timestamps and the 50ms stale cutoff remain unchanged.
  All 72 diagnostic episodes and 93,600 transitions replay. Tracking gain
  versus raw PPO is +0.471% at 20ms logical service and -0.116% at 10ms;
  40/100ms cases have no learned authority. This is approximate input
  compensation, not physical delay cancellation or a promoted controller.
  [Experimental Python 3.10 kit](docs/research/reviewer-delay-compensation-v7/LANS_Delay_Compensation_Python310_Kit.zip)
  uses the explicit `delay_compensated` profile and unchanged frozen weights.
  Earlier frozen timing studies require their recorded source snapshots/commits;
  current v7 source must not be relabeled with their old hashes.
- **Latest submitted-action study:** [matched credit ablation and timing attribution](docs/research/reviewer-credit-v6/final-update.md).
  Six fixed pilots add 600,000 transitions; all 672 fresh development episodes
  survive and 922,992 transitions independently replay. Submitted-only PPO gains
  2.611% over LQR, but just 0.561% over the student, below the frozen 1% margin.
  No arm qualifies. The separate diagnostic misses 657/7,500 controller deadlines;
  the native heartbeat misses 587/3,000. Functional fallback passes; reserved
  confirmation stays unopened. A verified scalar robust-filter specialization
  and all-32-entry bibliography audit do not constitute the matched robust
  vehicle reproduction or complete primary-source verification.
  [Three-actor Python 3.10 kit](docs/research/reviewer-credit-v6/LANS_Current_Python310_Kit.zip)
  and [Word/PDF evidence reports](docs/research/reviewer-credit-v6/LANS_Credit_Reports.zip)
  remain research diagnostics. Resume with
  `python tools/controller_review/run_credit_work.py --publish`.
- **Latest matched history ablation:** [600,000 additional transitions and 672 fresh episodes](docs/research/reviewer-history-v5/final-update.md).
  The balanced no-history diagnostic gains 2.956% over LQR, with 0.52% lower
  heading error and 4.73% higher actuator-rate RMS. Its 0.943% student-relative
  gain misses the unchanged 1% requirement. The history variant also fails the
  steering-rate limit. No winner is promoted; reserved tests remain unopened.
  [Python 3.10 diagnostic kit](docs/research/reviewer-history-v5/LANS_History_Python310_Kit.zip)
  and [Word/PDF evidence reports](docs/research/reviewer-history-v5/LANS_History_Reports.zip)
  include the versioned causal input and ABI guards. The 1,500-tick cloud smoke
  has 274 deadline misses; functional fallback passes. Actual laptop and physical
  validation are pending. Resume with
  `python tools/controller_review/run_history_work.py --publish`.
- **Latest deep diagnosis:** [realistic asynchronous delivery and scalar predictor](docs/research/reviewer-interface-v4/final-update.md).
  The unchanged PPO endpoints gain2.579% over LQR, with0.51% lower heading error
  and4.17% higher actuator-rate RMS. The roughly0.57% student-relative gain still
  fails the frozen1% margin. All672 episodes survive; actual one-second worker
  stall/recovery passes functional checks for all three seeds. Deadline tests
  still fail, including the native heartbeat baseline. No candidate is promoted.
  [Updated experimental Python3.10 kit](docs/research/reviewer-interface-v4/LANS_Interface_Python310_Kit.zip)
  uses the fresh-within-deadline authority rule, scalar predictor and actual PPO
  actors in a software plant; it is not vehicle deployment approval.
  Resume with `python tools/controller_review/run_interface_work.py --publish`.
- **Latest aligned study:** [300,000-step training and576-episode comparison](docs/research/reviewer-aligned-v3/README.md)
  passes the balanced-versus-LQR development screen:1.445% tracking gain,
  0.27% lower heading error and2.66% higher actuator-rate RMS (within5%).
  PPO beats the matched student by about0.33%, below the frozen1% margin;
  full promotion fails and reserved tests remain unopened. Timing still fails.
  [Verified report](docs/research/reviewer-aligned-v3/final-update.md) and
  [Python3.10 full-controller kit](docs/research/reviewer-aligned-v3/LANS_Aligned_Python310_Kit.zip)
  include actual v3 actors, exact NumPy export and replay checks.
  [One-command reproduction and limits](tools/controller_review/README-aligned.md).
- **Prior frozen follow-up:** [same-gain attribution and smoothing](docs/research/reviewer-followup-v2/README.md)
  reports864 fresh development episodes. Filtered PPO gains5.79% tracking versus
  LQR, but has27.5% higher actuator-rate RMS and trails the same-gain student.
  Preview filtering gains0.73%; no new variant passes the frozen selection gate.
  [Detailed update](docs/research/reviewer-followup-v2/final-research-update.md)
  separates timing failures, nominal published-filter specialization, laptop kit
  and physical evidence still required. Resume software stages with
  `python tools/controller_review/run_followup_work.py --publish`.
- [Reviewer-response causal residual campaign](tools/reviewer_campaign/README.md):
  one-command staged PPO training, mirrored comparisons, real-worker timing and
  native interface checks, with verified milestones pushed to the research branch.
  [Live evidence and status](docs/research/reviewer-causal-v1/status.json) distinguish
  completed tests from failed criteria and pending physical/reference work.
- [Archived90-episode diagnostic](docs/research/reviewer-pilot-2026-10-26/README.md):
  historical checkpoints only; their old input interface prevents a deployable
  causal-policy claim. Do not mix their numerical gains with the new campaign.

- [Specification](docs/research/specification-v0.1.md): research requirements; unchanged by remediation.
- [Cloud setup](tools/cloud/README.md): dependency and environment instructions.
- [Webots validation history](docs/research/webots-validation.md): simulation configuration, units, results and native-transfer limitations.
- [Frozen gated surrogate results](integrations/webots/results/revision2-test/report.md) and [native results](integrations/webots/results/revision2-native-test/report.md).
- [Range-matched retraining](integrations/webots/results/revision3-600k/report.md): flat/mixed development trend; no full-budget follow-up.
- [Gate-aware and relative-reward pilots](integrations/webots/results/revision4-pilots/report.md): new arms did not beat the pilot baseline.
- [Predictor and nonlearned-control diagnostics](integrations/webots/results/revision5-audit/report.md): explicit attribution controls on development data.

## Correction-quality PPO pilot (revision6)

The [matched600k-step pilot](integrations/webots/results/revision6-correction/interpretation.md) trained two arms at three fresh seeds and evaluated648 paired development episodes. Execution-aware training improved direct-trained error by only0.15%, failed the1% progress screen and did not beat simple fixed corrections. Neither model is promoted. The nominal constrained MPC reference is explicitly limited; LQR also beats it. [Protocol and reproduction](integrations/webots/research/revision6/README.md).

## Step1 headroom diagnostic (revision7)

The [five-action privileged diagnostic](integrations/webots/results/revision7-headroom/interpretation.md) completed864 paired episodes. With the actual frozen gate, measured error is2.076% lower than LQR and1.266% lower than the best global fixed proposal; all108 gated cases survive. The diagnostic bypass fails90/108 cases. These are finite-policy privileged results, **not an absolute ceiling or a trained-student result**. That Step1 diagnostic launched no training; Step2 is recorded below. [Protocol and reproduction](integrations/webots/research/revision7/README.md).

## Step2 supervised pilot (revision8)

The [teacher/student pilot](integrations/webots/results/revision8-student/interpretation.md) removes actual future-noise knowledge from teacher forecasts and trains three sensor/history-only students. On540 fresh paired episodes the student reduces LQR error by2.158% and the predeclared fixed-correction error by1.351%, passing its bounded pilot screen with108/108 survival. These are known task families, not native/safety/general-superiority evidence. Step2 itself launched no PPO fine-tuning, gate change or model promotion. [Protocol/reproduction](integrations/webots/research/revision8/README.md).

## Step3 PPO fine-tuning pilot (revision9)

The [matched fine-tuning pilot](integrations/webots/results/revision9-finetuning/interpretation.md) completed600k additional RL steps with exact supervised-actor transfer and a scratch control. All three finetune seeds selected step0 on independent development episodes. On756 fresh final episodes, the retained student reduces LQR error by2.068%; the100k fine-tuned endpoint has0.323% **higher** error than that student. The incremental PPO improvement screen fails. Retain the supervised research checkpoint; no production promotion or gate change. [Chart](integrations/webots/results/revision9-finetuning/comparison.png), [full report](integrations/webots/results/revision9-finetuning/report.md), [protocol/reproduction](integrations/webots/research/revision9/README.md).

## Corrected root demonstration

The corrected world-coordinate plant is a separate linear-tire demonstration, not the nonlinear Webots research surrogate. Full steering is applied once by `PathTrackingEnv`; `ResidualPathEnv` owns one LQR-plus-residual fusion. Old root checkpoints are incompatible and must not be reused as corrected policies.

```bash
python tests/test_controller_remediation.py -v
python tools/controller_review/train.py --steps 1000 --output /tmp/lans-corrected-bundle
python tools/controller_review/compare.py --bundle /tmp/lans-corrected-bundle --output /tmp/lans-corrected-comparison
python tools/controller_review/benchmark.py --bundle /tmp/lans-corrected-bundle --output /tmp/lans-inference.json
```

The 1000-step example verifies the pipeline, not policy quality. Output locations must be new. Learned control requires a versioned policy/normalization bundle; missing or incompatible models fail explicitly. Wall inference duration and simulated action age are reported separately. Five-seed full research training requires the predeclared development evidence; it is not launched by these examples.
