# Python-first campaign results

Stage: development. Episodes: 320. Audited ticks: 32931.

**Promotion gate: FAIL.**

| Controller | Mean RMSE (m) | Failed cases | Mean progress (m) |
|---|---:|---:|---:|
| lqr | 0.671773 | 12/32 | 51.754 |
| fixed | 0.455305 | 8/32 | 57.608 |
| deterministic | 0.698534 | 13/32 | 51.438 |
| optimized | 0.369497 | 6/32 | 58.444 |
| ppo | 0.648608 | 34/96 | 51.872 |
| hybrid | 0.666103 | 37/96 | 52.111 |

Hybrid gains and cluster-bootstrap 95% intervals:
{
  "lqr": {
    "gain_percent": 0.844083195830303,
    "ci95_percent": [
      -15.045098865632282,
      9.511363223104164
    ],
    "clusters": 8
  },
  "optimized": {
    "gain_percent": -80.27278479834186,
    "ci95_percent": [
      -224.62435505248362,
      -12.58757947112071
    ],
    "clusters": 8
  }
}

Per-actor LQR-relative gain (%): {"42": -3.9468131109394733, "43": 4.294832245657343, "44": 2.184230452773017}

Gate reasons:
- actor_42_failed_case_10
- actor_42_failed_case_12
- actor_42_failed_case_15
- actor_42_failed_case_18
- actor_42_failed_case_19
- actor_42_failed_case_2
- actor_42_failed_case_26
- actor_42_failed_case_27
- actor_42_failed_case_3
- actor_42_failed_case_30
- actor_42_failed_case_31
- actor_42_failed_case_4
- actor_42_failed_case_8
- actor_42_no_positive_lqr_gain
- actor_42_progress_regression_case_27
- actor_42_progress_regression_case_4
- actor_43_failed_case_10
- actor_43_failed_case_12
- actor_43_failed_case_15
- actor_43_failed_case_18
- actor_43_failed_case_19
- actor_43_failed_case_2
- actor_43_failed_case_26
- actor_43_failed_case_3
- actor_43_failed_case_30
- actor_43_failed_case_31
- actor_43_failed_case_4
- actor_43_failed_case_8
- actor_43_progress_regression_case_12
- actor_43_progress_regression_case_15
- actor_43_progress_regression_case_4
- actor_43_progress_regression_case_8
- actor_44_failed_case_10
- actor_44_failed_case_12
- actor_44_failed_case_15
- actor_44_failed_case_18
- actor_44_failed_case_19
- actor_44_failed_case_2
- actor_44_failed_case_26
- actor_44_failed_case_27
- actor_44_failed_case_30
- actor_44_failed_case_31
- actor_44_failed_case_4
- actor_44_failed_case_8
- actor_44_progress_regression_case_27
- actor_44_progress_regression_case_8
- gain_vs_lqr_below_5.0_percent
- gain_vs_optimized_below_1.0_percent
- lower_ci_vs_lqr_not_positive
- lower_ci_vs_optimized_not_positive

All outcomes retained. Logical-time performance supplies no measured real-time guarantee.
Reserved data, real-worker final confirmation and native Webots remain conditional on Python gates.
