# Python-first campaign results

Stage: development. Episodes: 320. Audited ticks: 32673.

**Promotion gate: FAIL.**

| Controller | Mean RMSE (m) | Failed cases | Mean progress (m) |
|---|---:|---:|---:|
| lqr | 0.623266 | 9/32 | 49.016 |
| fixed | 0.615651 | 9/32 | 49.726 |
| deterministic | 0.623780 | 9/32 | 48.989 |
| optimized | 0.422965 | 6/32 | 55.272 |
| ppo | 0.621527 | 27/96 | 49.152 |
| hybrid | 0.438075 | 19/96 | 54.949 |

Hybrid gains and cluster-bootstrap 95% intervals:
{
  "lqr": {
    "gain_percent": 29.712946203988942,
    "ci95_percent": [
      2.0046579050720417,
      62.63914323132154
    ],
    "clusters": 8
  },
  "optimized": {
    "gain_percent": -3.5724311406678533,
    "ci95_percent": [
      -17.420649934754454,
      0.0031909552946962627
    ],
    "clusters": 8
  }
}

Per-actor LQR-relative gain (%): {"42": 24.861914315256218, "43": 32.14617509116978, "44": 32.13074920554083}

Gate reasons:
- actor_42_failed_case_11
- actor_42_failed_case_15
- actor_42_failed_case_2
- actor_42_failed_case_27
- actor_42_failed_case_30
- actor_42_failed_case_6
- actor_42_failed_case_7
- actor_42_progress_regression_case_7
- actor_43_failed_case_15
- actor_43_failed_case_2
- actor_43_failed_case_27
- actor_43_failed_case_30
- actor_43_failed_case_6
- actor_43_failed_case_7
- actor_43_progress_regression_case_7
- actor_44_failed_case_15
- actor_44_failed_case_2
- actor_44_failed_case_27
- actor_44_failed_case_30
- actor_44_failed_case_6
- actor_44_failed_case_7
- actor_44_progress_regression_case_7
- gain_vs_optimized_below_1.0_percent
- lower_ci_vs_optimized_not_positive

All outcomes retained. Logical-time performance supplies no measured real-time guarantee.
Reserved data, real-worker final confirmation and native Webots remain conditional on Python gates.
