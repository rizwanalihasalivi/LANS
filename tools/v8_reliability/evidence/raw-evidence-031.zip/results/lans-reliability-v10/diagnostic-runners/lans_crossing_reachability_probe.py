import json,math
from pathlib import Path
import numpy as np
from tools.unified_control_v9.learning import setup
from tools.unified_control_v4.kernels import step,lqr
from integrations.unified_lans.physics import Config
p=Path('results/lans-reliability-v10/prior-diagnostics/results/publication-v9/training-diagnostics/audit.json')
d=json.loads(p.read_text());results=[]
for e in d['endpoints']:
 for f in e['failures']:
  c=f['case'];item=dict(seed=e['seed'],episode=f['episode'],case=c,plans=[])
  for acceleration in (-6.,-3.,0.,2.5):
   pipe,clock,z,npcs,net=setup(c,'lqr',controller_kwargs={'mpc':False,'adaptive':False})
   other=np.array(next(iter(npcs.values())));previous=0.;minimum=1e9;robust=1e9;ds=[]
   for i in range(400):
    t=i*.01;base=lqr(z,pipe._gains,*[int(pipe._route[0]),*pipe._route[1:]],1.)
    u=max(-.5,min(.5,max(previous-.006,min(previous+.006,base))));previous=u
    z=step(z,u,0. if t<c['delay']-1e-9 else acceleration,.01,c['stiffness'])
    other[:2]+=.01*other[3]*np.array([math.cos(other[2]),math.sin(other[2])])
    distance=float(np.linalg.norm(z[:2]-other[:2]));minimum=min(minimum,distance-4.6)
    robust=min(robust,distance-5.1-.6*(t+.01))
   item['plans'].append(dict(accel=acceleration,physical_clearance=minimum,robust_clearance=robust,end_x=float(z[0])))
  results.append(item);print(e['seed'],f['episode'],item['plans'])
Path('results/lans-reliability-v10/constant-accel-diagnostic.json').write_text(json.dumps(results,indent=2))
