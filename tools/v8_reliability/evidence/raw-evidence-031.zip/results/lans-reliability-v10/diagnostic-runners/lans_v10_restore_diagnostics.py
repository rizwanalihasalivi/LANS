from pathlib import Path
import hashlib,json,zipfile
src=Path('/workspace/LANS/tools/unified_control_v9/evidence')
out=Path('/workspace/LANS/results/lans-reliability-v10/prior-diagnostics')
out.mkdir(parents=True,exist_ok=False)
seal=json.loads((src/'SEAL.json').read_text());checked=set();count=0
for name,record in seal['files'].items():
    take=('training-diagnostics/' in name or name.endswith('calibration/selection.json') or '/native/' in name and name.endswith(('/summary.json','/case.json','/ticks.jsonl')))
    if not take or '/source/' in name:continue
    data=[]
    for part in record['pieces']:
        archive=part['archive']
        if archive not in checked:
            entry=next(a for a in seal['archives'] if a['name']==archive)
            assert hashlib.sha256((src/archive).read_bytes()).hexdigest()==entry['sha256'];checked.add(archive)
        with zipfile.ZipFile(src/archive) as z:block=z.read(part['member'])
        assert len(block)==part['size'] and hashlib.sha256(block).hexdigest()==part['sha256'];data.append(block)
    raw=b''.join(data);assert len(raw)==record['size'] and hashlib.sha256(raw).hexdigest()==record['sha256']
    dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);count+=1
print({'restored_diagnostic_files':count,'source_archives_verified':len(checked)})
d=json.loads((out/'results/publication-v9/training-diagnostics/audit.json').read_text())
for e in d['endpoints']:
    for f in e['failures']:
        print('FAILURE',e['seed'],f['episode'],f['case'],'first failure tick',f['actual_first_failure_tick'])
        h=f['all_failure_history'];print('HISTORY',[(r['tick'],r['risk'],r['reason'],r['applied_accel'],r['state_after'][:4],r['actual_truth']['true_clearance']) for r in h[::max(1,len(h)//8)]])
for p in out.glob('results/publication-v9/native/*/summary.json'):
    s=json.loads(p.read_text())
    if s['scheduled_cycle_misses']:print('TIMING_FAILURE',p.parent.name,s)
print('SELECTED',json.loads((out/'results/publication-v9/calibration/selection.json').read_text())['selected'])
