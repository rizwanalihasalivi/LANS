"""Cached unchanged v9 steering admission with explicit longitudinal recourse."""
from integrations.unified_lans.physics import Command
from tools.unified_control_v9.control import Controller as Prior
from .recovery import choose


class Controller(Prior):
    def __init__(self,*args,recovery=True,**kwargs):
        super().__init__(*args,**kwargs)
        self.recovery_enabled=recovery;self._candidate_cache={};self.cache_hits=0

    def cost(self,z,first,residual,accel,vehicles,lifetime):
        planned=self._plan is not None and self._plan_residual is not None and abs(residual-self._plan_residual)<1e-12
        key=(tuple(z),first.steering,accel,self.issued.steering,self.stiffness_estimate,
             self.stiffness_uncertainty,self.feedback_stiffness,
             tuple((name,tuple(other),unc) for name,other,unc in vehicles),
             tuple(self._plan) if planned else None)
        if key not in self._candidate_cache:
            self._candidate_cache[key]=super().cost(z,first,residual,accel,vehicles,lifetime)
        else:self.cache_hits+=1
        return self._candidate_cache[key]

    def decide(self,now,worker_failed=False):
        self._candidate_cache={};self.cache_hits=0
        result=super().decide(now,worker_failed)
        recourse=None
        if self.recovery_enabled and result['reason']=='no_feasible_prediction' and not result['ego_backup'] and not result['missing']:
            z=self.forecast(now)
            nominal=max(-6.,min(2.5,.8*(self.target_speed-z[3])))
            recourse=choose(self,now,self.issued,nominal)
            if recourse is not None and recourse['selected']['accel']!=self.issued.accel:
                command=Command(self.issued.steering,recourse['selected']['accel'])
                self.pending[-1]=(now+self.delay,command);self.issued=command
                result.update(source='recovery_lqr',residual=0.,issued_accel=command.accel,
                    reason='longitudinal_recourse',planned_candidate_selected=False)
        result.update(recovery=recourse,candidate_cache_hits=self.cache_hits)
        return result
