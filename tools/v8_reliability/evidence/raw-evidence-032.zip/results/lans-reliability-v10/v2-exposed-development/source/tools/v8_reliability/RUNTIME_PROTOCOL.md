# Actual-worker cohort declared before execution

After all2309 CPU confirmation episodes and independent reconstruction finish,
run26 six-second actual-worker episodes sequentially. Both original-v8 and
selected new controller use each unchanged actor42/43/44 in four fixed conditions:
following/nominal, curved/ego-blackout, merge/PPO-crash and following/loss/PPO-stall.
Add selected-new actor42 following with planner-stall and planner-crash. Inject
crashes at1s; stalls last300ms. After1.5s no failed/stalled worker's stale proposal
may be selected. Source timestamps/TTLs and limits stay unchanged. Startup
warms returned-plan owner admission and is recorded separately.

Use actual spawned inference/solver processes and a fixed50ms release origin,
with no dropped tick or schedule reset. Measure sensor/wire input to issue,
and the complete cycle through plant propagation and inline JSON write/flush.
Retain all slow ticks in a separately hashed timing sidecar. Scope is finite
engineering observation on this shared cloud machine, not WCET/real-time proof.
Independent scalar physics/FIFO/source-age reconstruction is required. Fault
checks, safety, local timing and scheduled timing are separate outcome flags.
No new PPO training, altered policy weights, drafts, figures or tables.
